import neon from "../assets/raw/neon.jpg";
import crown from "../assets/raw/crown.jpg";
import tide from "../assets/raw/tide.jpg";
import signal from "../assets/raw/signal.jpg";
import paper from "../assets/raw/paper.jpg";
import solar from "../assets/raw/solar.jpg";
import iron from "../assets/raw/iron.jpg";

export type Game = {
  id: string;
  title: string;
  tagline: string;
  genre: string;
  developer: string;
  year: number;
  /** One honest, whole-dollar price. No fake "was" prices, no .99 charm pricing. */
  price: number;
  rating: number;
  sizeGB: number;
  img: string;
  color: string;
  focus: string;
  deck: string;
  author: string;
  article: string[];
  quote: string;
  features: string[];
  players: string;
  tags: string[];
};

export const GAMES: Game[] = [
  {
    id: "neon-drift",
    title: "Neon Drift",
    tagline: "The city never sleeps. Neither do your tires.",
    genre: "Racing",
    developer: "Halcyon Motorworks",
    year: 2026,
    price: 50,
    rating: 4.7,
    sizeGB: 38.2,
    img: neon,
    color: "#ff2e88",
    focus: "50% 60%",
    deck: "A rain-slicked love letter to midnight street racing, where every corner is a dare and every reflection tells a story.",
    author: "Mara Okafor",
    article: [
      "There is a moment, about four seconds into your first drift through the Kowloon Spiral, when Neon Drift stops being a racing game and becomes something closer to a dance. The rear tires let go, the city blurs into ribbons of magenta and cyan, and the soundtrack drops out to nothing but the hiss of rain on hot asphalt.",
      "Halcyon Motorworks has spent six years building this city, and it shows. Every alley is hand-placed, every billboard animated, every puddle a mirror. The open world isn't the biggest we've seen, but it may be the densest — a vertical maze of overpasses and service tunnels that rewards curiosity as much as raw speed.",
      "The handling model sits in a sweet spot between arcade and sim. You'll feel weight transfer, but you won't need a wheel. Crew races, a pursuit mode that genuinely raises the pulse, and a photo mode that might swallow whole weekends round out a package that feels finished in a way few launch titles do.",
    ],
    quote: "Every puddle is a mirror, every corner a dare.",
    features: ["Open-world night city", "64 licensed machines", "Crew online play", "Ray-traced reflections"],
    players: "1–8 Online",
    tags: ["Open World", "Multiplayer", "Arcade"],
  },
  {
    id: "hollow-crown",
    title: "Hollow Crown",
    tagline: "Kneel before a throne no one remembers.",
    genre: "RPG",
    developer: "Ashgrove Studio",
    year: 2025,
    price: 60,
    rating: 4.9,
    sizeGB: 72.4,
    img: crown,
    color: "#c9a227",
    focus: "50% 40%",
    deck: "A cathedral-sized dark fantasy where the kingdom has already fallen — and you arrived three hundred years too late.",
    author: "Elias Brandt",
    article: [
      "Hollow Crown opens with an ending. The king is dead, the court is dust, and the great cathedral of Vael stands empty save for the ash that falls, endlessly, from a ceiling you will never see. You are a knight with no oath and no memory, and the game's genius is that it never tells you why you came.",
      "Combat is deliberate and punishing, built around stamina and the weight of your weapon. But Ashgrove's real achievement is the world itself: a single interconnected ruin that folds back on itself, where a door unlocked in hour thirty reveals the courtyard you crossed in hour one.",
      "It is a game about grief and inheritance, told almost entirely through architecture. The few characters you meet speak in riddles and half-confessions. Piecing together the fall of Vael is optional. You'll do it anyway.",
    ],
    quote: "A story told almost entirely through architecture.",
    features: ["Seamless 80-hour world", "Deep build crafting", "Optional co-op summons", "Five endings"],
    players: "1 (Co-op 2)",
    tags: ["Souls-like", "Story Rich", "Dark Fantasy"],
  },
  {
    id: "tidebound",
    title: "Tidebound",
    tagline: "Hold your breath. The ocean is listening.",
    genre: "Adventure",
    developer: "Low Tide Collective",
    year: 2026,
    price: 25,
    rating: 4.8,
    sizeGB: 12.1,
    img: tide,
    color: "#13b5b0",
    focus: "50% 50%",
    deck: "A wordless underwater odyssey through drowned cities, singing whales, and the slow, luminous dark.",
    author: "Juno Takeda",
    article: [
      "Tidebound has no dialogue, no map, and no health bar. What it has instead is light — shafts of it, falling through forty meters of turquoise water onto the bones of a civilization that built its temples for creatures far larger than us.",
      "You play as a small diver drawn ever deeper by the song of a leviathan. Puzzles are gentle and environmental: redirect a current, wake a field of bioluminescent coral, ride the wake of something enormous. It's a game you play with your shoulders lowered and your breath slowed.",
      "At roughly five hours, it never outstays its welcome. The final descent, when the light finally runs out and you navigate by sound alone, is one of the most quietly astonishing sequences of the year.",
    ],
    quote: "A game you play with your shoulders lowered.",
    features: ["Wordless storytelling", "Adaptive orchestral score", "Photo mode", "Steam Deck verified"],
    players: "1",
    tags: ["Relaxing", "Exploration", "Indie"],
  },
  {
    id: "signal-lost",
    title: "Signal Lost",
    tagline: "Something on the station answered back.",
    genre: "Horror",
    developer: "Black Static",
    year: 2025,
    price: 40,
    rating: 4.5,
    sizeGB: 46.8,
    img: signal,
    color: "#ff3b30",
    focus: "50% 50%",
    deck: "Alone on a derelict research station with one flashlight, failing oxygen, and a transmission that keeps saying your name.",
    author: "Dana Volkov",
    article: [
      "Signal Lost understands that the scariest thing in a horror game is a long corridor and a red light that flickers just slightly out of rhythm. Black Static's debut is a masterclass in restraint — the thing hunting you aboard Kepler Relay 7 appears perhaps a dozen times. You will feel it in every room.",
      "Resource management is tight but fair. Your flashlight battery, your oxygen, and your sanity all drain, and the station's systems must be rebooted one terminal at a time. Audio design is the star: put on headphones, and you'll start hearing footsteps that aren't in the mix.",
      "Not every late-game reveal lands, but the first eight hours are as tense as anything in the genre. Play it in the dark. Then regret it.",
    ],
    quote: "You will feel it in every room.",
    features: ["Binaural 3D audio", "Dynamic AI stalker", "Permadeath mode", "VR support"],
    players: "1",
    tags: ["Survival Horror", "Sci-Fi", "Atmospheric"],
  },
  {
    id: "paper-kingdoms",
    title: "Paper Kingdoms",
    tagline: "Fold an empire. Crease your enemies.",
    genre: "Strategy",
    developer: "Origami Lab",
    year: 2026,
    price: 30,
    rating: 4.6,
    sizeGB: 8.4,
    img: paper,
    color: "#f28c28",
    focus: "50% 55%",
    deck: "A charming tabletop strategy game where castles are folded, armies are cut out, and rivers are made of ribbon.",
    author: "Theo Lindqvist",
    article: [
      "Paper Kingdoms looks like a children's pop-up book and plays like a ruthless chess match. Each map is a hand-crafted diorama, and every unit you deploy is literally folded into existence before your eyes — the crinkle of paper accompanying every march.",
      "Underneath the charm is a surprisingly deep 4X-lite: territory control, supply lines, and a clever card system that lets you 'refold' the board itself, raising mountains or flooding valleys mid-battle.",
      "A full campaign, a daily puzzle mode, and couch multiplayer make it the rare strategy game you'll want to play with people who don't play strategy games.",
    ],
    quote: "Looks like a pop-up book. Plays like chess.",
    features: ["Refoldable battlefields", "Local & online PvP", "Map editor", "Daily challenges"],
    players: "1–4",
    tags: ["Turn-Based", "Family", "Tabletop"],
  },
  {
    id: "solar-bloom",
    title: "Solar Bloom",
    tagline: "Grow a garden at the edge of the galaxy.",
    genre: "Simulation",
    developer: "Moss & Moon",
    year: 2026,
    price: 0,
    rating: 4.4,
    sizeGB: 5.6,
    img: solar,
    color: "#a855f7",
    focus: "50% 50%",
    deck: "A cozy farming sim on a floating asteroid, where your only neighbor is a small robot who loves tomatoes.",
    author: "Priya Raman",
    article: [
      "Solar Bloom is free, and it is lovely. You inherit a tiny asteroid with a cracked greenhouse dome and a robot named Pip, and from there it's the familiar loop: plant, water, harvest, upgrade — but with low gravity, comet showers, and seeds that only bloom under specific nebula light.",
      "There's no stamina meter and no fail state. Seasons are replaced by orbital cycles, and visiting traders arrive on drifting barges with requests and rumours. The monetisation is purely cosmetic and refreshingly unpushy.",
      "It's the game equivalent of a warm drink, and we've returned to it every evening this month.",
    ],
    quote: "The game equivalent of a warm drink.",
    features: ["Free to play", "No fail states", "Cross-save", "Seasonal events"],
    players: "1 (Visits 4)",
    tags: ["Cozy", "Free", "Farming"],
  },
  {
    id: "ironclad-9",
    title: "Ironclad 9",
    tagline: "Forty tons of steel. One pilot. No retreat.",
    genre: "Action",
    developer: "Foundry Interactive",
    year: 2025,
    price: 55,
    rating: 4.3,
    sizeGB: 88.0,
    img: iron,
    color: "#ff7a1a",
    focus: "50% 45%",
    deck: "A heavy, roaring mech shooter where every step shakes the camera and every loadout is a philosophy.",
    author: "Rex Adeyemi",
    article: [
      "You feel Ironclad 9 before you see it. The camera shudders with every footfall, the cockpit rattles, and when you fire the twin rail cannons, the whole screen breathes in. Foundry has nailed the fantasy of piloting something enormous and slightly out of control.",
      "Missions sprawl across dust-choked deserts and ruined megacities. Between sorties you return to the hangar to swap limbs, reactors, and weapons in a garage system so deep it could be its own game.",
      "The story is pure B-movie, but the 6v6 Siege mode is where Ironclad lives — slow, tactical, and explosive in the best way.",
    ],
    quote: "Every footfall shakes the world.",
    features: ["Modular mech garage", "6v6 Siege mode", "Destructible cities", "Co-op campaign"],
    players: "1–12 Online",
    tags: ["Mechs", "Shooter", "PvP"],
  },
];

export const GENRES = ["All", ...Array.from(new Set(GAMES.map((g) => g.genre)))];

/** Three-letter "destination codes" printed on purchase passes */
export const CODES: Record<string, string> = {
  "neon-drift": "NDR",
  "hollow-crown": "HCR",
  tidebound: "TDB",
  "signal-lost": "SGL",
  "paper-kingdoms": "PKD",
  "solar-bloom": "SLB",
  "ironclad-9": "IC9",
};

export const getGame = (id: string) => GAMES.find((g) => g.id === id)!;

/** "$50", or "Free". Older receipts keep their exact cents, so nothing is ever misstated. */
export const fmtPrice = (n: number) => (n === 0 ? "Free" : Number.isInteger(n) ? `$${n}` : `$${n.toFixed(2)}`);
