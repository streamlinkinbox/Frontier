import { useEffect, useRef } from "react";
import type { CSSProperties } from "react";
import { AppProvider, useApp, pageNo, routeMeta } from "./store";
import type { Route, TransitionStyle } from "./store";
import Cover from "./pages/Cover";
import Index from "./pages/Index";
import Store from "./pages/Store";
import Browse from "./pages/Browse";
import Library from "./pages/Library";
import Downloads from "./pages/Downloads";
import Settings from "./pages/Settings";
import GamePage from "./pages/GamePage";
import { Footer, Header, LaunchOverlay, Toasts } from "./components/Chrome";
import { ReceiptModal } from "./components/Receipt";
import { cx } from "./components/ui";
import { useReveal } from "./components/micro";

function renderRoute(r: Route) {
  if (r.startsWith("game:")) return <GamePage id={r.slice(5)} />;
  switch (r) {
    case "cover":
      return <Cover />;
    case "store":
      return <Store />;
    case "games":
      return <Browse />;
    case "library":
      return <Library />;
    case "downloads":
      return <Downloads />;
    case "settings":
      return <Settings />;
    default:
      return <Index />;
  }
}

const IN_CLASS: Record<TransitionStyle, string> = {
  turn: "turn-in",
  ink: "ink-in",
  shutter: "shutter-in",
  crt: "crt-in",
  slice: "slice-in",
  panel: "panel-in",
};

function Stage() {
  const { nav, settings, durationMs } = useApp();
  const curRef = useRef<HTMLDivElement>(null);
  useReveal(curRef, nav.current, nav.enter);

  const { current, prev, dir, origin, key, enter } = nav;
  const t = settings.transition;
  const curClass = prev ? IN_CLASS[t] : "";
  const prevClass = t === "turn" ? `turn-out-${dir}` : `${t}-out`;
  const curZ = t === "ink" ? 30 : 10;
  const prevZ = t === "ink" ? 10 : 20;
  const meta = routeMeta(current);

  const style = {
    ["--dur" as string]: `${durationMs}ms`,
    ["--x" as string]: `${origin.x}px`,
    ["--y" as string]: `${origin.y}px`,
    ["--dir" as string]: dir,
  } as CSSProperties;

  return (
    <main className="stage fixed inset-0 overflow-hidden bg-black" style={style}>
      <div key={current} ref={curRef} className={cx("page", curClass)} style={{ zIndex: curZ, ["--enter" as string]: `${enter}ms` } as CSSProperties}>
        {renderRoute(current)}
        <div className="page-shade" />
      </div>

      {prev && (
        <div key={prev} className={cx("page pointer-events-none", prevClass)} style={{ zIndex: prevZ }}>
          {renderRoute(prev)}
          <div className="page-shade" />
        </div>
      )}

      {prev && t === "ink" && <div key={`blot-${key}`} className="ink-blot" style={{ zIndex: 20 }} />}

      {prev && t === "crt" && (
        <div key={`crt-${key}`}>
          <div className="crt-noise" />
          <div className="crt-scan" />
          <div className="crt-bar" />
        </div>
      )}

      {prev && t === "slice" && <div key={`slice-${key}`} className="slice-lines" />}

      {prev && t === "panel" && (
        <div key={`panel-${key}`} className="panel-swipe">
          <span />
          <span />
          <span />
        </div>
      )}

      {prev && t === "shutter" && (
        <div key={`sh-${key}`}>
          <div className={`shutter-panel-ink d${dir}`} />
          <div className={`shutter-panel shutter-panel-${dir}`}>
            <div className="shutter-title">
              <div className="font-mono text-xs uppercase tracking-[.4em] opacity-80 md:text-sm">
                {meta.kicker} — p.{pageNo(current)}
              </div>
              <div className="font-display text-[18vw] uppercase leading-[.82] md:text-[12vw]">{meta.title}</div>
            </div>
            <div className="absolute bottom-6 right-8 select-none font-display text-[30vw] leading-none opacity-15">{pageNo(current)}</div>
          </div>
        </div>
      )}
    </main>
  );
}

function Keys() {
  const { step, navigate, playing, stop, receiptView } = useApp();
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      if (receiptView) return; // the receipt handles its own keys
      if (playing) {
        if (e.key === "Escape") stop();
        return;
      }
      if (e.key === "ArrowRight") step(1);
      else if (e.key === "ArrowLeft") step(-1);
      else if (e.key === "Escape") navigate("index");
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [step, navigate, playing, stop, receiptView]);
  return null;
}

function Shell() {
  const { settings } = useApp();
  return (
    <div className={cx("h-full", settings.grain && "grain")}>
      <Stage />
      <Header />
      <Footer />
      <LaunchOverlay />
      <ReceiptModal />
      <Toasts />
      <Keys />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
