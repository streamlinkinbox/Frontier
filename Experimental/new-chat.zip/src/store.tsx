import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { GAMES, getGame } from "./data/games";

/* ---------- Routes ---------- */
export type Route = string; // 'cover' | 'index' | 'store' | 'games' | 'library' | 'downloads' | 'settings' | `game:${id}`

export const ORDER: Route[] = [
  "cover",
  "index",
  "store",
  "games",
  ...GAMES.map((g) => `game:${g.id}`),
  "library",
  "downloads",
  "settings",
];

export const pageNo = (r: Route) => {
  const i = ORDER.indexOf(r);
  return i <= 0 ? "C1" : String(i * 2).padStart(2, "0");
};

export const routeMeta = (r: Route): { title: string; kicker: string } => {
  if (r.startsWith("game:")) {
    const g = getGame(r.slice(5));
    return { title: g.title, kicker: `Feature · ${g.genre}` };
  }
  const map: Record<string, { title: string; kicker: string }> = {
    cover: { title: "Cover", kicker: "Issue No. 27" },
    index: { title: "Contents", kicker: "In this issue" },
    store: { title: "Store", kicker: "Department 01" },
    games: { title: "Games", kicker: "Department 02" },
    library: { title: "Library", kicker: "Department 03" },
    downloads: { title: "Downloads", kicker: "Department 04" },
    settings: { title: "Settings", kicker: "Department 05" },
  };
  return map[r] ?? { title: r, kicker: "" };
};

/** Pick readable text (near-black or white) for a background colour. */
export function onColor(hex: string) {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(full, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.55 ? "#0b0b0c" : "#ffffff";
}

/* ---------- Types ---------- */
export type TransitionStyle = "turn" | "ink" | "shutter" | "crt" | "slice" | "panel";
export type Settings = {
  transition: TransitionStyle;
  speed: "fast" | "normal" | "slow";
  accent: string;
  bandwidth: number; // MB/s
  grain: boolean;
  autoInstall: boolean;
};
export type Owned = { installed: boolean; hours: number; lastPlayed?: number; addedAt: number };
export type DL = { id: string; progress: number; status: "downloading" | "queued" | "paused"; kind: "install" | "update" };
export type Toast = { id: number; title: string; body: string };
export type Receipt = { id: string; gameId: string; at: number; paid: number; card: string; shelf: string };

type Nav = {
  current: Route;
  prev: Route | null;
  dir: 1 | -1;
  origin: { x: number; y: number };
  key: number;
  /** ms to wait before the new page's entrance animations play (lets the transition land first) */
  enter: number;
};

type Ctx = {
  nav: Nav;
  navigate: (to: Route, e?: { clientX: number; clientY: number }) => void;
  step: (d: 1 | -1) => void;
  settings: Settings;
  setSettings: (p: Partial<Settings>) => void;
  library: Record<string, Owned>;
  downloads: DL[];
  speedHistory: number[];
  receipts: Receipt[];
  wishlist: string[];
  toggleWish: (id: string) => void;
  receiptView: string | null;
  openReceipt: (id: string) => void;
  closeReceipt: () => void;
  acquire: (id: string) => void;
  install: (id: string) => void;
  uninstall: (id: string) => void;
  pause: (id: string) => void;
  resume: (id: string) => void;
  cancel: (id: string) => void;
  prioritize: (id: string) => void;
  playing: string | null;
  play: (id: string) => void;
  stop: () => void;
  toasts: Toast[];
  toast: (title: string, body: string) => void;
  resetAll: () => void;
  durationMs: number;
};

const C = createContext<Ctx | null>(null);
export const useApp = () => useContext(C)!;

/* ---------- Defaults ---------- */
const DEFAULT_SETTINGS: Settings = {
  transition: "turn",
  speed: "normal",
  accent: "#3d6bff",
  bandwidth: 250,
  grain: true,
  autoInstall: true,
};

const DAY = 864e5;
const now = Date.now();
const DEFAULT_LIBRARY: Record<string, Owned> = {
  "hollow-crown": { installed: true, hours: 42.5, lastPlayed: now - DAY, addedAt: now - 30 * DAY },
  tidebound: { installed: true, hours: 6.2, lastPlayed: now - 3 * DAY, addedAt: now - 12 * DAY },
  "signal-lost": { installed: false, hours: 9.1, lastPlayed: now - 20 * DAY, addedAt: now - 40 * DAY },
  "paper-kingdoms": { installed: false, hours: 0, addedAt: now - DAY },
};
const DEFAULT_DOWNLOADS: DL[] = [{ id: "paper-kingdoms", progress: 34, status: "downloading", kind: "install" }];

const CARD = "•• 4242";
const DEFAULT_RECEIPTS: Receipt[] = [
  { id: "PS4H7Q", gameId: "paper-kingdoms", at: now - DAY, paid: 30, card: CARD, shelf: "A04" },
  { id: "PS9C2M", gameId: "tidebound", at: now - 12 * DAY, paid: 25, card: CARD, shelf: "A03" },
  { id: "PS2K8X", gameId: "hollow-crown", at: now - 30 * DAY, paid: 60, card: CARD, shelf: "A02" },
  { id: "PS6T3B", gameId: "signal-lost", at: now - 40 * DAY, paid: 40, card: CARD, shelf: "A01" },
];

const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const orderId = () => "PS" + Array.from({ length: 4 }, () => ALPHA[Math.floor(Math.random() * ALPHA.length)]).join("");

const KEY = "pressstart:";
function load<T>(k: string, d: T): T {
  try {
    const v = localStorage.getItem(KEY + k);
    return v ? (JSON.parse(v) as T) : d;
  } catch {
    return d;
  }
}

/* ---------- Provider ---------- */
export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setS] = useState<Settings>(() => ({ ...DEFAULT_SETTINGS, ...load<Partial<Settings>>("settings", {}) }));
  const [library, setLibrary] = useState<Record<string, Owned>>(() => load("library", DEFAULT_LIBRARY));
  const [downloads, setDownloads] = useState<DL[]>(() => load("downloads", DEFAULT_DOWNLOADS));
  const [receipts, setReceipts] = useState<Receipt[]>(() => load("receipts", DEFAULT_RECEIPTS));
  const [wishlist, setWishlist] = useState<string[]>(() => load("wishlist", []));
  const [receiptView, setReceiptView] = useState<string | null>(null);
  const [speedHistory, setSpeedHistory] = useState<number[]>(() => Array(40).fill(0));
  const [nav, setNav] = useState<Nav>({ current: "cover", prev: null, dir: 1, origin: { x: 0, y: 0 }, key: 0, enter: 0 });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [playing, setPlaying] = useState<string | null>(null);
  const playStart = useRef(0);
  const animating = useRef(false);

  const durationMs = settings.speed === "fast" ? 650 : settings.speed === "slow" ? 1600 : 1050;
  const durRef = useRef(durationMs);
  durRef.current = durationMs;

  // persist
  useEffect(() => localStorage.setItem(KEY + "settings", JSON.stringify(settings)), [settings]);
  useEffect(() => localStorage.setItem(KEY + "library", JSON.stringify(library)), [library]);
  useEffect(() => localStorage.setItem(KEY + "downloads", JSON.stringify(downloads)), [downloads]);
  useEffect(() => localStorage.setItem(KEY + "receipts", JSON.stringify(receipts)), [receipts]);
  useEffect(() => localStorage.setItem(KEY + "wishlist", JSON.stringify(wishlist)), [wishlist]);

  // accent theme vars
  useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty("--accent", settings.accent);
    r.style.setProperty("--on-accent", onColor(settings.accent));
  }, [settings.accent]);

  const toast = useCallback((title: string, body: string) => {
    const id = Math.random();
    setToasts((t) => [...t, { id, title, body }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3600);
  }, []);

  /* ---------- navigation ---------- */
  const navigate = useCallback((to: Route, e?: { clientX: number; clientY: number }) => {
    if (animating.current) return;
    setNav((n) => {
      if (n.current === to) return n;
      animating.current = true;
      const dir = ORDER.indexOf(to) >= ORDER.indexOf(n.current) ? 1 : -1;
      return {
        current: to,
        prev: n.current,
        dir,
        origin: e ? { x: e.clientX, y: e.clientY } : { x: window.innerWidth / 2, y: window.innerHeight / 2 },
        key: n.key + 1,
        enter: Math.round(durRef.current * 0.45),
      };
    });
  }, []);

  useEffect(() => {
    if (!nav.prev) return;
    const t = setTimeout(() => {
      setNav((n) => ({ ...n, prev: null }));
      animating.current = false;
    }, durationMs + 40);
    return () => clearTimeout(t);
  }, [nav.key, nav.prev, durationMs]);

  const step = useCallback(
    (d: 1 | -1) => {
      const i = ORDER.indexOf(nav.current);
      const ni = Math.min(ORDER.length - 1, Math.max(0, i + d));
      if (ni !== i) navigate(ORDER[ni]);
    },
    [nav.current, navigate]
  );

  /* ---------- download simulation ---------- */
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const dlRef = useRef(downloads);
  dlRef.current = downloads;

  useEffect(() => {
    const iv = setInterval(() => {
      let finished: string | null = null;
      let speed = 0;
      const list = dlRef.current;
      const active = list.find((d) => d.status === "downloading");
      let next = list;
      if (!active) {
        const q = list.find((d) => d.status === "queued");
        if (q) next = list.map((d) => (d === q ? { ...d, status: "downloading" as const } : d));
      } else {
        const g = getGame(active.id);
        speed = settingsRef.current.bandwidth * (0.75 + Math.random() * 0.35);
        const inc = (speed / 250) * (30 / Math.max(4, g.sizeGB)) * 2.2; // accelerated demo time
        const p = Math.min(100, active.progress + inc);
        if (p >= 100) {
          finished = active.id;
          next = list.filter((d) => d !== active);
        } else {
          next = list.map((d) => (d === active ? { ...d, progress: p } : d));
        }
      }
      if (next !== list) {
        dlRef.current = next;
        setDownloads(next);
      }
      setSpeedHistory((h) => [...h.slice(1), speed]);
      if (finished) {
        const id = finished as string;
        setLibrary((l) => (l[id] ? { ...l, [id]: { ...l[id], installed: true } } : l));
        toast("Ready to play", `${getGame(id).title} finished installing.`);
      }
    }, 500);
    return () => clearInterval(iv);
  }, [toast]);

  const enqueue = (id: string) =>
    setDownloads((list) => {
      if (list.some((d) => d.id === id)) return list;
      const hasActive = list.some((d) => d.status === "downloading");
      return [...list, { id, progress: 0, status: hasActive ? "queued" : "downloading", kind: "install" }];
    });

  /** Purchase: add to shelf, write a receipt, open the pass. */
  const acquire = (id: string) => {
    if (library[id]) return;
    const g = getGame(id);
    const paid = g.price;
    const r: Receipt = {
      id: orderId(),
      gameId: id,
      at: Date.now(),
      paid,
      card: paid === 0 ? "—" : CARD,
      shelf: `A${String(Object.keys(library).length + 1).padStart(2, "0")}`,
    };
    setReceipts((rs) => [r, ...rs]);
    setLibrary((l) => ({ ...l, [id]: { installed: false, hours: 0, addedAt: Date.now() } }));
    setWishlist((w) => w.filter((x) => x !== id));
    if (settings.autoInstall) enqueue(id);
    setReceiptView(r.id);
  };
  const install = (id: string) => {
    enqueue(id);
    toast("Queued", `${getGame(id).title} added to downloads.`);
  };
  const uninstall = (id: string) => {
    setLibrary((l) => ({ ...l, [id]: { ...l[id], installed: false } }));
    toast("Uninstalled", `${getGame(id).title} removed from disk.`);
  };
  const pause = (id: string) => setDownloads((l) => l.map((d) => (d.id === id ? { ...d, status: "paused" } : d)));
  const resume = (id: string) =>
    setDownloads((l) => {
      const hasActive = l.some((d) => d.status === "downloading" && d.id !== id);
      return l.map((d) => (d.id === id ? { ...d, status: hasActive ? "queued" : "downloading" } : d));
    });
  const cancel = (id: string) => setDownloads((l) => l.filter((d) => d.id !== id));
  const prioritize = (id: string) =>
    setDownloads((l) => {
      const target = l.find((d) => d.id === id);
      if (!target) return l;
      const rest = l.filter((d) => d.id !== id).map((d) => (d.status === "downloading" ? { ...d, status: "queued" as const } : d));
      return [{ ...target, status: "downloading" }, ...rest];
    });

  const play = (id: string) => {
    playStart.current = Date.now();
    setPlaying(id);
  };
  const stop = () => {
    if (playing) {
      const hrs = Math.max(0.1, (Date.now() - playStart.current) / 36e5 + 0.4);
      const id = playing;
      setLibrary((l) => ({ ...l, [id]: { ...l[id], hours: +(l[id].hours + hrs).toFixed(1), lastPlayed: Date.now() } }));
    }
    setPlaying(null);
  };

  const toggleWish = (id: string) => {
    const saving = !wishlist.includes(id);
    setWishlist((w) => (w.includes(id) ? w.filter((x) => x !== id) : [...w, id]));
    if (saving) toast("Saved for later", `${getGame(id).title} — find it under Games → Saved.`);
  };

  const setSettings = (p: Partial<Settings>) => setS((s) => ({ ...s, ...p }));
  const openReceipt = (id: string) => setReceiptView(id);
  const closeReceipt = () => setReceiptView(null);

  const resetAll = () => {
    setS(DEFAULT_SETTINGS);
    setLibrary(DEFAULT_LIBRARY);
    setDownloads(DEFAULT_DOWNLOADS);
    setReceipts(DEFAULT_RECEIPTS);
    setWishlist([]);
    setReceiptView(null);
    toast("Fresh issue", "Everything reset to factory print.");
  };

  const value = useMemo<Ctx>(
    () => ({
      nav,
      navigate,
      step,
      settings,
      setSettings,
      library,
      downloads,
      speedHistory,
      receipts,
      wishlist,
      toggleWish,
      receiptView,
      openReceipt,
      closeReceipt,
      acquire,
      install,
      uninstall,
      pause,
      resume,
      cancel,
      prioritize,
      playing,
      play,
      stop,
      toasts,
      toast,
      resetAll,
      durationMs,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [nav, settings, library, downloads, speedHistory, receipts, wishlist, receiptView, playing, toasts, durationMs, step]
  );

  return <C.Provider value={value}>{children}</C.Provider>;
}
