import { useState } from "react";
import type { MouseEvent as RMouseEvent } from "react";
import { useApp } from "../store";
import { fmtPrice, getGame } from "../data/games";
import { Link, cx } from "./ui";
import { BagIcon, DownIcon, HeartIcon, PlayIcon } from "./icons";

const CARD = "#232326";
const stop = (fn: () => void) => (e: RMouseEvent) => {
  e.stopPropagation();
  fn();
};

/** Round "save for later" button that sits on the artwork. */
export function HeartButton({ id, className }: { id: string; className?: string }) {
  const { wishlist, toggleWish } = useApp();
  const on = wishlist.includes(id);
  const [pop, setPop] = useState(0);

  return (
    <button
      onClick={stop(() => {
        setPop((p) => p + 1);
        toggleWish(id);
      })}
      aria-pressed={on}
      aria-label={on ? "Remove from saved" : "Save for later"}
      title={on ? "Saved" : "Save for later"}
      className={cx("grid h-9 w-9 place-items-center rounded-full text-white transition-transform duration-300 hover:scale-110", className || "relative")}
      style={{ background: CARD }}
    >
      <span key={pop} className={cx("grid place-items-center", pop > 0 && "heart-pop", pop > 0 && on && "heart-burst")}>
        <HeartIcon filled={on} className={cx("h-[18px] w-[18px] transition-colors duration-300", on && "text-accent")} />
      </span>
    </button>
  );
}

/**
 * The square action from the reference card, made launcher-aware:
 * bag (buy/get) → download (install) → progress ring (tap to pause/resume) → play.
 */
export function CardAction({ id }: { id: string }) {
  const { library, downloads, acquire, install, play, pause, resume } = useApp();
  const g = getGame(id);
  const owned = library[id];
  const dl = downloads.find((d) => d.id === id);
  const base = "act relative grid h-16 w-16 shrink-0 place-items-center rounded-[22px] transition duration-300 active:scale-95";
  const light = "bg-white text-[#0d0d0d] hover:scale-105 hover:shadow-[0_12px_32px_-12px_rgba(255,255,255,.45)]";

  if (dl) {
    const pct = Math.floor(dl.progress);
    const r = 17;
    const c = 2 * Math.PI * r;
    const label = dl.status === "downloading" ? `Pause download (${pct}%)` : dl.status === "paused" ? "Resume download" : "Queued";
    return (
      <button onClick={stop(() => (dl.status === "downloading" ? pause(id) : resume(id)))} aria-label={label} title={label} className={cx(base, light)}>
        <svg viewBox="0 0 40 40" className="absolute h-11 w-11 -rotate-90">
          <circle cx="20" cy="20" r={r} fill="none" stroke="rgba(0,0,0,.1)" strokeWidth="3" />
          <circle
            cx="20"
            cy="20"
            r={r}
            fill="none"
            stroke="var(--accent)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={c * (1 - dl.progress / 100)}
            style={{ transition: "stroke-dashoffset .5s" }}
          />
        </svg>
        <span className="relative text-[11px] font-semibold tabular-nums">
          {dl.status === "downloading" ? pct : dl.status === "paused" ? <DownIcon className="h-4 w-4" /> : "···"}
        </span>
      </button>
    );
  }

  if (owned?.installed) {
    return (
      <button
        onClick={stop(() => play(id))}
        aria-label={`Play ${g.title}`}
        title="Play"
        className={cx(base, "bg-accent text-on-accent hover:scale-105 hover:shadow-[0_12px_32px_-10px_var(--accent)]")}
      >
        <PlayIcon className="h-6 w-6" />
      </button>
    );
  }

  if (owned) {
    return (
      <button onClick={stop(() => install(id))} aria-label={`Install ${g.title} (${g.sizeGB} GB)`} title={`Install · ${g.sizeGB} GB`} className={cx(base, light)}>
        <DownIcon className="h-[26px] w-[26px]" />
      </button>
    );
  }

  const label = g.price === 0 ? `Get ${g.title} for free` : `Buy ${g.title} for ${fmtPrice(g.price)}`;
  return (
    <button onClick={stop(() => acquire(id))} aria-label={label} title={label} className={cx(base, light)}>
      <BagIcon className="h-[26px] w-[26px]" />
    </button>
  );
}

/** Product card: inset artwork, name, genre, one honest price, one action. */
export function GameCard({ id }: { id: string }) {
  const { library } = useApp();
  const g = getGame(id);
  const owned = !!library[id];

  return (
    <Link
      to={`game:${id}`}
      className="group block rounded-[30px] border border-white/[.05] p-2 font-sans shadow-[0_30px_60px_-34px_rgba(0,0,0,.95)] transition duration-500 ease-[cubic-bezier(.2,.8,.2,1)] hover:-translate-y-1.5 hover:border-white/[.1]"
      style={{ background: CARD }}
    >
      <div className="relative aspect-[10/9] overflow-hidden rounded-[22px] bg-black">
        <img
          src={g.img}
          alt={g.title}
          style={{ objectPosition: g.focus }}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(.2,.8,.2,1)] group-hover:scale-[1.06]"
        />
        <HeartButton id={id} className="absolute right-2 top-2" />
      </div>

      <div className="px-2.5 pt-3.5">
        <div className="truncate text-[21px] leading-tight text-white">{g.title}</div>
        <div className="mt-0.5 truncate text-[15px] text-white/55">{g.genre}</div>
      </div>

      <div className="mt-5 flex items-center justify-between gap-3 pl-2.5">
        <span className={cx("font-medium leading-none tracking-tight tabular-nums", owned ? "text-[28px] text-white/45" : "text-[38px] text-white")}>
          {owned ? "Owned" : fmtPrice(g.price)}
        </span>
        <CardAction id={id} />
      </div>
    </Link>
  );
}
