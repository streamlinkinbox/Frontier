import { Fragment, useEffect, useRef, useState } from "react";
import type { CSSProperties, ElementType, ReactNode, RefObject, MouseEvent as RMouseEvent } from "react";

const cn = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

/** Entrance delay that waits for the page transition to land (reads --enter from the page). */
export const enter = (s = 0): CSSProperties => ({ animationDelay: `calc(var(--enter, 0ms) + ${s}s)` });

/* ---------------------------------------------------------------
   useReveal — fades in [data-reveal] elements as they scroll into
   view. Also watches for elements added later (filters, queues…).
----------------------------------------------------------------*/
export function useReveal(root: RefObject<HTMLElement | null>, dep: unknown, startDelay = 0) {
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      el.querySelectorAll<HTMLElement>("[data-reveal]").forEach((n) => n.setAttribute("data-in", ""));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        let i = 0;
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const t = e.target as HTMLElement;
          t.style.setProperty("--rd", `${Math.min(i++ * 70, 420)}ms`);
          t.setAttribute("data-in", "");
          io.unobserve(t);
        }
      },
      { threshold: 0.08, rootMargin: "0px 0px -4% 0px" }
    );
    const watch = (scope: Element) => {
      if (scope.matches("[data-reveal]:not([data-in])")) io.observe(scope);
      scope.querySelectorAll("[data-reveal]:not([data-in])").forEach((n) => io.observe(n));
    };
    let mo: MutationObserver | null = null;
    const timer = window.setTimeout(() => {
      watch(el);
      mo = new MutationObserver((muts) => {
        for (const m of muts) m.addedNodes.forEach((n) => n instanceof Element && watch(n));
      });
      mo.observe(el, { childList: true, subtree: true });
    }, startDelay);
    return () => {
      clearTimeout(timer);
      io.disconnect();
      mo?.disconnect();
    };
  }, [root, dep, startDelay]);
}

/* ---------------------------------------------------------------
   SplitText — headline that rises word-by-word out of a mask.
----------------------------------------------------------------*/
export function SplitText({
  text,
  as: Tag = "span",
  className,
  delay = 0,
  step = 0.07,
  accentWord,
}: {
  text: string;
  as?: ElementType;
  className?: string;
  delay?: number;
  step?: number;
  accentWord?: string;
}) {
  const words = text.split(" ");
  return (
    <Tag className={className}>
      {words.map((w, i) => (
        <Fragment key={i}>
          <span className="word">
            <span className={w === accentWord ? "text-accent" : undefined} style={enter(delay + i * step)}>
              {w}
            </span>
          </span>
          {i < words.length - 1 ? " " : null}
        </Fragment>
      ))}
    </Tag>
  );
}

/* ---------------------------------------------------------------
   Tilt — pointer-following 3D tilt with optional glare.
----------------------------------------------------------------*/
export function Tilt({
  children,
  className,
  strength = 8,
  scale = 1.02,
  glare,
}: {
  children: ReactNode;
  className?: string;
  strength?: number;
  scale?: number;
  glare?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const onMove = (e: RMouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.style.setProperty("--ry", `${(px - 0.5) * strength * 2}deg`);
    el.style.setProperty("--rx", `${(0.5 - py) * strength * 2}deg`);
    el.style.setProperty("--s", String(scale));
    el.style.setProperty("--gx", `${px * 100}%`);
    el.style.setProperty("--gy", `${py * 100}%`);
    el.classList.add("is-on");
  };
  const leave = () => {
    const el = ref.current;
    if (!el) return;
    el.classList.remove("is-on");
    el.style.setProperty("--ry", "0deg");
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--s", "1");
  };
  return (
    <div ref={ref} onMouseMove={onMove} onMouseLeave={leave} className={cn("tilt", className)}>
      {children}
      {glare && <span className="tilt-glare" aria-hidden />}
    </div>
  );
}

/* ---------------------------------------------------------------
   CountUp — animates to a value when visible, then tweens on change.
----------------------------------------------------------------*/
export function CountUp({ to, decimals = 0, duration = 900, className }: { to: number; decimals?: number; duration?: number; className?: string }) {
  const [v, setV] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const from = useRef(0);
  const seen = useRef(false);
  const raf = useRef(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const animate = () => {
      cancelAnimationFrame(raf.current);
      const start = from.current;
      const t0 = performance.now();
      const tick = (t: number) => {
        const p = Math.min(1, (t - t0) / duration);
        const val = start + (to - start) * (1 - Math.pow(1 - p, 3));
        from.current = val;
        setV(val);
        if (p < 1) raf.current = requestAnimationFrame(tick);
      };
      raf.current = requestAnimationFrame(tick);
    };
    if (seen.current || typeof IntersectionObserver === "undefined") {
      seen.current = true;
      animate();
      return () => cancelAnimationFrame(raf.current);
    }
    const io = new IntersectionObserver(
      (es) => {
        if (es.some((e) => e.isIntersecting)) {
          seen.current = true;
          io.disconnect();
          animate();
        }
      },
      { threshold: 0.3 }
    );
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf.current);
    };
  }, [to, duration]);

  return (
    <span ref={ref} className={className}>
      {v.toFixed(decimals)}
    </span>
  );
}

/* ---------------------------------------------------------------
   Scramble — characters cycle before locking in (receipt numbers).
----------------------------------------------------------------*/
export function Scramble({ text, duration = 800, delay = 0, className }: { text: string; duration?: number; delay?: number; className?: string }) {
  const [out, setOut] = useState(() => text.replace(/\S/g, "·"));
  useEffect(() => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
    let raf = 0;
    const t0 = performance.now() + delay;
    const tick = (t: number) => {
      const p = Math.max(0, Math.min(1, (t - t0) / duration));
      const fixed = Math.floor(p * text.length);
      setOut(
        text
          .split("")
          .map((c, i) => (i < fixed || c === " " ? c : chars[(Math.random() * chars.length) | 0]))
          .join("")
      );
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [text, duration, delay]);
  return <span className={className}>{out}</span>;
}

/* ---------------------------------------------------------------
   Parallax — image drifts slowly as the page scrolls.
----------------------------------------------------------------*/
export function Parallax({
  src,
  alt,
  className,
  imgStyle,
}: {
  src: string;
  alt: string;
  className?: string;
  imgStyle?: CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const scroller = el.closest(".page-scroll") as HTMLElement | null;
    if (!scroller) return;
    const onScroll = () => el.style.setProperty("--py", `${Math.min(scroller.scrollTop, 900) * 0.25}px`);
    onScroll();
    scroller.addEventListener("scroll", onScroll, { passive: true });
    return () => scroller.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div ref={ref} className={cn("overflow-hidden", className)}>
      <img
        src={src}
        alt={alt}
        className="h-full w-full object-cover"
        style={{ transform: "translate3d(0, var(--py, 0px), 0) scale(1.1)", ...imgStyle }}
      />
    </div>
  );
}
