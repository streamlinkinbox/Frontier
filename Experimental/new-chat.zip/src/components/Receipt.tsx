import { useCallback, useEffect, useMemo, useState } from "react";
import type { CSSProperties, ReactNode, SVGProps } from "react";
import { useApp } from "../store";
import type { Receipt, Route } from "../store";
import { CODES, fmtPrice, getGame } from "../data/games";
import { cx, tint } from "./ui";
import { Scramble, Tilt } from "./micro";

const CARD_BG = "#0b0b0c";
const TICKET_BG = "#f2f2f0";

/* ---------------- icons ---------------- */
type IP = SVGProps<SVGSVGElement>;
const stroke = { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
const IDownload = (p: IP) => (
  <svg {...stroke} {...p}>
    <path d="M12 4v11" />
    <path d="m7 10 5 5 5-5" />
    <path d="M5 20h14" />
  </svg>
);
const IShare = (p: IP) => (
  <svg {...stroke} {...p}>
    <path d="M12 3v12" />
    <path d="m8 7 4-4 4 4" />
    <path d="M8 11H6.5A1.5 1.5 0 0 0 5 12.5v7A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5v-7a1.5 1.5 0 0 0-1.5-1.5H16" />
  </svg>
);
const ISearch = (p: IP) => (
  <svg {...stroke} {...p}>
    <circle cx="11" cy="11" r="7.5" />
    <path d="m20.5 20.5-4-4" />
  </svg>
);
const ITicket = (p: IP) => (
  <svg {...stroke} {...p}>
    <path d="M3 7.5A1.5 1.5 0 0 1 4.5 6h15A1.5 1.5 0 0 1 21 7.5V10a2 2 0 0 0 0 4v2.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 16.5V14a2 2 0 0 0 0-4Z" />
    <path d="M9.5 8.5v1M9.5 11.5v1M9.5 14.5v1" />
  </svg>
);
const IHeart = (p: IP) => (
  <svg {...stroke} {...p}>
    <path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20Z" />
  </svg>
);
const IUser = (p: IP) => (
  <svg {...stroke} {...p}>
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="10" r="3" />
    <path d="M6.6 18.2a6.5 6.5 0 0 1 10.8 0" />
  </svg>
);
const IClose = (p: IP) => (
  <svg {...stroke} {...p}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);
const IPad = (p: IP) => (
  <svg viewBox="0 0 24 24" fill="currentColor" fillRule="evenodd" {...p}>
    <path d="M7 7h10a5 5 0 0 1 4.9 6l-.8 4a2.6 2.6 0 0 1-4.5 1.2L14.8 16H9.2l-1.8 2.2A2.6 2.6 0 0 1 2.9 17l-.8-4A5 5 0 0 1 7 7Zm.5 3a.75.75 0 0 0-.75.75V12H5.5a.75.75 0 0 0 0 1.5h1.25v1.25a.75.75 0 0 0 1.5 0V13.5H9.5a.75.75 0 0 0 0-1.5H8.25v-1.25A.75.75 0 0 0 7.5 10Zm8.5.25a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm2 2.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z" />
  </svg>
);

/* ---------------- helpers ---------------- */
const pad2 = (n: number) => String(n).padStart(2, "0");
const fmtDate = (t: number) => {
  const d = new Date(t);
  return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${String(d.getFullYear()).slice(2)}`;
};
const fmtTime = (t: number) => new Date(t).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
const paidLabel = (n: number) => (n === 0 ? "Free" : fmtPrice(n));

function barsFor(seed: string) {
  let h = 2166136261;
  for (const c of seed) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  const rnd = () => {
    h ^= h << 13;
    h ^= h >>> 17;
    h ^= h << 5;
    return ((h >>> 0) % 1000) / 1000;
  };
  return Array.from({ length: 44 }, (_, i) => ({ w: 1 + Math.floor(rnd() * 4), on: i % 2 === 0 }));
}

function Barcode({ seed }: { seed: string }) {
  const bars = useMemo(() => barsFor(seed), [seed]);
  return (
    <div className="flex h-[96px] w-full" role="img" aria-label={`Barcode ${seed}`}>
      {bars.map((b, i) => (
        <span
          key={i}
          className={b.on ? "bar bg-[#0d0d0d]" : undefined}
          style={{ flexGrow: b.w, flexBasis: 0, ["--i" as string]: i } as CSSProperties}
        />
      ))}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <div className="text-[11px] text-black/50">{label}</div>
      <div className="mt-1 truncate text-[16px] font-bold tracking-tight">{value}</div>
    </div>
  );
}

/* ---------------- the ticket ---------------- */
function Ticket({ r }: { r: Receipt }) {
  const g = getGame(r.gameId);
  return (
    <Tilt strength={5} scale={1.01} glare className="mt-4">
      <div className="ticket-print relative rounded-2xl text-[#0d0d0d]" style={{ background: TICKET_BG }}>
        <div className="px-6 pb-6 pt-6">
          <div className="text-[11px] text-black/50">Order number</div>
          <Scramble text={r.id} delay={380} duration={750} className="mt-0.5 block text-[19px] font-bold tracking-[.06em]" />

          <div className="mt-4 flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[38px] font-extrabold leading-none tracking-tight">PSS</div>
              <div className="mt-2 text-[11.5px] text-black/55">Press Start Store</div>
            </div>
            <IPad className="float-x mt-3 h-5 w-5 shrink-0 text-black/20" />
            <div className="min-w-0 text-right">
              <div className="text-[38px] font-extrabold leading-none tracking-tight">{CODES[g.id] ?? "GME"}</div>
              <div className="mt-2 truncate text-[11.5px] text-black/55">{g.title}</div>
            </div>
          </div>

          <div className="my-5 h-px bg-black/10" />

          <div className="grid grid-cols-[1.25fr_1fr_.8fr] gap-y-5">
            <Field label="Time" value={fmtTime(r.at)} />
            <Field label="Paid" value={paidLabel(r.paid)} />
            <Field label="Card" value={r.card} />
            <Field label="Date" value={fmtDate(r.at)} />
            <Field label="Size" value={`${g.sizeGB} GB`} />
            <Field label="Shelf" value={r.shelf} />
          </div>
        </div>

        {/* perforation with notches */}
        <div className="relative h-0">
          <span className="absolute left-0 top-0 h-7 w-7 -translate-x-1/2 -translate-y-1/2 rounded-full" style={{ background: CARD_BG }} />
          <span className="absolute right-0 top-0 h-7 w-7 -translate-y-1/2 translate-x-1/2 rounded-full" style={{ background: CARD_BG }} />
          <span className="absolute left-5 right-5 top-0 border-t-2 border-dotted border-black/30" />
        </div>

        <div className="px-10 pb-6 pt-5">
          <Barcode seed={r.id} />
        </div>
      </div>
    </Tilt>
  );
}

/* ---------------- primary action (live) ---------------- */
function PassAction({ gameId, onGo, onPlay }: { gameId: string; onGo: (r: Route) => void; onPlay: () => void }) {
  const { library, downloads, install } = useApp();
  const dl = downloads.find((d) => d.id === gameId);
  const owned = library[gameId];
  const cls = "relative flex h-12 items-center justify-center gap-2 overflow-hidden rounded-lg text-[15px] font-medium transition active:scale-[.98]";

  if (dl) {
    return (
      <button onClick={() => onGo("downloads")} className={cx(cls, "bg-accent/25 text-white")} title="View downloads">
        <span className="absolute inset-y-0 left-0 bg-accent transition-[width] duration-500" style={{ width: `${dl.progress}%` }} />
        <span className="relative flex items-center gap-2">
          <IDownload className={cx("h-[18px] w-[18px]", dl.status === "downloading" && "animate-bounce")} />
          {dl.status === "downloading" ? `${Math.floor(dl.progress)}%` : dl.status === "queued" ? "Queued" : "Paused"}
        </span>
      </button>
    );
  }
  if (owned?.installed) {
    return (
      <button onClick={onPlay} className={cx(cls, "bg-accent text-on-accent hover:brightness-110")}>
        ▶ Play
      </button>
    );
  }
  return (
    <button onClick={() => install(gameId)} className={cx(cls, "bg-accent text-on-accent hover:brightness-110")}>
      <IDownload className="h-[18px] w-[18px]" /> Download
    </button>
  );
}

/* ---------------- past orders ---------------- */
function Stubs({ current, onPick }: { current: string; onPick: (id: string) => void }) {
  const { receipts } = useApp();
  return (
    <div className="page-scroll -mr-1 mt-4 max-h-[min(470px,58vh)] space-y-3 overflow-y-auto pr-1 pt-1">
      {receipts.map((r, i) => {
        const g = getGame(r.gameId);
        return (
          <button
            key={r.id}
            onClick={() => onPick(r.id)}
            className={cx(
              "stub-in relative flex w-full items-stretch rounded-xl text-left text-[#0d0d0d] transition hover:-translate-y-0.5",
              r.id === current && "ring-2 ring-accent ring-offset-2 ring-offset-[#0b0b0c]"
            )}
            style={{ background: TICKET_BG, ["--i" as string]: i } as CSSProperties}
          >
            <div className="min-w-0 flex-1 px-4 py-3">
              <div className="text-[10px] tracking-wider text-black/45">{r.id}</div>
              <div className="flex items-center gap-2 text-[22px] font-extrabold leading-tight tracking-tight">
                PSS <span className="text-sm text-black/25">→</span> {CODES[g.id] ?? "GME"}
              </div>
              <div className="truncate text-[11px] text-black/55">
                {g.title} · {fmtDate(r.at)}
              </div>
            </div>
            <div className="relative grid w-[86px] shrink-0 place-items-center border-l-2 border-dotted border-black/25">
              <span className="absolute -left-2.5 -top-2.5 h-5 w-5 rounded-full" style={{ background: CARD_BG }} />
              <span className="absolute -bottom-2.5 -left-2.5 h-5 w-5 rounded-full" style={{ background: CARD_BG }} />
              <span className="text-[13px] font-bold">{paidLabel(r.paid)}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function NavBtn({ label, active, onClick, children }: { label: string; active?: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cx(
        "grid h-11 w-11 place-items-center rounded-full transition [&>svg]:h-[23px] [&>svg]:w-[23px]",
        active ? "text-white" : "text-white/40 hover:bg-white/5 hover:text-white"
      )}
    >
      {children}
    </button>
  );
}

/* ---------------- modal ---------------- */
export function ReceiptModal() {
  const { receiptView, receipts, closeReceipt, openReceipt, navigate, play, toast } = useApp();
  const [tab, setTab] = useState<"pass" | "all">("pass");
  const [closing, setClosing] = useState(false);
  const r = receipts.find((x) => x.id === receiptView) ?? null;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const fresh = useMemo(() => !!r && Date.now() - r.at < 15000, [receiptView]);

  useEffect(() => {
    if (receiptView) {
      setTab("pass");
      setClosing(false);
    }
  }, [receiptView]);

  const requestClose = useCallback(() => {
    setClosing(true);
    window.setTimeout(() => {
      closeReceipt();
      setClosing(false);
    }, 280);
  }, [closeReceipt]);

  useEffect(() => {
    if (!receiptView) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && requestClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [receiptView, requestClose]);

  if (!r) return null;
  const g = getGame(r.gameId);

  const go = (to: Route) => {
    requestClose();
    navigate(to);
  };
  const share = async () => {
    const text = `${g.title} — order ${r.id} · ${paidLabel(r.paid)} · Press Start`;
    try {
      if (navigator.share) {
        await navigator.share({ title: "Press Start receipt", text });
        return;
      }
      await navigator.clipboard.writeText(text);
      toast("Copied", "Receipt details copied to clipboard.");
    } catch {
      /* share sheet dismissed */
    }
  };

  return (
    <div className="fixed inset-0 z-[110] overflow-y-auto" role="dialog" aria-modal="true" aria-label="Purchase receipt">
      <div className={cx("fixed inset-0 bg-black/75 backdrop-blur-md", closing ? "fade-out" : "fade-in")} onClick={requestClose} />

      <div className="pointer-events-none relative flex min-h-full items-center justify-center p-4 py-10">
        <div
          className={cx(
            "pointer-events-auto relative w-full max-w-[372px] rounded-[30px] border border-white/10 px-5 pb-4 pt-6 font-sans text-white shadow-[0_40px_120px_-30px_rgba(0,0,0,.95)]",
            closing ? "receipt-out" : "receipt-in"
          )}
          style={{ background: CARD_BG, ...tint(g.color) }}
        >
          {/* tabs */}
          <div className="flex justify-center">
            <div className="relative inline-grid grid-cols-2 text-[12.5px] font-bold uppercase">
              <span
                className="absolute inset-y-0 left-0 w-1/2 rounded-lg bg-accent transition-transform duration-500 ease-[cubic-bezier(.7,0,.2,1)]"
                style={{ transform: tab === "all" ? "translateX(100%)" : "none" }}
              />
              <button onClick={() => setTab("pass")} className={cx("relative px-4 py-2.5 transition-colors duration-300", tab === "pass" ? "text-on-accent" : "text-white/85 hover:text-white")}>
                Your pass
              </button>
              <button onClick={() => setTab("all")} className={cx("relative px-4 py-2.5 transition-colors duration-300", tab === "all" ? "text-on-accent" : "text-white/85 hover:text-white")}>
                All orders
              </button>
            </div>
          </div>
          <button
            onClick={requestClose}
            aria-label="Close receipt"
            className="absolute right-4 top-5 grid h-8 w-8 place-items-center rounded-full text-white/45 transition hover:bg-white/10 hover:text-white"
          >
            <IClose className="h-4 w-4" />
          </button>

          <h2 className="mt-7 flex items-center gap-2 text-[19px] font-semibold tracking-tight">
            {tab === "all" ? "Your orders" : fresh ? "Purchase complete" : "Your entry pass"}
            {tab === "pass" && fresh && (
              <span className="pop-in grid h-5 w-5 place-items-center rounded-full bg-accent text-[11px] text-on-accent">✓</span>
            )}
          </h2>

          {tab === "pass" ? (
            <div key={r.id}>
              <Ticket r={r} />
              <div className="mt-7 grid grid-cols-2 gap-3">
                <PassAction
                  gameId={g.id}
                  onGo={go}
                  onPlay={() => {
                    requestClose();
                    play(g.id);
                  }}
                />
                <button
                  onClick={share}
                  className="flex h-12 items-center justify-center gap-2 rounded-lg border border-white/80 text-[15px] font-medium transition hover:bg-white hover:text-black active:scale-[.98]"
                >
                  <IShare className="h-[18px] w-[18px]" /> Share
                </button>
              </div>
            </div>
          ) : (
            <Stubs
              current={r.id}
              onPick={(id) => {
                openReceipt(id);
                setTab("pass");
              }}
            />
          )}

          <nav className="mt-7 flex items-center justify-around">
            <NavBtn label="Browse games" onClick={() => go("games")}>
              <ISearch />
            </NavBtn>
            <NavBtn label="Orders" active onClick={() => setTab(tab === "all" ? "pass" : "all")}>
              <ITicket />
            </NavBtn>
            <NavBtn label="Library" onClick={() => go("library")}>
              <IHeart />
            </NavBtn>
            <NavBtn label="Settings" onClick={() => go("settings")}>
              <IUser />
            </NavBtn>
          </nav>
        </div>
      </div>
    </div>
  );
}
