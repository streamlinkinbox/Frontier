import { useEffect, useRef, useState } from "react";
import type { CSSProperties, HTMLAttributes, ReactNode } from "react";
import { useApp, pageNo, onColor } from "../store";
import type { Route } from "../store";
import { fmtPrice, getGame } from "../data/games";
import { SplitText, enter } from "./micro";
import { BagIcon, DownIcon, PlayIcon } from "./icons";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

/** Scope the accent colour (and readable text on it) to an element. */
export const tint = (color: string) =>
  ({ ["--accent" as string]: color, ["--on-accent" as string]: onColor(color) }) as CSSProperties;

/** Context-aware primary action: Buy / Get / Install / Downloading / Play. The price always sits beside it, so it is never repeated here. */
export function GameAction({ id, size = "md", className }: { id: string; size?: "sm" | "md" | "lg"; className?: string }) {
  const { library, downloads, acquire, install, play, resume } = useApp();
  const g = getGame(id);
  const owned = library[id];
  const dl = downloads.find((d) => d.id === id);
  const pad = size === "lg" ? "h-14 px-7 text-[12.5px]" : size === "sm" ? "h-8 px-3 text-[10px]" : "h-11 px-5 text-[11px]";
  const base = cx(
    "act relative inline-flex items-center justify-center gap-2 overflow-hidden whitespace-nowrap font-mono font-semibold uppercase tracking-[.18em] transition duration-300 active:scale-[.97]",
    pad,
    className
  );

  if (dl) {
    return (
      <button
        onClick={(e) => {
          e.stopPropagation();
          if (dl.status === "paused") resume(id);
        }}
        className={cx(base, "min-w-[8.5rem] bg-white/[.07] text-ink")}
      >
        <span
          className={cx("absolute inset-y-0 left-0 bg-accent transition-[width] duration-500", dl.status === "downloading" && "stripes")}
          style={{ width: `${dl.progress}%` }}
        />
        <span className="relative">
          {dl.status === "paused" ? "Paused · Resume" : dl.status === "queued" ? "Queued" : `${Math.floor(dl.progress)}%`}
        </span>
      </button>
    );
  }
  if (owned?.installed) {
    return (
      <button
        onClick={(e) => {
          e.stopPropagation();
          play(id);
        }}
        className={cx(base, "bg-accent text-on-accent hover:-translate-y-0.5 hover:shadow-[0_14px_40px_-12px_var(--accent)]")}
      >
        <PlayIcon className="h-4 w-4" /> {size === "sm" ? "Play" : "Press Start"}
      </button>
    );
  }
  if (owned) {
    return (
      <button
        onClick={(e) => {
          e.stopPropagation();
          install(id);
        }}
        className={cx(base, "border border-white/20 text-ink hover:border-white/60 hover:bg-white/5")}
      >
        <DownIcon className="h-4 w-4" /> Install{size !== "sm" && ` · ${g.sizeGB} GB`}
      </button>
    );
  }
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        acquire(id);
      }}
      aria-label={g.price === 0 ? `Get ${g.title} for free` : `Buy ${g.title} for ${fmtPrice(g.price)}`}
      className={cx(base, "bg-ink text-paper hover:bg-accent hover:text-on-accent")}
    >
      <BagIcon className="h-4 w-4" /> {g.price === 0 ? "Get" : "Buy"}
    </button>
  );
}

export function Stars({ value, className }: { value: number; className?: string }) {
  return (
    <span className={cx("inline-flex items-center gap-0.5 font-mono", className)}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} className={i <= Math.round(value) ? "text-accent" : "text-ink/20"}>
          ★
        </span>
      ))}
      <span className="ml-1.5 text-xs text-ink/50">{value.toFixed(1)}</span>
    </span>
  );
}

/**
 * Scrollable page with a reading-progress hairline under the header.
 * Sticky offsets are measured from the scroll container's padding edge, so the
 * hairline uses top-0 on padded pages and top-14 on `flush` (full-bleed) pages.
 */
export function PageShell({ children, className, style, flush }: { children: ReactNode; className?: string; style?: CSSProperties; flush?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [prog, setProg] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onScroll = () => {
      const max = el.scrollHeight - el.clientHeight;
      setProg(max > 0 ? el.scrollTop / max : 0);
    };
    onScroll();
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div ref={ref} className={cx("page-scroll absolute inset-0 overflow-y-auto overflow-x-hidden bg-paper pb-28 text-ink", flush ? "pt-0" : "pt-14", className)} style={style}>
      <div className={cx("sticky z-40 h-0", flush ? "top-14" : "top-0")}>
        <div className="h-[2px] origin-left bg-accent transition-transform duration-150" style={{ transform: `scaleX(${prog})` }} />
      </div>
      {children}
    </div>
  );
}

export function SectionHead({ kicker, title, deck, route }: { kicker: string; title: string; deck?: string; route: Route }) {
  return (
    <header className="px-6 md:px-12 lg:px-16 pt-10 md:pt-16 pb-10 md:pb-14">
      <div className="rise flex items-center justify-between font-mono text-[10.5px] uppercase tracking-[.3em]" style={enter(0)}>
        <span className="text-accent">{kicker}</span>
        <span className="text-ink/35">p.{pageNo(route)}</span>
      </div>
      <SplitText as="h1" text={title} delay={0.08} step={0.07} className="mt-3 font-display uppercase leading-[.85] tracking-tight text-[17vw] md:text-[8.5vw]" />
      {deck && (
        <p className="rise mt-4 max-w-xl font-serif text-lg italic text-ink/50 md:text-xl" style={enter(0.3)}>
          {deck}
        </p>
      )}
    </header>
  );
}

type DivProps = Omit<HTMLAttributes<HTMLDivElement>, "className" | "style" | "children">;

export function Link({ to, children, className, style, ...rest }: { to: Route; children: ReactNode; className?: string; style?: CSSProperties } & DivProps) {
  const { navigate } = useApp();
  return (
    <div
      role="link"
      tabIndex={0}
      onClick={(e) => navigate(to, e)}
      onKeyDown={(e) => {
        if (e.key === "Enter" && e.target === e.currentTarget) {
          const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
          navigate(to, { clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 });
        }
      }}
      className={cx("cursor-pointer text-left outline-none focus-visible:ring-1 focus-visible:ring-accent", className)}
      style={style}
      {...rest}
    >
      {children}
    </div>
  );
}

export function Kicker({ children, className, style, ...rest }: { children: ReactNode; className?: string; style?: CSSProperties } & DivProps) {
  return (
    <div className={cx("font-mono text-[10.5px] uppercase tracking-[.28em]", className)} style={style} {...rest}>
      {children}
    </div>
  );
}
