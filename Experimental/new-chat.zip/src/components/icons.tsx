import type { SVGProps } from "react";

type IP = SVGProps<SVGSVGElement>;

const line = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

/** Shopping bag with an up-arrow (the arrow nudges up on hover via .act). */
export const BagIcon = (p: IP) => (
  <svg {...line} {...p}>
    <path d="M9 8V6.6a3 3 0 0 1 6 0V8" />
    <path d="M13.5 20.5H7.3a1.6 1.6 0 0 1-1.6-1.43L4.8 9.77A1.6 1.6 0 0 1 6.4 8h11.2a1.6 1.6 0 0 1 1.6 1.77l-.4 3.73" />
    <g className="ico-up">
      <path d="M18 22v-6.5" />
      <path d="m15.5 18 2.5-2.5 2.5 2.5" />
    </g>
  </svg>
);

export const DownIcon = (p: IP) => (
  <svg {...line} {...p}>
    <g className="ico-down">
      <path d="M12 4v10.5" />
      <path d="m7.5 10.5 4.5 4.5 4.5-4.5" />
    </g>
    <path d="M5 20h14" />
  </svg>
);

export const PlayIcon = (p: IP) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path className="ico-play" d="M8 5.6v12.8a1 1 0 0 0 1.52.85l10.2-6.4a1 1 0 0 0 0-1.7L9.52 4.75A1 1 0 0 0 8 5.6Z" />
  </svg>
);

export const HeartIcon = ({ filled, ...p }: IP & { filled?: boolean }) => (
  <svg {...line} fill={filled ? "currentColor" : "none"} {...p}>
    <path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20Z" />
  </svg>
);
