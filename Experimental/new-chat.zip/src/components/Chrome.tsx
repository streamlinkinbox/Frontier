import { useEffect, useState } from "react";
import { useApp, ORDER, pageNo, routeMeta } from "../store";
import { getGame } from "../data/games";
import { cx, tint } from "./ui";

const TABS = [
  ["index", "Contents"],
  ["store", "Store"],
  ["games", "Games"],
  ["library", "Library"],
  ["downloads", "Downloads"],
  ["settings", "Settings"],
] as const;

function Ring({ p }: { p: number }) {
  const r = 8;
  const c = 2 * Math.PI * r;
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" className="-rotate-90">
      <circle cx="11" cy="11" r={r} fill="none" stroke="currentColor" strokeOpacity=".15" strokeWidth="2" />
      <circle
        cx="11"
        cy="11"
        r={r}
        fill="none"
        stroke="var(--accent)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - p / 100)}
        style={{ transition: "stroke-dashoffset .5s" }}
      />
    </svg>
  );
}

export function Header() {
  const { nav, navigate, downloads } = useApp();
  const cur = nav.current;
  if (cur === "cover") return null;
  const active = downloads.find((d) => d.status === "downloading");
  const section = cur.startsWith("game:") ? "games" : cur;

  return (
    <header className="fixed inset-x-0 top-0 z-50 flex h-14 items-center gap-6 bg-paper/75 px-5 text-ink backdrop-blur-xl md:px-8">
      <button onClick={(e) => navigate("cover", e)} className="group flex items-center gap-2 font-display text-xl tracking-tight" title="Back to cover">
        <span className="logo-mark grid h-5 w-5 place-items-center bg-accent text-[9px] text-on-accent">▶</span>
        <span>PRESS START</span>
      </button>

      <nav className="mx-auto hidden items-center gap-1 md:flex">
        {TABS.map(([r, label]) => (
          <button
            key={r}
            onClick={(e) => navigate(r, e)}
            className={cx(
              "relative px-3 py-2 font-mono text-[10.5px] uppercase tracking-[.22em] transition-colors duration-300",
              section === r ? "text-ink" : "text-ink/40 hover:text-ink"
            )}
          >
            {label}
            <span
              className={cx(
                "absolute bottom-0.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-accent transition-transform duration-300",
                section === r ? "scale-100" : "scale-0"
              )}
            />
          </button>
        ))}
      </nav>

      <div className="ml-auto flex items-center gap-3 md:ml-0">
        {active && (
          <button
            onClick={(e) => navigate("downloads", e)}
            className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-ink/60 transition hover:text-ink"
            title={`${getGame(active.id).title} — ${Math.floor(active.progress)}%`}
          >
            <Ring p={active.progress} />
            <span className="hidden tabular-nums lg:inline">{Math.floor(active.progress)}%</span>
          </button>
        )}
        <button
          onClick={(e) => navigate("index", e)}
          className="border border-white/15 px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-[.22em] text-ink/70 md:hidden"
        >
          Index
        </button>
      </div>
    </header>
  );
}

/** Floating page control: ← 04 Store → (tap the number to jump anywhere) */
export function Footer() {
  const { nav, navigate, step } = useApp();
  const cur = nav.current;
  if (cur === "cover") return null;
  const i = ORDER.indexOf(cur);
  const prev = ORDER[i - 1];
  const next = ORDER[i + 1];

  const arrow =
    "grid h-9 w-9 place-items-center rounded-full text-ink/60 transition hover:bg-white/10 hover:text-ink disabled:pointer-events-none disabled:opacity-20";

  return (
    <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2">
      <div className="flex items-center gap-1 rounded-full border border-white/10 bg-[#141417]/85 p-1 shadow-[0_20px_50px_-20px_rgba(0,0,0,.9)] backdrop-blur-xl">
        <button disabled={!prev} onClick={() => step(-1)} className={arrow} title={prev ? `Previous: ${routeMeta(prev).title} (←)` : undefined}>
          ←
        </button>
        <label className="relative flex min-w-[8.5rem] cursor-pointer items-center justify-center gap-2.5 px-2">
          <span key={nav.key} className="tick font-display text-lg leading-none text-ink">
            {pageNo(cur)}
          </span>
          <span className="max-w-[9rem] truncate font-mono text-[10px] uppercase tracking-[.2em] text-ink/50">{routeMeta(cur).title}</span>
          <select
            aria-label="Jump to page"
            value={cur}
            onChange={(e) => navigate(e.target.value)}
            className="absolute inset-0 cursor-pointer opacity-0"
          >
            {ORDER.map((r) => (
              <option key={r} value={r}>
                {pageNo(r)} — {routeMeta(r).title}
              </option>
            ))}
          </select>
        </label>
        <button disabled={!next} onClick={() => step(1)} className={arrow} title={next ? `Next: ${routeMeta(next).title} (→)` : undefined}>
          →
        </button>
      </div>
    </div>
  );
}

export function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="pointer-events-none fixed right-4 top-[4.25rem] z-[120] flex flex-col items-end gap-2">
      {toasts.map((t) => (
        <div key={t.id} className="toast-drop max-w-xs border border-white/10 border-l-2 border-l-accent bg-[#18181b]/95 px-4 py-3 shadow-2xl backdrop-blur">
          <div className="font-display text-lg uppercase leading-none text-ink">{t.title}</div>
          <div className="mt-1 font-serif text-sm italic text-ink/60">{t.body}</div>
        </div>
      ))}
    </div>
  );
}

export function LaunchOverlay() {
  const { playing, stop } = useApp();
  const [phase, setPhase] = useState<"loading" | "playing">("loading");
  const [secs, setSecs] = useState(0);

  useEffect(() => {
    if (!playing) return;
    setPhase("loading");
    setSecs(0);
    const t = setTimeout(() => setPhase("playing"), 2600);
    const iv = setInterval(() => setSecs((s) => s + 1), 1000);
    return () => {
      clearTimeout(t);
      clearInterval(iv);
    };
  }, [playing]);

  if (!playing) return null;
  const g = getGame(playing);
  const mm = String(Math.floor(secs / 60)).padStart(2, "0");
  const ss = String(secs % 60).padStart(2, "0");

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden bg-black text-white" style={tint(g.color)}>
      <img
        src={g.img}
        alt=""
        style={{ objectPosition: g.focus, transition: "transform 20s linear, filter 1.2s", transform: phase === "playing" ? "scale(1.25)" : "scale(1.05)" }}
        className={cx("absolute inset-0 h-full w-full object-cover", phase === "loading" && "blur-sm brightness-50")}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/60" />

      <div className="relative flex h-full flex-col justify-between p-6 md:p-12">
        <div className="flex justify-between font-mono text-[11px] uppercase tracking-[.3em] text-white/70">
          <span>Press Start · Launcher</span>
          <span>{phase === "loading" ? "Booting…" : `Session ${mm}:${ss}`}</span>
        </div>

        <div>
          <div className="rise mb-3 flex items-center gap-3 font-mono text-xs uppercase tracking-[.4em]">
            <span className="live-dot text-accent">●</span>
            {phase === "loading" ? "Now loading" : "Now playing"}
          </div>
          <div className="rise shimmer font-display text-[20vw] uppercase leading-[.8] md:text-[13vw]" style={{ animationDelay: ".1s" }}>
            {g.title}
          </div>
          <p className="rise mt-3 font-serif text-xl italic text-white/85 md:text-2xl" style={{ animationDelay: ".2s" }}>
            {g.tagline}
          </p>
          {phase === "loading" && (
            <div className="mt-8 h-px max-w-xl overflow-hidden bg-white/20">
              <div className="h-full bg-white" style={{ animation: "loadbar 2.6s cubic-bezier(.6,0,.3,1) forwards" }} />
            </div>
          )}
        </div>

        <div className="flex items-end justify-between">
          <div className="font-mono text-[10px] uppercase tracking-widest text-white/50">Esc to return to the magazine</div>
          <button onClick={stop} className="bg-white px-5 py-3 font-mono text-xs uppercase tracking-widest text-black transition hover:bg-accent hover:text-on-accent">
            ✕ Quit to issue
          </button>
        </div>
      </div>
    </div>
  );
}
