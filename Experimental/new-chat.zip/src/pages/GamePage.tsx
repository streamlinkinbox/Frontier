import { useApp, pageNo } from "../store";
import { GAMES, fmtPrice, getGame } from "../data/games";
import { GameAction, Kicker, Link, PageShell, Stars, tint } from "../components/ui";
import { Parallax, SplitText, enter } from "../components/micro";

export default function GamePage({ id }: { id: string }) {
  const g = getGame(id);
  const { library, downloads, uninstall, receipts, openReceipt } = useApp();
  const idx = GAMES.findIndex((x) => x.id === id);
  const next = GAMES[(idx + 1) % GAMES.length];
  const prev = GAMES[(idx - 1 + GAMES.length) % GAMES.length];
  const owned = library[id];
  const dl = downloads.find((d) => d.id === id);
  const receipt = receipts.find((r) => r.gameId === id);

  const facts: [string, string][] = [
    ["Developer", g.developer],
    ["Released", String(g.year)],
    ["Players", g.players],
    ["Install size", `${g.sizeGB} GB`],
    ["Status", dl ? `Downloading · ${Math.floor(dl.progress)}%` : owned?.installed ? "Installed" : owned ? "In library" : fmtPrice(g.price)],
  ];
  if (owned) facts.push(["Played", `${owned.hours} h`]);

  return (
    <PageShell flush style={tint(g.color)}>
      {/* hero */}
      <section className="relative h-[100svh] min-h-[560px] overflow-hidden bg-black text-white">
        <Parallax src={g.img} alt={g.title} className="absolute inset-0" imgStyle={{ objectPosition: g.focus }} />
        <div className="absolute inset-0 bg-gradient-to-t from-paper via-black/25 to-black/45" />
        <div className="absolute inset-x-0 bottom-0 px-6 pb-28 md:px-12 md:pb-24 lg:px-16">
          <Kicker className="rise text-white/70" style={enter(0)}>
            <span className="text-accent">Feature</span> · {g.genre} · p.{pageNo(`game:${id}`)}
          </Kicker>
          <SplitText as="h1" text={g.title} delay={0.08} step={0.08} className="mt-3 font-display text-[21vw] uppercase leading-[.82] tracking-tight md:text-[12vw]" />
          <div className="mt-6 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <p className="rise max-w-2xl font-serif text-xl italic text-white/80 md:text-2xl" style={enter(0.3)}>
              {g.deck}
            </p>
            <div className="rise flex shrink-0 items-center gap-5" style={enter(0.4)}>
              {!owned && <div className="font-display text-4xl">{fmtPrice(g.price)}</div>}
              <GameAction id={id} size="lg" />
            </div>
          </div>
        </div>
      </section>

      {/* article + facts */}
      <section className="grid gap-14 px-6 py-16 md:px-12 md:py-24 lg:grid-cols-12 lg:gap-20 lg:px-16">
        <article className="space-y-7 font-serif text-lg leading-[1.75] text-ink/80 md:text-xl lg:col-span-7">
          <div data-reveal className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-white/10 pb-6 font-mono text-[10.5px] uppercase tracking-[.25em] text-ink/40">
            <span>
              By <span className="text-ink">{g.author}</span>
            </span>
            <span>6 min read</span>
            <Stars value={g.rating} />
          </div>
          <p data-reveal className="dropcap">
            {g.article[0]}
          </p>
          <blockquote data-reveal="blur" className="border-y border-white/10 py-10">
            <span className="block font-display text-4xl uppercase leading-[.95] text-ink md:text-5xl">“{g.quote}”</span>
          </blockquote>
          <p data-reveal>{g.article[1]}</p>
          <p data-reveal>{g.article[2]}</p>
        </article>

        <aside className="lg:col-span-5">
          <div data-reveal="right" className="lg:sticky lg:top-24">
            <div className="border border-white/[.07] bg-paper2 p-6 md:p-8">
              <Kicker className="text-ink/40">At a glance</Kicker>
              <dl className="mt-4 divide-y divide-white/[.07] font-mono text-[13px]">
                {facts.map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-6 py-3">
                    <dt className="text-[10.5px] uppercase tracking-[.2em] text-ink/40">{k}</dt>
                    <dd className="text-right text-ink/90">{v}</dd>
                  </div>
                ))}
              </dl>
              <ul className="mt-6 space-y-2 font-serif text-[15px] text-ink/70">
                {g.features.map((f) => (
                  <li key={f} className="flex items-center gap-3">
                    <span className="h-1 w-1 shrink-0 rounded-full bg-accent" />
                    {f}
                  </li>
                ))}
              </ul>
              <GameAction id={id} className="mt-8 w-full" />
              {(receipt || owned?.installed) && (
                <div className="mt-4 flex justify-between font-mono text-[10px] uppercase tracking-[.2em] text-ink/40">
                  {receipt ? (
                    <button onClick={() => openReceipt(receipt.id)} className="transition hover:text-accent">
                      View receipt
                    </button>
                  ) : (
                    <span />
                  )}
                  {owned?.installed && (
                    <button onClick={() => uninstall(id)} className="transition hover:text-accent">
                      Uninstall
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </aside>
      </section>

      {/* next / previous feature */}
      <section data-reveal className="grid border-t border-white/10 md:grid-cols-2">
        {[
          { g: prev, label: `← Previous · p.${pageNo(`game:${prev.id}`)}`, align: "" },
          { g: next, label: `Next · p.${pageNo(`game:${next.id}`)} →`, align: "md:text-right" },
        ].map(({ g: x, label, align }, i) => (
          <Link
            key={x.id}
            to={`game:${x.id}`}
            className={`group relative overflow-hidden p-8 md:p-12 ${align} ${i === 0 ? "border-b border-white/10 md:border-b-0 md:border-r" : ""}`}
          >
            <img src={x.img} alt="" className="absolute inset-0 h-full w-full object-cover opacity-0 transition duration-700 group-hover:scale-105 group-hover:opacity-40" />
            <div className="relative">
              <Kicker className="text-ink/40">{label}</Kicker>
              <div className="mt-2 font-display text-5xl uppercase md:text-6xl">{x.title}</div>
            </div>
          </Link>
        ))}
      </section>
    </PageShell>
  );
}
