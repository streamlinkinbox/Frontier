import { useApp, pageNo } from "../store";
import { GAMES, fmtPrice } from "../data/games";
import { GameAction, Kicker, Link, PageShell, SectionHead, Stars } from "../components/ui";
import { GameCard } from "../components/GameCard";
import { CountUp, SplitText, enter } from "../components/micro";

const PICKS = ["signal-lost", "solar-bloom", "paper-kingdoms", "ironclad-9"];

export default function Store() {
  const { library } = useApp();
  const hero = GAMES[0];
  const chart = [...GAMES].sort((a, b) => b.rating - a.rating).slice(0, 5);

  return (
    <PageShell>
      <SectionHead route="store" kicker="Department 01" title="The Store" deck="Hand-picked, honestly reviewed, one tap from your shelf." />

      {/* cover feature */}
      <section className="grid items-end gap-8 px-6 md:px-12 lg:grid-cols-12 lg:gap-12 lg:px-16">
        <div className="rise lg:col-span-8" style={enter(0.2)}>
          <Link to={`game:${hero.id}`} className="group relative block aspect-[16/10] overflow-hidden bg-black">
            <img
              src={hero.img}
              alt={hero.title}
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1.6s] ease-out group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 md:p-10">
              <Kicker className="flex items-center gap-2 text-white/70">
                <span className="live-dot text-accent">●</span> Cover feature · p.{pageNo(`game:${hero.id}`)}
              </Kicker>
              <SplitText as="div" text={hero.title} delay={0.3} className="mt-3 font-display text-6xl uppercase leading-[.85] text-white md:text-8xl" />
            </div>
          </Link>
        </div>

        <div className="rise pb-1 lg:col-span-4" style={enter(0.35)}>
          <p className="font-serif text-2xl italic leading-snug text-ink/90 md:text-3xl">“{hero.quote}”</p>
          <div className="mt-3 font-mono text-[10.5px] uppercase tracking-[.2em] text-ink/35">— {hero.author}</div>
          <div className="mt-10 font-display text-5xl">{library[hero.id] ? "Owned" : fmtPrice(hero.price)}</div>
          <Stars value={hero.rating} className="mt-2 text-sm" />
          <GameAction id={hero.id} size="lg" className="mt-6 w-full" />
        </div>
      </section>

      {/* editor's picks */}
      <section className="mt-28 px-6 md:px-12 lg:px-16">
        <div data-reveal className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-4xl uppercase md:text-5xl">Editor's picks</h2>
          <Link to="games" className="group font-mono text-[10.5px] uppercase tracking-[.2em] text-ink/45 transition hover:text-ink">
            All games <span className="inline-block transition-transform duration-300 group-hover:translate-x-1">→</span>
          </Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {PICKS.map((id) => (
            <div key={id} data-reveal>
              <GameCard id={id} />
            </div>
          ))}
        </div>
      </section>

      {/* chart */}
      <section className="mt-28 px-6 md:px-12 lg:px-16">
        <div data-reveal className="mb-4 flex items-end justify-between">
          <h2 className="font-display text-4xl uppercase md:text-5xl">The chart</h2>
          <Kicker className="text-ink/35">Top rated</Kicker>
        </div>
        <ol>
          {chart.map((g, i) => (
            <li key={g.id} data-reveal="left">
              <Link
                to={`game:${g.id}`}
                className="group grid grid-cols-[3rem_1fr_auto_1.5rem] items-center gap-4 border-t border-white/[.07] py-4 md:grid-cols-[4rem_1fr_6rem_6rem_1.5rem]"
              >
                <span className="font-display text-4xl text-ink/20 transition-colors duration-300 group-hover:text-accent">{i + 1}</span>
                <span className="min-w-0">
                  <span className="block truncate font-display text-2xl uppercase leading-none transition-transform duration-300 group-hover:translate-x-1 md:text-3xl">
                    {g.title}
                  </span>
                  <span className="mt-1 block font-mono text-[10px] uppercase tracking-[.2em] text-ink/35">{g.genre}</span>
                </span>
                <span className="hidden font-mono text-sm text-ink/50 md:block">
                  ★ <CountUp to={g.rating} decimals={1} />
                </span>
                <span className={library[g.id] ? "text-right text-base text-ink/40" : "text-right text-xl font-medium tracking-tight"}>
                  {library[g.id] ? "Owned" : fmtPrice(g.price)}
                </span>
                <span className="text-right text-ink/25 transition duration-300 group-hover:translate-x-1 group-hover:text-ink">→</span>
              </Link>
            </li>
          ))}
        </ol>
      </section>
    </PageShell>
  );
}
