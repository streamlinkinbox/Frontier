import { useEffect, useRef } from "react";
import cover from "../assets/raw/cover.jpg";
import { useApp, pageNo } from "../store";
import { GAMES } from "../data/games";
import { Link } from "../components/ui";
import { SplitText, enter } from "../components/micro";

export default function Cover() {
  const { navigate } = useApp();
  const imgRef = useRef<HTMLImageElement>(null);
  const lines = [GAMES[1], GAMES[0], GAMES[3]];

  // gentle pointer parallax on the cover photo
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const el = imgRef.current;
      if (!el) return;
      el.style.setProperty("--tx", `${(e.clientX / window.innerWidth - 0.5) * -16}px`);
      el.style.setProperty("--ty", `${(e.clientY / window.innerHeight - 0.5) * -10}px`);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <div className="absolute inset-0 select-none overflow-hidden bg-black text-[#f1efe9]">
      <img
        ref={imgRef}
        src={cover}
        alt="Cover star in a chrome visor"
        className="absolute inset-0 h-full w-full object-cover object-[50%_30%] md:object-contain md:object-right-bottom"
        style={{ transform: "translate3d(var(--tx, 0px), var(--ty, 0px), 0) scale(1.06)", transition: "transform 1s cubic-bezier(.2,.8,.2,1)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-black/50" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/30 to-transparent" />

      {/* folio */}
      <div className="relative z-10 flex items-center justify-between px-6 pt-6 font-mono text-[10px] uppercase tracking-[.3em] text-white/50 md:px-12 md:text-[11px]">
        <span className="rise" style={enter(0.05)}>
          No. 27 — Spring 2026
        </span>
        <span className="rise hidden sm:inline" style={enter(0.15)}>
          The Launcher Issue
        </span>
      </div>

      {/* masthead */}
      <div className="relative z-10 mt-3 px-5 md:px-10">
        <SplitText
          as="h1"
          text="Press Start"
          delay={0.12}
          step={0.1}
          accentWord="Start"
          className="font-display text-[24vw] uppercase leading-[.8] tracking-[-.01em] md:text-[13vw] [&>span]:block"
        />
      </div>

      {/* cover lines + open */}
      <div className="absolute inset-x-0 bottom-0 z-10 flex flex-col justify-between gap-8 px-6 pb-8 md:flex-row md:items-end md:px-12 md:pb-12">
        <ul className="space-y-5">
          {lines.map((g, i) => (
            <li key={g.id} className="rise" style={enter(0.5 + i * 0.1)}>
              <Link to={`game:${g.id}`} className="group flex items-baseline gap-4">
                <span className="w-6 font-mono text-[10px] text-white/40">{pageNo(`game:${g.id}`)}</span>
                <span>
                  <span className="block font-display text-3xl uppercase leading-none transition-colors duration-300 group-hover:text-accent md:text-[2.6rem]">
                    {g.title}
                  </span>
                  <span className="mt-1.5 block font-mono text-[10px] uppercase tracking-[.25em] text-white/40">{g.genre}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>

        <button
          onClick={(e) => navigate("index", e)}
          className="rise group inline-flex h-14 items-center gap-4 self-start bg-white pl-6 pr-4 font-mono text-xs uppercase tracking-[.25em] text-black transition-colors duration-300 hover:bg-accent hover:text-on-accent md:self-auto"
          style={enter(0.85)}
        >
          Open the issue
          <span className="grid h-8 w-8 place-items-center rounded-full bg-black/10 transition-transform duration-300 group-hover:translate-x-1">→</span>
        </button>
      </div>
    </div>
  );
}
