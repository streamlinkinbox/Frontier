import { useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { useApp } from "../store";
import type { TransitionStyle } from "../store";
import { PageShell, SectionHead, cx } from "../components/ui";

const ACCENTS = [
  { name: "Signal", v: "#3d6bff" },
  { name: "Press Red", v: "#ff4a3d" },
  { name: "Tangerine", v: "#ff6a1a" },
  { name: "Hot Pink", v: "#f0377f" },
  { name: "Violet", v: "#8b5cf6" },
  { name: "Emerald", v: "#12a36f" },
];

const TRANSITIONS: { id: TransitionStyle; name: string; desc: string }[] = [
  { id: "turn", name: "Page Turn", desc: "A 3D page peels off the binding like real paper." },
  { id: "ink", name: "Ink Bleed", desc: "Ink floods outward from the exact spot you tap." },
  { id: "shutter", name: "Shutter", desc: "A title card slams across the spread." },
  { id: "crt", name: "CRT Glitch", desc: "RGB tear, power-off flash, then the new page powers on." },
  { id: "slice", name: "Blinds", desc: "The old page closes into scanlines, revealing the next." },
  { id: "panel", name: "Comic Panel", desc: "Three skewed panels wipe the page off the stand." },
];

function Row({ title, desc, children }: { title: string; desc: string; children: ReactNode }) {
  return (
    <div data-reveal className="grid gap-6 border-t border-white/[.07] py-10 md:grid-cols-[minmax(0,1fr)_minmax(0,1.7fr)] md:gap-12">
      <div>
        <h3 className="font-display text-2xl uppercase leading-none md:text-3xl">{title}</h3>
        <p className="mt-2 font-serif italic text-ink/40">{desc}</p>
      </div>
      <div>{children}</div>
    </div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!checked)} className="flex w-full items-center justify-between py-2" role="switch" aria-checked={checked}>
      <span className="font-serif text-lg text-ink/80">{label}</span>
      <span className={cx("relative h-6 w-11 rounded-full transition-colors duration-300", checked ? "bg-accent" : "bg-white/15")}>
        <span
          className={cx(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all duration-300 ease-[cubic-bezier(.34,1.56,.64,1)]",
            checked ? "left-[22px]" : "left-0.5"
          )}
        />
      </span>
    </button>
  );
}

/** Miniature, replayable version of each page transition. */
function Preview({ style, k }: { style: TransitionStyle; k: number }) {
  const A = (
    <div className="absolute inset-0 flex flex-col justify-between bg-paper2 p-3">
      <span className="font-mono text-[8px] uppercase tracking-widest text-ink/50">p.02</span>
      <span className="font-display text-3xl uppercase leading-none">Before</span>
    </div>
  );
  const B = (
    <div className="absolute inset-0 flex flex-col justify-between bg-ink p-3 text-paper">
      <span className="font-mono text-[8px] uppercase tracking-widest opacity-60">p.04</span>
      <span className="font-display text-3xl uppercase leading-none">After</span>
    </div>
  );
  return (
    <div
      key={`${style}-${k}`}
      className="stage relative h-36 w-full overflow-hidden border border-white/10 bg-black"
      style={{ ["--x" as string]: "70%", ["--y" as string]: "60%", ["--dir" as string]: 1 } as CSSProperties}
    >
      {style === "turn" && (
        <>
          <div className="turn-in absolute inset-0">
            {B}
            <div className="page-shade" />
          </div>
          <div className="turn-out-1 absolute inset-0">
            {A}
            <div className="page-shade" />
          </div>
        </>
      )}
      {style === "ink" && (
        <>
          <div className="ink-out absolute inset-0">{A}</div>
          <div className="ink-blot" />
          <div className="ink-in absolute inset-0">{B}</div>
        </>
      )}
      {style === "shutter" && (
        <>
          <div className="shutter-in absolute inset-0">{B}</div>
          <div className="shutter-out absolute inset-0">{A}</div>
          <div className="shutter-panel-ink d1" />
          <div className="shutter-panel shutter-panel-1 !px-4">
            <span className="shutter-title font-display text-2xl uppercase">Page 04</span>
          </div>
        </>
      )}
      {style === "crt" && (
        <>
          <div className="crt-in absolute inset-0">{B}</div>
          <div className="crt-out absolute inset-0">{A}</div>
          <div className="crt-scan" />
          <div className="crt-bar" />
          <div className="crt-noise" />
        </>
      )}
      {style === "slice" && (
        <>
          <div className="slice-in absolute inset-0">{B}</div>
          <div className="slice-out absolute inset-0">{A}</div>
          <div className="slice-lines" />
        </>
      )}
      {style === "panel" && (
        <>
          <div className="panel-in absolute inset-0">{B}</div>
          <div className="panel-out absolute inset-0">{A}</div>
          <div className="panel-swipe">
            <span />
            <span />
            <span />
          </div>
        </>
      )}
    </div>
  );
}

export default function Settings() {
  const { settings, setSettings, resetAll, navigate } = useApp();
  const [pk, setPk] = useState(0);
  const current = TRANSITIONS.find((t) => t.id === settings.transition) ?? TRANSITIONS[0];
  const replay = () => setPk((k) => k + 1);

  return (
    <PageShell>
      <SectionHead route="settings" kicker="Department 05" title="Settings" deck="Your issue, your way. Everything saves automatically." />

      <div className="max-w-6xl px-6 md:px-12 lg:px-16">
        <Row title="Page transition" desc="How pages change when you follow a link.">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {TRANSITIONS.map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  setSettings({ transition: t.id });
                  replay();
                }}
                className={cx(
                  "h-12 border px-4 text-left font-display text-lg uppercase tracking-wide transition duration-300",
                  settings.transition === t.id ? "border-accent bg-accent/10 text-ink" : "border-white/[.08] text-ink/45 hover:border-white/25 hover:text-ink"
                )}
              >
                {t.name}
              </button>
            ))}
          </div>
          <div className="mt-4 grid items-stretch gap-3 sm:grid-cols-[1fr_auto]">
            <Preview style={settings.transition} k={pk} />
            <div className="flex justify-end gap-2 sm:flex-col">
              <button onClick={replay} className="h-10 border border-white/15 px-4 font-mono text-[10.5px] uppercase tracking-[.18em] text-ink/70 transition hover:border-white/50 hover:text-ink">
                ↻ Replay
              </button>
              <button
                onClick={(e) => navigate("index", e)}
                className="h-10 bg-ink px-4 font-mono text-[10.5px] uppercase tracking-[.18em] text-paper transition hover:bg-accent hover:text-on-accent"
              >
                Try it →
              </button>
            </div>
          </div>
          <p className="mt-3 font-serif text-sm italic text-ink/40">{current.desc}</p>
        </Row>

        <Row title="Turn speed" desc="How long each page change takes.">
          <div className="inline-flex rounded-full border border-white/10 p-1">
            {(["fast", "normal", "slow"] as const).map((s) => (
              <button
                key={s}
                onClick={() => {
                  setSettings({ speed: s });
                  replay();
                }}
                className={cx(
                  "rounded-full px-5 py-2 font-mono text-[10.5px] uppercase tracking-[.18em] transition duration-300",
                  settings.speed === s ? "bg-ink text-paper" : "text-ink/45 hover:text-ink"
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </Row>

        <Row title="Ink colour" desc="The spot colour used across the issue.">
          <div className="flex flex-wrap gap-4">
            {ACCENTS.map((a) => (
              <button key={a.v} onClick={() => setSettings({ accent: a.v })} className="group flex flex-col items-center gap-2" title={a.name}>
                <span
                  className={cx(
                    "h-11 w-11 rounded-full transition duration-300",
                    settings.accent === a.v ? "scale-110 ring-2 ring-ink ring-offset-4 ring-offset-paper" : "group-hover:scale-110"
                  )}
                  style={{ background: a.v }}
                />
                <span className={cx("font-mono text-[9px] uppercase tracking-[.18em]", settings.accent === a.v ? "text-ink" : "text-ink/35")}>{a.name}</span>
              </button>
            ))}
          </div>
        </Row>

        <Row title="Downloads" desc="Bandwidth and install behaviour.">
          <label className="block">
            <div className="flex justify-between font-mono text-[10.5px] uppercase tracking-[.18em]">
              <span className="text-ink/40">Bandwidth limit</span>
              <span>{settings.bandwidth} MB/s</span>
            </div>
            <input
              type="range"
              min={25}
              max={1000}
              step={25}
              value={settings.bandwidth}
              onChange={(e) => setSettings({ bandwidth: +e.target.value })}
              className="mt-3 w-full accent-[var(--accent)]"
            />
          </label>
          <div className="mt-4">
            <Toggle label="Download purchases automatically" checked={settings.autoInstall} onChange={(v) => setSettings({ autoInstall: v })} />
          </div>
        </Row>

        <Row title="Texture" desc="A whisper of film grain over every page.">
          <Toggle label="Film grain" checked={settings.grain} onChange={(v) => setSettings({ grain: v })} />
        </Row>

        <Row title="Start over" desc="Restore the library, orders and preferences.">
          <button
            onClick={() => {
              if (confirm("Reset library, orders, downloads and settings?")) resetAll();
            }}
            className="h-11 border border-white/15 px-5 font-mono text-[10.5px] uppercase tracking-[.18em] text-ink/60 transition hover:border-accent hover:text-accent"
          >
            Reset all data
          </button>
        </Row>
      </div>
    </PageShell>
  );
}
