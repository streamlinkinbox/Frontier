import { useApp, pageNo } from "../store";
import { GAMES } from "../data/games";
import { Kicker, Link, PageShell } from "../components/ui";
import { SplitText, enter } from "../components/micro";

const DEPTS = [
  { to: "store", n: "01", title: "Store", desc: "Cover feature, editor's picks, the chart." },
  { to: "games", n: "02", title: "Games", desc: "The full catalogue, searchable by genre." },
  { to: "library", n: "03", title: "Library", desc: "Your shelf — everything you own." },
  { to: "downloads", n: "04", title: "Downloads", desc: "The queue, the bandwidth, the wait." },
  { to: "settings", n: "05", title: "Settings", desc: "Transitions, ink colour, preferences." },
];

export default function Index() {
  const { library } = useApp();

  return (
    <PageShell>
      <div className="grid gap-14 px-6 pt-10 md:px-12 md:pt-16 lg:grid-cols-12 lg:gap-20 lg:px-16">
        {/* departments */}
        <section className="lg:col-span-7">
          <div className="flex items-end justify-between">
            <SplitText as="h1" text="Contents" delay={0.05} className="font-serif text-6xl font-light italic tracking-tight md:text-8xl" />
            <Kicker className="rise hidden pb-3 text-ink/35 sm:block" style={enter(0.2)}>
              No. 27
            </Kicker>
          </div>

          <ol className="mt-10 border-t border-white/10">
            {DEPTS.map((d) => (
              <li key={d.to} data-reveal>
                <Link to={d.to} className="group relative flex items-center gap-5 overflow-hidden border-b border-white/10 py-5 md:gap-8">
                  <span className="absolute inset-0 origin-left scale-x-0 bg-accent transition-transform duration-500 ease-[cubic-bezier(.7,0,.2,1)] group-hover:scale-x-100" />
                  <span className="relative w-6 font-mono text-xs text-ink/35 transition-colors duration-500 group-hover:text-on-accent">{d.n}</span>
                  <span className="relative min-w-0 flex-1">
                    <span className="block font-display text-5xl uppercase leading-[.9] transition duration-500 group-hover:translate-x-2 group-hover:text-on-accent md:text-6xl">
                      {d.title}
                    </span>
                    <span className="mt-1 block truncate font-serif text-[15px] italic text-ink/40 transition duration-500 group-hover:translate-x-2 group-hover:text-on-accent/80">
                      {d.desc}
                    </span>
                  </span>
                  <span className="relative font-display text-2xl text-ink/25 transition-colors duration-500 group-hover:text-on-accent md:text-3xl">{pageNo(d.to)}</span>
                </Link>
              </li>
            ))}
          </ol>

          <p data-reveal className="mt-6 font-mono text-[10px] uppercase tracking-[.25em] text-ink/30">
            Tip — use ← → to turn pages
          </p>
        </section>

        {/* features */}
        <aside className="lg:col-span-5 lg:pt-6">
          <Kicker data-reveal className="mb-4 text-ink/40">
            Features in this issue
          </Kicker>
          <ul>
            {GAMES.map((g) => (
              <li key={g.id} data-reveal>
                <Link to={`game:${g.id}`} className="group flex items-center gap-4 border-b border-white/[.07] py-3">
                  <span className="w-6 font-mono text-[11px] text-ink/30">{pageNo(`game:${g.id}`)}</span>
                  <span className="h-14 w-14 shrink-0 overflow-hidden">
                    <img
                      src={g.img}
                      alt=""
                      style={{ objectPosition: g.focus }}
                      className="h-full w-full object-cover opacity-60 grayscale transition duration-700 group-hover:scale-110 group-hover:opacity-100 group-hover:grayscale-0"
                    />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-display text-2xl uppercase leading-none transition-transform duration-300 group-hover:translate-x-1">{g.title}</span>
                    <span className="mt-1 block font-mono text-[10px] uppercase tracking-[.2em] text-ink/35">{g.genre}</span>
                  </span>
                  {library[g.id] && <span className="h-1.5 w-1.5 rounded-full bg-accent" title="In your library" />}
                </Link>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </PageShell>
  );
}
