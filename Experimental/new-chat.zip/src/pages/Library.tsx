import { useState } from "react";
import type { CSSProperties } from "react";
import { useApp } from "../store";
import { getGame } from "../data/games";
import { GameAction, Kicker, Link, PageShell, SectionHead, cx, tint } from "../components/ui";
import { CountUp, enter } from "../components/micro";

const ago = (t?: number) => {
  if (!t) return "Never";
  const d = Math.floor((Date.now() - t) / 864e5);
  if (d <= 0) return "Today";
  if (d === 1) return "Yesterday";
  return `${d} days ago`;
};

const HEIGHTS = ["h-[92%]", "h-[86%]", "h-[96%]"];

export default function Library() {
  const { library, downloads, uninstall, navigate, receipts, openReceipt } = useApp();
  const ids = Object.keys(library).sort(
    (a, b) => (library[b].lastPlayed ?? library[b].addedAt) - (library[a].lastPlayed ?? library[a].addedAt)
  );
  const [sel, setSel] = useState<string | null>(ids[0] ?? null);
  const [touched, setTouched] = useState(false);
  const [filter, setFilter] = useState<"all" | "installed">("all");

  const shown = ids.filter((id) => filter === "all" || library[id].installed);
  const selected = sel && library[sel] ? getGame(sel) : null;
  const installedCount = ids.filter((i) => library[i].installed).length;
  const hours = ids.reduce((s, id) => s + library[id].hours, 0);
  const receipt = sel ? receipts.find((r) => r.gameId === sel) : undefined;

  const pick = (id: string) => {
    setSel(id);
    setTouched(true);
  };

  return (
    <PageShell>
      <SectionHead route="library" kicker="Department 03" title="Library" deck="Your shelf. Pull a spine to read the back cover." />

      {ids.length === 0 ? (
        <div className="px-6 py-24 text-center">
          <div className="font-display text-6xl uppercase text-ink/15 md:text-7xl">Empty shelf</div>
          <p className="mb-8 mt-3 font-serif italic text-ink/45">Visit the store to start your collection.</p>
          <Link to="store" className="inline-block bg-ink px-6 py-3 font-mono text-xs uppercase tracking-[.2em] text-paper">
            Go to the store →
          </Link>
        </div>
      ) : (
        <>
          {/* stats + filter */}
          <div className="rise flex flex-wrap items-end justify-between gap-6 px-6 md:px-12 lg:px-16" style={enter(0.35)}>
            <div className="flex gap-10 md:gap-14">
              {(
                [
                  ["Owned", ids.length, 0],
                  ["Installed", installedCount, 0],
                  ["Hours", hours, 1],
                ] as const
              ).map(([k, v, d]) => (
                <div key={k}>
                  <div className="font-display text-4xl leading-none md:text-5xl">
                    <CountUp to={v} decimals={d} />
                  </div>
                  <div className="mt-2 font-mono text-[10px] uppercase tracking-[.25em] text-ink/35">{k}</div>
                </div>
              ))}
            </div>
            <div className="flex gap-1.5">
              {(["all", "installed"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={cx(
                    "rounded-full px-3 py-1.5 font-mono text-[10.5px] uppercase tracking-[.18em] transition duration-300",
                    filter === f ? "bg-ink text-paper" : "text-ink/45 hover:bg-white/5 hover:text-ink"
                  )}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* shelf */}
          <section data-reveal="clip" className="mt-10 px-6 md:px-12 lg:px-16">
            <div className="flex h-[340px] items-end gap-2.5 overflow-x-auto overflow-y-hidden px-1 md:h-[400px] md:gap-3">
              {shown.map((id, i) => {
                const g = getGame(id);
                const active = sel === id;
                const dl = downloads.find((d) => d.id === id);
                return (
                  <button
                    key={id}
                    onClick={() => pick(id)}
                    className={cx(
                      "relative shrink-0 overflow-hidden text-white transition-all duration-500 ease-[cubic-bezier(.2,.8,.2,1)]",
                      active ? "h-full w-60 md:w-72" : cx("w-16 hover:-translate-y-3 md:w-[4.5rem]", HEIGHTS[i % 3])
                    )}
                    style={{ background: g.color }}
                    aria-pressed={active}
                  >
                    <img
                      src={g.img}
                      alt=""
                      style={{ objectPosition: g.focus }}
                      className={cx("absolute inset-0 h-full w-full object-cover transition duration-500", active ? "opacity-100" : "opacity-30 mix-blend-multiply grayscale")}
                    />
                    <div className={cx("absolute inset-0 transition", active ? "bg-gradient-to-t from-black/90 via-transparent" : "bg-black/35")} />
                    {active ? (
                      <div className="absolute inset-x-0 bottom-0 p-4 text-left">
                        <div className="font-mono text-[10px] uppercase tracking-[.25em] text-white/70">{g.genre}</div>
                        <div className="font-display text-4xl uppercase leading-[.9]">{g.title}</div>
                      </div>
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-between py-4">
                        <span className="font-mono text-[9px] tracking-widest text-white/70">{String(i + 1).padStart(2, "0")}</span>
                        <span className="vertical whitespace-nowrap font-display text-2xl uppercase tracking-wide md:text-3xl">{g.title}</span>
                        <span
                          className={cx("h-2 w-2 rounded-full border border-white/80", library[id].installed && "bg-white")}
                          title={library[id].installed ? "Installed" : "Not installed"}
                        />
                      </div>
                    )}
                    {dl && (
                      <div className="absolute inset-x-0 bottom-0 h-1 bg-black/40">
                        <div className="h-full bg-white transition-[width] duration-500" style={{ width: `${dl.progress}%` }} />
                      </div>
                    )}
                  </button>
                );
              })}
              <Link
                to="store"
                className="grid h-[78%] w-16 shrink-0 place-items-center border border-dashed border-white/15 text-ink/35 transition hover:border-white/40 hover:text-ink md:w-[4.5rem]"
              >
                <span className="vertical font-mono text-[10px] uppercase tracking-[.25em]">+ Add from store</span>
              </Link>
            </div>
            <div className="h-3 bg-gradient-to-b from-white/[.14] to-white/[.03] shadow-[0_18px_30px_-12px_rgba(0,0,0,.9)]" />
          </section>

          {/* back cover */}
          {selected && sel && (
            <section
              key={sel}
              className="rise grid gap-10 px-6 py-16 md:grid-cols-12 md:px-12 lg:px-16"
              style={{ ...tint(selected.color), ...(touched ? { animationDelay: "0s" } : enter(0.5)) } as CSSProperties}
            >
              <div className="md:col-span-7">
                <Kicker className="text-accent">Back cover · {selected.genre}</Kicker>
                <h2 className="mt-2 font-display text-6xl uppercase leading-[.85] md:text-7xl">{selected.title}</h2>
                <p className="mt-4 max-w-xl font-serif text-xl italic text-ink/55">{selected.deck}</p>
                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <GameAction id={sel} size="lg" />
                  <button
                    onClick={(e) => navigate(`game:${sel}`, e)}
                    className="h-14 border border-white/15 px-5 font-mono text-[11px] uppercase tracking-[.18em] text-ink/80 transition hover:border-white/50 hover:text-ink"
                  >
                    Read feature
                  </button>
                  {receipt && (
                    <button
                      onClick={() => openReceipt(receipt.id)}
                      className="h-14 border border-white/15 px-5 font-mono text-[11px] uppercase tracking-[.18em] text-ink/80 transition hover:border-white/50 hover:text-ink"
                    >
                      Receipt
                    </button>
                  )}
                  {library[sel].installed && (
                    <button onClick={() => uninstall(sel)} className="px-3 font-mono text-[10px] uppercase tracking-[.2em] text-ink/35 transition hover:text-accent">
                      Uninstall
                    </button>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-px self-start border border-white/[.07] bg-white/[.07] md:col-span-5">
                {[
                  ["Played", `${library[sel].hours} h`],
                  ["Last session", ago(library[sel].lastPlayed)],
                  ["On disk", library[sel].installed ? `${selected.sizeGB} GB` : "—"],
                  ["Added", ago(library[sel].addedAt)],
                ].map(([k, v]) => (
                  <div key={k} className="bg-paper p-5">
                    <Kicker className="text-ink/35">{k}</Kicker>
                    <div className="mt-2 font-display text-3xl">{v}</div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </PageShell>
  );
}
