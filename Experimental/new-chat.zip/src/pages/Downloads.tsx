import { useApp } from "../store";
import { GAMES, getGame } from "../data/games";
import { Kicker, Link, PageShell, SectionHead, tint } from "../components/ui";

const DISK = 1000; // GB
const SYSTEM = 214; // GB

export default function Downloads() {
  const { downloads, speedHistory, pause, resume, cancel, prioritize, library, settings, setSettings } = useApp();
  const active = downloads.find((d) => d.status === "downloading");
  const rest = downloads.filter((d) => d !== active);
  const curSpeed = speedHistory[speedHistory.length - 1] || 0;
  const installed = GAMES.filter((g) => library[g.id]?.installed);
  const used = installed.reduce((s, g) => s + g.sizeGB, 0) + SYSTEM;
  const max = Math.max(settings.bandwidth * 1.15, ...speedHistory, 1);
  const path = speedHistory.map((v, i) => `${(i / (speedHistory.length - 1)) * 300},${80 - (v / max) * 70}`).join(" L ");

  const ag = active ? getGame(active.id) : null;
  const remainingGB = ag && active ? ag.sizeGB * (1 - active.progress / 100) : 0;
  const eta = curSpeed > 0 ? Math.ceil((remainingGB * 1024) / curSpeed) : 0;
  const iconBtn = "grid h-9 w-9 place-items-center text-ink/50 transition hover:bg-white/10 hover:text-ink";

  return (
    <PageShell>
      <SectionHead route="downloads" kicker="Department 04" title="Downloads" deck="Bits on the move. Reorder, pause, or just watch the numbers climb." />

      <section className="grid gap-12 px-6 md:px-12 lg:grid-cols-12 lg:px-16">
        <div className="space-y-14 lg:col-span-8">
          {/* active transfer */}
          {active && ag ? (
            <div data-reveal>
              <div className="relative overflow-hidden border border-white/[.07] bg-paper2" style={tint(ag.color)}>
                <img src={ag.img} alt="" style={{ objectPosition: ag.focus }} className="absolute inset-0 h-full w-full object-cover opacity-25" />
                <div className="absolute inset-0 bg-gradient-to-r from-paper2 via-paper2/85 to-transparent" />
                <div className="relative p-6 md:p-10">
                  <Kicker className="flex items-center gap-2 text-accent">
                    <span className="live-dot">●</span> Now downloading
                  </Kicker>
                  <div className="mt-2 font-display text-4xl uppercase leading-[.9] md:text-6xl">{ag.title}</div>
                  <div className="mt-8 flex flex-wrap items-end justify-between gap-8">
                    <div className="breath font-display text-[26vw] tabular-nums leading-[.8] md:text-[10rem]">
                      {Math.floor(active.progress)}
                      <span className="ml-1 align-top text-[.35em] text-accent">%</span>
                    </div>
                    <dl className="grid grid-cols-2 gap-x-10 gap-y-4 font-mono">
                      {[
                        ["Speed", `${curSpeed.toFixed(0)} MB/s`],
                        ["Remaining", `${remainingGB.toFixed(1)} GB`],
                        ["ETA", eta > 60 ? `${Math.floor(eta / 60)}m ${eta % 60}s` : `${eta}s`],
                        ["Size", `${ag.sizeGB} GB`],
                      ].map(([k, v]) => (
                        <div key={k}>
                          <dt className="text-[10px] uppercase tracking-[.2em] text-ink/40">{k}</dt>
                          <dd className="text-lg tabular-nums">{v}</dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                  <div className="mt-8 h-1.5 overflow-hidden bg-white/10">
                    <div className="stripes h-full bg-accent transition-[width] duration-500" style={{ width: `${active.progress}%` }} />
                  </div>
                  <div className="mt-6 flex gap-3">
                    <button
                      onClick={() => pause(active.id)}
                      className="h-11 bg-ink px-5 font-mono text-[11px] uppercase tracking-[.18em] text-paper transition hover:bg-accent hover:text-on-accent"
                    >
                      ❚❚ Pause
                    </button>
                    <button
                      onClick={() => cancel(active.id)}
                      className="h-11 border border-white/20 px-5 font-mono text-[11px] uppercase tracking-[.18em] text-ink/70 transition hover:border-white/60 hover:text-ink"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div data-reveal className="border border-dashed border-white/15 p-10 text-center md:p-16">
              <div className="font-display text-6xl uppercase leading-none text-ink/15 md:text-8xl">All quiet</div>
              <p className="mt-4 font-serif text-xl italic text-ink/50">{rest.length ? "Everything is paused." : "Nothing in transit. Your shelf is up to date."}</p>
              <Link to="store" className="mt-8 inline-block bg-ink px-5 py-3 font-mono text-[11px] uppercase tracking-[.2em] text-paper">
                Browse the store →
              </Link>
            </div>
          )}

          {/* queue */}
          {rest.length > 0 && (
            <div>
              <div data-reveal className="flex items-end justify-between pb-3">
                <h2 className="font-display text-4xl uppercase">Up next</h2>
                <Kicker className="text-ink/35">{rest.length} in queue</Kicker>
              </div>
              {rest.map((d, i) => {
                const g = getGame(d.id);
                return (
                  <div key={d.id} data-reveal="left">
                    <div className="grid grid-cols-[2.5rem_3.5rem_1fr_auto] items-center gap-4 border-t border-white/[.07] py-4">
                      <span className="font-display text-3xl text-ink/20">{String(i + 1).padStart(2, "0")}</span>
                      <img src={g.img} alt="" className="h-12 w-14 object-cover" />
                      <div className="min-w-0">
                        <div className="truncate font-display text-2xl uppercase leading-none">{g.title}</div>
                        <div className="mt-2 h-1 bg-white/10">
                          <div className="h-full bg-ink/70" style={{ width: `${d.progress}%` }} />
                        </div>
                        <div className="mt-1.5 font-mono text-[10px] uppercase tracking-[.2em] text-ink/35">
                          {d.status} · {Math.floor(d.progress)}% of {g.sizeGB} GB
                        </div>
                      </div>
                      <div className="flex font-mono text-xs">
                        <button title="Download now" onClick={() => prioritize(d.id)} className={iconBtn}>
                          ⇡
                        </button>
                        {d.status === "paused" ? (
                          <button title="Resume" onClick={() => resume(d.id)} className={iconBtn}>
                            ▶
                          </button>
                        ) : (
                          <button title="Pause" onClick={() => pause(d.id)} className={iconBtn}>
                            ❚❚
                          </button>
                        )}
                        <button title="Cancel" onClick={() => cancel(d.id)} className={iconBtn}>
                          ✕
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* sidebar */}
        <aside className="space-y-6 lg:col-span-4">
          <div data-reveal="right" className="border border-white/[.07] bg-paper2 p-6">
            <div className="flex items-baseline justify-between">
              <Kicker className="text-ink/40">Network</Kicker>
              <span className="font-display text-3xl tabular-nums">
                {curSpeed.toFixed(0)}
                <span className="ml-1 font-mono text-xs text-ink/40">MB/s</span>
              </span>
            </div>
            <svg viewBox="0 0 300 80" className="mt-4 h-24 w-full" preserveAspectRatio="none">
              <path d={`M 0,80 L ${path} L 300,80 Z`} fill="var(--accent)" fillOpacity=".15" />
              <path d={`M ${path}`} fill="none" stroke="var(--accent)" strokeWidth="2" vectorEffect="non-scaling-stroke" />
            </svg>
            <label className="mt-5 block">
              <div className="flex justify-between font-mono text-[10px] uppercase tracking-[.2em]">
                <span className="text-ink/40">Limit</span>
                <span>{settings.bandwidth} MB/s</span>
              </div>
              <input
                type="range"
                min={25}
                max={1000}
                step={25}
                value={settings.bandwidth}
                onChange={(e) => setSettings({ bandwidth: +e.target.value })}
                className="mt-3 w-full accent-[var(--accent)]"
              />
            </label>
          </div>

          <div data-reveal="right" className="border border-white/[.07] bg-paper2 p-6">
            <Kicker className="text-ink/40">Storage</Kicker>
            <div className="mt-2 font-display text-5xl">
              {used.toFixed(0)}
              <span className="text-xl text-ink/35"> / {DISK} GB</span>
            </div>
            <div className="mt-4 flex h-2 overflow-hidden bg-white/10">
              <div className="bg-white/35" style={{ width: `${(SYSTEM / DISK) * 100}%` }} title="System" />
              {installed.map((g) => (
                <div key={g.id} style={{ width: `${(g.sizeGB / DISK) * 100}%`, background: g.color }} title={g.title} />
              ))}
            </div>
            <ul className="mt-5 space-y-1.5 font-mono text-xs text-ink/60">
              <li className="flex justify-between">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 bg-white/35" /> System
                </span>
                <span>{SYSTEM} GB</span>
              </li>
              {installed.map((g) => (
                <li key={g.id} className="flex justify-between">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2" style={{ background: g.color }} /> {g.title}
                  </span>
                  <span>{g.sizeGB} GB</span>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </section>
    </PageShell>
  );
}
