import { useMemo, useState } from "react";
import { useApp } from "../store";
import { GAMES, GENRES } from "../data/games";
import { PageShell, SectionHead, cx } from "../components/ui";
import { GameCard } from "../components/GameCard";
import { HeartIcon } from "../components/icons";
import { CountUp } from "../components/micro";

type Sort = "issue" | "rating" | "price";
const SAVED = "Saved";

export default function Browse() {
  const { wishlist } = useApp();
  const [genre, setGenre] = useState("All");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<Sort>("issue");

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let l = GAMES.filter((g) => {
      const inGroup = genre === SAVED ? wishlist.includes(g.id) : genre === "All" || g.genre === genre;
      return inGroup && (g.title + " " + g.genre + " " + g.developer + " " + g.tags.join(" ")).toLowerCase().includes(needle);
    });
    if (sort === "rating") l = [...l].sort((a, b) => b.rating - a.rating);
    if (sort === "price") l = [...l].sort((a, b) => a.price - b.price);
    return l;
  }, [genre, q, sort, wishlist]);

  const showSaved = wishlist.length > 0 || genre === SAVED;
  const pill = (active: boolean) =>
    cx(
      "shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 font-mono text-[10.5px] uppercase tracking-[.18em] transition duration-300",
      active ? "bg-ink text-paper" : "text-ink/45 hover:bg-white/5 hover:text-ink"
    );

  return (
    <PageShell>
      <SectionHead route="games" kicker="Department 02" title="Games" deck="Every world in the issue. Tap a card to turn to its feature." />

      {/* controls */}
      <div className="z-20 flex flex-wrap items-center gap-x-6 gap-y-3 border-y border-white/[.06] bg-paper/85 px-6 py-4 backdrop-blur-xl md:sticky md:top-0 md:px-12 lg:px-16">
        <label className="relative order-1 min-w-[10rem] max-w-sm flex-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="absolute left-0 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/35">
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.5-3.5" strokeLinecap="round" />
          </svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search titles, studios, tags"
            className="w-full border-b border-white/15 bg-transparent py-2 pl-7 font-serif text-lg italic outline-none transition-colors placeholder:text-ink/25 focus:border-accent"
          />
        </label>
        <div className="order-3 -mx-6 flex basis-[calc(100%+3rem)] gap-1.5 overflow-x-auto px-6 [scrollbar-width:none] md:order-2 md:mx-0 md:basis-auto md:flex-wrap md:overflow-visible md:px-0">
          {GENRES.map((g) => (
            <button key={g} onClick={() => setGenre(g)} className={pill(genre === g)}>
              {g}
            </button>
          ))}
          {showSaved && (
            <button onClick={() => setGenre(SAVED)} className={cx(pill(genre === SAVED), "toast-in flex items-center gap-1.5")}>
              <HeartIcon filled className={cx("h-3 w-3", genre !== SAVED && "text-accent")} />
              Saved · {wishlist.length}
            </button>
          )}
        </div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as Sort)}
          className="order-2 ml-auto cursor-pointer bg-transparent font-mono text-[10.5px] uppercase tracking-[.18em] text-ink/55 outline-none md:order-3"
          aria-label="Sort"
        >
          <option value="issue">Issue order</option>
          <option value="rating">Top rated</option>
          <option value="price">Lowest price</option>
        </select>
      </div>

      <div className="px-6 pt-8 md:px-12 lg:px-16">
        <div className="mb-8 flex items-baseline gap-2 font-mono text-[10.5px] uppercase tracking-[.25em] text-ink/35">
          <span className="font-display text-2xl tracking-normal text-ink">
            <CountUp to={list.length} />
          </span>
          {list.length === 1 ? "result" : "results"}
          {genre !== "All" && ` in ${genre}`}
        </div>

        {list.length === 0 ? (
          <div className="py-24 text-center">
            <div className="font-display text-6xl uppercase text-ink/15 md:text-7xl">{genre === SAVED ? "Nothing saved" : "Nothing printed"}</div>
            <p className="mt-3 font-serif italic text-ink/45">{genre === SAVED ? "Tap ♥ on any card to keep it for later." : "Try another search or genre."}</p>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 md:gap-6 lg:grid-cols-3 xl:grid-cols-4">
            {list.map((g) => (
              <div key={g.id} data-reveal>
                <GameCard id={g.id} />
              </div>
            ))}
          </div>
        )}
      </div>
    </PageShell>
  );
}
