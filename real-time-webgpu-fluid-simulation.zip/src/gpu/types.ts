// Shared parameter types for the WebGPU fluid engine.

export type ToolMode =
  | 'none'
  | 'add'
  | 'remove'
  | 'push'
  | 'splash'
  | 'raise'
  | 'lower';

export const TOOL_IDS: Record<ToolMode, number> = {
  none: 0,
  add: 1,
  remove: 2,
  push: 3,
  splash: 6,
  raise: 4,
  lower: 5,
};

export type DebugView = 'none' | 'depth' | 'velocity' | 'foam';
export const DEBUG_IDS: Record<DebugView, number> = {
  none: 0,
  depth: 1,
  velocity: 2,
  foam: 3,
};

/** Parameters consumed by the compute shaders every frame. */
export interface SimParams {
  gravity: number;
  /** Viscous drag (mud-like). Water ≈ 0, mud 0.5 – 3. */
  viscosity: number;
  /** Linear bottom friction. */
  drag: number;
  /** Bingham yield slope: fluid only flows when surface slope exceeds it. */
  yieldSlope: number;
  /** Minimum depth (m) that is treated as "wet". */
  minDepth: number;
  /** Rain drops per m² per second. */
  rainRate: number;
  /** Height added per rain drop (m). */
  rainDrop: number;
  /** Evaporation (m / s). */
  evaporation: number;
  seaLevel: number;
  /** Wave-maker toggle (waves injected along the x = 0 edge). */
  waveMaker: boolean;
  waveAmp: number;
  waveLen: number;
  wavePeriod: number;
  /** Continuous inflow source (streams / mud). */
  sourceRate: number;
  sourceX: number; // 0..1 (domain uv)
  sourceY: number;
  sourceRadius: number; // meters
  /** Drain strength at the far (x = 1) edge, 0 = closed wall. */
  drain: number;
  foamDecay: number;
  foamGain: number;
  /** Expected max depth; used to pick a stable sub-step size. */
  maxDepth: number;
  /** Max number of sub-steps per frame. */
  maxSubsteps: number;
}

export interface RenderParams {
  /** 0 = water, 1 = mud */
  fluidType: 0 | 1;
  /** Gerstner swell amplitude (visual only). */
  swellAmp: number;
  windDir: number; // degrees
  windSpeed: number;
  /** Per-channel light absorption per metre. */
  absorb: [number, number, number];
  /** In-scattered colour of the water body. */
  scatter: [number, number, number];
  roughness: number;
  refraction: number;
  foamAmount: number;
  /** Depth over which thin films fade in (m). */
  fadeDepth: number;
  rippleAmp: number;
  sunElevation: number; // degrees
  sunAzimuth: number; // degrees
  /** 0 = natural (sand/grass/rock), 1 = dirt/mud */
  palette: 0 | 1;
  /** Render an endless ocean plane around the sim domain. */
  farField: boolean;
  debugView: DebugView;
  /** Terrain skirt base height. */
  skirtBase: number;
}

export interface TerrainParams {
  /** 0 bowl, 1 beach, 2 bumpy ground, 3 slope+channel, 4 islands */
  terrainType: number;
  seed: number;
  amplitude: number;
  frequency: number;
  slope: number;
  baseHeight: number;
  channelDepth: number;
  channelWidth: number;
  /** 0 none, 1 fill to level, 2 blob at top of slope */
  fillType: number;
  fillLevel: number;
  fillExtent: number;
}

export interface Preset {
  id: string;
  name: string;
  description: string;
  emoji: string;
  terrain: TerrainParams;
  sim: SimParams;
  render: RenderParams;
  camera: { yaw: number; pitch: number; distance: number; targetY: number };
}

export interface EngineStats {
  fps: number;
  frameMs: number;
  substeps: number;
  gridSize: number;
  cells: number;
  adapter: string;
}
