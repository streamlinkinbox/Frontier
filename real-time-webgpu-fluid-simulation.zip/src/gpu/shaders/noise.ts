// Shared WGSL noise helpers (concatenated into both shader modules).
export const noiseWGSL = /* wgsl */ `
fn hash21(p : vec2<f32>) -> f32 {
  var q = fract(p * vec2<f32>(0.1031, 0.1030));
  q = q + dot(q, q.yx + vec2<f32>(33.33, 33.33));
  return fract((q.x + q.y) * q.x);
}

fn valueNoise(p : vec2<f32>) -> f32 {
  let i = floor(p);
  let f = fract(p);
  let u = f * f * (3.0 - 2.0 * f);
  let a = hash21(i);
  let b = hash21(i + vec2<f32>(1.0, 0.0));
  let c = hash21(i + vec2<f32>(0.0, 1.0));
  let d = hash21(i + vec2<f32>(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Signed fractal Brownian motion in roughly [-1, 1]
fn fbm(p : vec2<f32>, octaves : i32) -> f32 {
  var v = 0.0;
  var amp = 0.5;
  var q = p;
  let rot = mat2x2<f32>(vec2<f32>(0.8, 0.6), vec2<f32>(-0.6, 0.8));
  for (var i = 0; i < octaves; i++) {
    v = v + amp * (valueNoise(q) * 2.0 - 1.0);
    q = rot * q * 2.03 + vec2<f32>(11.3, 7.1);
    amp = amp * 0.5;
  }
  return v;
}
`;
