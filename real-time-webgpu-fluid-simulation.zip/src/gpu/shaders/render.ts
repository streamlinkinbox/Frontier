import { noiseWGSL } from './noise';

export const renderShader = /* wgsl */ `
struct Uniforms {
  viewProj : mat4x4<f32>,
  cameraPos : vec4<f32>,   // xyz, w = tan(fov / 2)
  camRight : vec4<f32>,    // xyz, w = aspect
  camUp : vec4<f32>,
  camForward : vec4<f32>,
  sunDir : vec4<f32>,      // xyz, w = intensity
  params0 : vec4<f32>,     // gridSize, cellSize, time, seaLevel
  params1 : vec4<f32>,     // swellAmp, windX, windY, windSpeed
  params2 : vec4<f32>,     // fluidType, foamAmount, debugMode, farFieldRadius
  absorb : vec4<f32>,      // rgb absorption / m, w = refraction strength
  scatter : vec4<f32>,     // rgb scatter colour, w = roughness
  screen : vec4<f32>,      // w, h, 1/w, 1/h
  misc : vec4<f32>,        // paletteId, skirtBase, rippleAmp, fadeDepth
  waveParams : vec4<f32>,  // wave-maker amp, period, obliqueness length, deep-water speed
};

struct DrawParams {
  mode : u32,              // 0 = sim domain, 1 = far-field ocean
  pad0 : u32,
  pad1 : u32,
  pad2 : u32,
};

@group(0) @binding(0) var<uniform> U : Uniforms;
@group(0) @binding(1) var<storage, read> terrain : array<f32>;
@group(0) @binding(2) var<storage, read> water : array<f32>;
@group(0) @binding(3) var<storage, read> velocity : array<vec2<f32>>;
@group(0) @binding(4) var<storage, read> aux : array<vec2<f32>>;
@group(1) @binding(0) var sceneTex : texture_2d<f32>;
@group(1) @binding(1) var sceneSampler : sampler;
@group(2) @binding(0) var<uniform> D : DrawParams;

${noiseWGSL}

const PI : f32 = 3.14159265;
const TAU : f32 = 6.2831853;
const HORIZON : vec3<f32> = vec3<f32>(0.70, 0.78, 0.88);

// ---------------------------------------------------------------------------
// Field sampling
// ---------------------------------------------------------------------------
fn gridN() -> i32 {
  return i32(U.params0.x);
}

fn fetchCell(which : u32, x : i32, y : i32) -> f32 {
  let n = gridN();
  let cx = clamp(x, 0, n - 1);
  let cy = clamp(y, 0, n - 1);
  let i = u32(cy * n + cx);
  if (which == 0u) { return terrain[i]; }
  if (which == 1u) { return water[i]; }
  if (which == 2u) { return terrain[i] + water[i]; }
  if (which == 3u) { return aux[i].x; }
  return aux[i].y;
}

// which: 0 terrain, 1 depth, 2 surface, 3 foam, 4 wetness
fn sampleField(which : u32, uv : vec2<f32>) -> f32 {
  let n = f32(gridN());
  let g = clamp(uv, vec2<f32>(0.0), vec2<f32>(1.0)) * n - 0.5;
  let g0 = floor(g);
  let f = g - g0;
  let x0 = i32(g0.x);
  let y0 = i32(g0.y);
  let a = fetchCell(which, x0, y0);
  let b = fetchCell(which, x0 + 1, y0);
  let c = fetchCell(which, x0, y0 + 1);
  let d = fetchCell(which, x0 + 1, y0 + 1);
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

fn sampleVelocity(uv : vec2<f32>) -> vec2<f32> {
  let n = gridN();
  let g = clamp(uv, vec2<f32>(0.0), vec2<f32>(1.0)) * f32(n) - 0.5;
  let g0 = floor(g);
  let f = g - g0;
  let x0 = clamp(i32(g0.x), 0, n - 1);
  let y0 = clamp(i32(g0.y), 0, n - 1);
  let x1 = clamp(x0 + 1, 0, n - 1);
  let y1 = clamp(y0 + 1, 0, n - 1);
  let a = velocity[u32(y0 * n + x0)];
  let b = velocity[u32(y0 * n + x1)];
  let c = velocity[u32(y1 * n + x0)];
  let d = velocity[u32(y1 * n + x1)];
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// ---------------------------------------------------------------------------
// Gerstner swell (visual, deep-water waves layered on top of the simulation)
// ---------------------------------------------------------------------------
fn gerstner(p : vec2<f32>, t : f32) -> vec3<f32> {
  let amp = U.params1.x;
  var disp = vec3<f32>(0.0);
  if (amp <= 0.0001) {
    return disp;
  }
  let wind = normalize(U.params1.yz + vec2<f32>(0.0001, 0.0));
  var waves = array<vec4<f32>, 6>(
    vec4<f32>(41.0, 1.00, 0.00, 0.0),
    vec4<f32>(23.0, 0.62, 0.42, 1.7),
    vec4<f32>(14.5, 0.42, -0.55, 3.1),
    vec4<f32>(8.2, 0.26, 0.90, 5.3),
    vec4<f32>(4.6, 0.16, -1.15, 2.2),
    vec4<f32>(2.7, 0.09, 0.30, 4.4)
  );
  for (var i = 0; i < 6; i++) {
    let w = waves[i];
    let k = TAU / w.x;
    let ca = cos(w.z);
    let sa = sin(w.z);
    let dir = vec2<f32>(wind.x * ca - wind.y * sa, wind.x * sa + wind.y * ca);
    let a = amp * w.y;
    let omega = sqrt(9.81 * k);
    let phase = k * dot(dir, p) - omega * t + w.w;
    let qa = min(a, 0.15 / k);
    let cp = cos(phase);
    disp = disp + vec3<f32>(dir.x * qa * cp, a * sin(phase), dir.y * qa * cp);
  }
  return disp;
}

fn swellMask(depth : f32) -> f32 {
  return smoothstep(0.0, 1.5, depth);
}

// Analytic continuation of the simulation's wave-maker wave into the far field,
// so the endless ocean plane matches the domain at the x = 0 edge.
fn wavemakerWave(xz : vec2<f32>) -> f32 {
  let amp = U.waveParams.x;
  if (amp <= 0.0001) {
    return 0.0;
  }
  let half = U.params0.x * U.params0.y * 0.5;
  let period = max(U.waveParams.y, 0.1);
  let lambda = max(U.waveParams.w * period, 1.0);
  let phase = TAU * (U.params0.z / period - (xz.y + half) / (U.waveParams.z * 4.0) - (xz.x + half) / lambda);
  return amp * (sin(phase) * 0.85 + sin(phase * 2.0 + 0.9) * 0.15);
}

// World-space position of the fluid surface for a domain uv (includes swell)
fn surfacePoint(uv : vec2<f32>, farField : bool) -> vec3<f32> {
  let worldSize = U.params0.x * U.params0.y;
  let xz = (uv - 0.5) * worldSize;
  var h = U.params0.w;
  var mask = 1.0;
  if (!farField) {
    h = sampleField(2u, uv);
    mask = swellMask(sampleField(1u, uv));
  } else {
    h = h + wavemakerWave(xz);
  }
  let disp = gerstner(xz, U.params0.z) * mask;
  return vec3<f32>(xz.x + disp.x, h + disp.y, xz.y + disp.z);
}

fn rippleHeight(p : vec2<f32>, t : f32) -> f32 {
  let wind = U.params1.yz * (0.4 + 0.6 * U.params1.w);
  var h = valueNoise(p * 1.3 + wind * t * 0.35) * 0.5;
  h = h + valueNoise(p * 3.1 - wind.yx * t * 0.25 + vec2<f32>(3.7, 1.3)) * 0.3;
  h = h + valueNoise(p * 7.3 + wind * t * 0.5 + vec2<f32>(9.1, 4.3)) * 0.2;
  return h;
}

// ---------------------------------------------------------------------------
// Sky & tone mapping
// ---------------------------------------------------------------------------
fn skyColor(dir : vec3<f32>) -> vec3<f32> {
  let L = U.sunDir.xyz;
  let y = dir.y;
  let zenith = vec3<f32>(0.16, 0.33, 0.70);
  var col = mix(HORIZON, zenith, pow(clamp(y, 0.0, 1.0), 0.55));
  let cosS = dot(dir, L);
  let lowSun = 1.0 - clamp(L.y * 2.5, 0.0, 1.0);
  let haze = pow(max(cosS, 0.0), 6.0) * (0.25 + 0.6 * lowSun) * (1.0 - clamp(y * 2.0, 0.0, 1.0) * 0.6);
  col = col + vec3<f32>(1.0, 0.75, 0.5) * haze;
  let glow = pow(max(cosS, 0.0), 160.0) * 0.8 + pow(max(cosS, 0.0), 1200.0) * 3.0;
  let disc = smoothstep(0.99955, 0.99985, cosS) * 25.0;
  col = col + vec3<f32>(1.0, 0.93, 0.82) * (glow + disc) * U.sunDir.w;
  if (y < 0.0) {
    let g = clamp(-y * 6.0, 0.0, 1.0);
    col = mix(HORIZON * 0.9, vec3<f32>(0.22, 0.24, 0.27), g);
  }
  return col;
}

fn aces(x : vec3<f32>) -> vec3<f32> {
  let a = 2.51;
  let b = 0.03;
  let c = 2.43;
  let d = 0.59;
  let e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), vec3<f32>(0.0), vec3<f32>(1.0));
}

fn heat(x : f32) -> vec3<f32> {
  let c0 = vec3<f32>(0.05, 0.02, 0.25);
  let c1 = vec3<f32>(0.10, 0.40, 0.95);
  let c2 = vec3<f32>(0.10, 0.90, 0.50);
  let c3 = vec3<f32>(1.00, 0.90, 0.10);
  let c4 = vec3<f32>(1.00, 0.15, 0.05);
  let s = clamp(x, 0.0, 1.0) * 4.0;
  if (s < 1.0) { return mix(c0, c1, s); }
  if (s < 2.0) { return mix(c1, c2, s - 1.0); }
  if (s < 3.0) { return mix(c2, c3, s - 2.0); }
  return mix(c3, c4, s - 3.0);
}

fn caustic(uv : vec2<f32>, t : f32) -> f32 {
  let p = (uv * TAU) % TAU - vec2<f32>(250.0, 250.0);
  var i = p;
  var c = 1.0;
  let inten = 0.005;
  for (var n = 0; n < 4; n++) {
    let tt = t * (1.0 - (3.5 / f32(n + 1)));
    i = p + vec2<f32>(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
    c = c + 1.0 / length(vec2<f32>(p.x / (sin(i.x + tt) / inten), p.y / (cos(i.y + tt) / inten)));
  }
  c = c / 4.0;
  c = 1.17 - pow(c, 1.4);
  return pow(abs(c), 8.0);
}

// ---------------------------------------------------------------------------
// Fullscreen passes: sky + final tonemap
// ---------------------------------------------------------------------------
struct FSQOut {
  @builtin(position) pos : vec4<f32>,
  @location(0) ndc : vec2<f32>,
};

@vertex
fn vsFullscreen(@builtin(vertex_index) vi : u32) -> FSQOut {
  var p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  var out : FSQOut;
  out.pos = vec4<f32>(p[vi], 0.99999, 1.0);
  out.ndc = p[vi];
  return out;
}

@fragment
fn fsSky(in : FSQOut) -> @location(0) vec4<f32> {
  let th = U.cameraPos.w;
  let aspect = U.camRight.w;
  let dir = normalize(U.camForward.xyz + U.camRight.xyz * (in.ndc.x * th * aspect) + U.camUp.xyz * (in.ndc.y * th));
  return vec4<f32>(skyColor(dir), 1.0);
}

@fragment
fn fsBlit(in : FSQOut) -> @location(0) vec4<f32> {
  let c = textureLoad(sceneTex, vec2<i32>(in.pos.xy), 0).rgb;
  var col = aces(c);
  let v = 1.0 - 0.22 * dot(in.ndc * 0.7, in.ndc * 0.7);
  col = col * v;
  return vec4<f32>(pow(col, vec3<f32>(1.0 / 2.2)), 1.0);
}

// ---------------------------------------------------------------------------
// Terrain
// ---------------------------------------------------------------------------
struct VSOut {
  @builtin(position) pos : vec4<f32>,
  @location(0) world : vec3<f32>,
  @location(1) uv : vec2<f32>,
  @location(2) skirt : f32,
};

@vertex
fn vsTerrain(@location(0) uvIn : vec2<f32>) -> VSOut {
  let worldSize = U.params0.x * U.params0.y;
  let inside = uvIn.x >= 0.0 && uvIn.y >= 0.0 && uvIn.x <= 1.0 && uvIn.y <= 1.0;
  let cuv = clamp(uvIn, vec2<f32>(0.0), vec2<f32>(1.0));
  let xz = (cuv - 0.5) * worldSize;
  var h = sampleField(0u, cuv);
  var skirt = 0.0;
  if (!inside) {
    h = U.misc.y;
    skirt = 1.0;
  }
  var out : VSOut;
  out.world = vec3<f32>(xz.x, h, xz.y);
  out.uv = cuv;
  out.skirt = skirt;
  out.pos = U.viewProj * vec4<f32>(out.world, 1.0);
  return out;
}

fn terrainNormal(uv : vec2<f32>) -> vec3<f32> {
  let n = U.params0.x;
  let cell = U.params0.y;
  let e = 1.0 / n;
  let hx1 = sampleField(0u, uv + vec2<f32>(e, 0.0));
  let hx0 = sampleField(0u, uv - vec2<f32>(e, 0.0));
  let hz1 = sampleField(0u, uv + vec2<f32>(0.0, e));
  let hz0 = sampleField(0u, uv - vec2<f32>(0.0, e));
  return normalize(vec3<f32>(hx0 - hx1, 2.0 * cell, hz0 - hz1));
}

@fragment
fn fsTerrain(in : VSOut) -> @location(0) vec4<f32> {
  let L = U.sunDir.xyz;
  let V = normalize(U.cameraPos.xyz - in.world);
  let ddx = dpdx(in.world);
  let ddy = dpdy(in.world);
  var N = terrainNormal(in.uv);
  if (in.skirt > 0.5) {
    N = normalize(cross(ddx, ddy));
    if (dot(N, V) < 0.0) { N = -N; }
  }
  let seaLevel = U.params0.w;
  let depth = sampleField(1u, in.uv);
  let wet = sampleField(4u, in.uv);
  let t = U.params0.z;
  let slope = 1.0 - N.y;
  let detail = 0.8 + 0.4 * valueNoise(in.world.xz * 2.3);
  let detail2 = 0.9 + 0.2 * valueNoise(in.world.xz * 11.0);

  var base : vec3<f32>;
  if (U.misc.x < 0.5) {
    let sand = vec3<f32>(0.78, 0.70, 0.52);
    let grass = vec3<f32>(0.30, 0.44, 0.17);
    let rock = vec3<f32>(0.46, 0.43, 0.40);
    let hRel = in.world.y - seaLevel;
    base = mix(sand, grass, smoothstep(0.6, 1.8, hRel + 0.6 * fbm(in.world.xz * 0.15, 3)));
    base = mix(base, rock, smoothstep(0.25, 0.55, slope));
  } else {
    let dirt = vec3<f32>(0.46, 0.36, 0.26);
    let dark = vec3<f32>(0.30, 0.23, 0.17);
    let pebble = vec3<f32>(0.52, 0.50, 0.46);
    base = mix(dirt, dark, 0.5 + 0.5 * fbm(in.world.xz * 0.4, 3));
    base = mix(base, pebble, smoothstep(0.35, 0.6, slope));
  }
  if (in.skirt > 0.5) {
    base = base * 0.7;
  }
  base = base * detail * detail2;

  let wetness = max(wet, clamp(depth * 40.0, 0.0, 1.0));
  base = base * mix(1.0, 0.55, wetness);

  let NdotL = max(dot(N, L), 0.0);
  let sunCol = vec3<f32>(1.0, 0.95, 0.88) * U.sunDir.w;
  let skyAmb = mix(vec3<f32>(0.30, 0.34, 0.38), vec3<f32>(0.42, 0.52, 0.70), 0.5 + 0.5 * N.y);
  var col = base * (skyAmb * 0.9 + sunCol * NdotL * 1.5);

  // Caustics on submerged ground (water only)
  if (depth > 0.003 && U.params2.x < 0.5) {
    let ca = caustic(in.world.xz * 0.035, t * 0.6);
    let cb = caustic(in.world.xz * 0.05 + vec2<f32>(3.1, 1.7), t * 0.45 + 2.0);
    let cstr = clamp(depth * 25.0, 0.0, 1.0) * exp(-depth * 0.45) * NdotL;
    col = col + sunCol * (ca + cb) * 0.6 * cstr;
  }
  // Light attenuated by the fluid column above the ground
  col = col * exp(-U.absorb.rgb * depth * 0.8);

  // Wet sheen
  let H = normalize(L + V);
  let spec = pow(max(dot(N, H), 0.0), 48.0) * wetness * 0.35;
  col = col + sunCol * spec;

  let dist = length(U.cameraPos.xyz - in.world);
  let fog = 1.0 - exp(-dist * 0.0015);
  col = mix(col, HORIZON, fog * 0.9);
  return vec4<f32>(col, 1.0);
}

// ---------------------------------------------------------------------------
// Water / mud surface
// ---------------------------------------------------------------------------
@vertex
fn vsWater(@location(0) uvIn : vec2<f32>) -> VSOut {
  let worldSize = U.params0.x * U.params0.y;
  var out : VSOut;
  if (D.mode == 1u) {
    // Far-field ocean: cubic mapping gives dense tessellation near the domain
    let q = (uvIn - 0.5) * 2.0;
    let off = q * abs(q) * abs(q) * U.params2.w;
    let uv = off / worldSize + 0.5;
    let p = surfacePoint(uv, true);
    out.world = p;
    out.uv = uv;
    out.skirt = 0.0;
    out.pos = U.viewProj * vec4<f32>(p, 1.0);
    return out;
  }
  let inside = uvIn.x >= 0.0 && uvIn.y >= 0.0 && uvIn.x <= 1.0 && uvIn.y <= 1.0;
  let cuv = clamp(uvIn, vec2<f32>(0.0), vec2<f32>(1.0));
  var p = surfacePoint(cuv, false);
  let depth = sampleField(1u, cuv);
  var skirt = 0.0;
  if (!inside) {
    // Cross-section wall down to the terrain at the domain border
    p.y = sampleField(0u, cuv) - 0.01;
    skirt = 1.0;
  } else if (depth < 0.0005) {
    p.y = p.y - 0.02;
  }
  out.world = p;
  out.uv = cuv;
  out.skirt = skirt;
  out.pos = U.viewProj * vec4<f32>(p, 1.0);
  return out;
}

@fragment
fn fsWater(in : VSOut) -> @location(0) vec4<f32> {
  let far = D.mode == 1u;
  if (far && in.uv.x > 0.0 && in.uv.x < 1.0 && in.uv.y > 0.0 && in.uv.y < 1.0) {
    discard;
  }
  let worldSize = U.params0.x * U.params0.y;
  let cell = U.params0.y;
  let t = U.params0.z;
  let isMud = U.params2.x > 0.5;
  let L = U.sunDir.xyz;
  let camPos = U.cameraPos.xyz;
  let toCam = camPos - in.world;
  let dist = length(toCam);
  let V = toCam / max(dist, 0.001);

  // Geometric normal from the displaced surface function
  let e = max(cell * 0.5, dist * 0.0015) / worldSize;
  let pX1 = surfacePoint(in.uv + vec2<f32>(e, 0.0), far);
  let pX0 = surfacePoint(in.uv - vec2<f32>(e, 0.0), far);
  let pZ1 = surfacePoint(in.uv + vec2<f32>(0.0, e), far);
  let pZ0 = surfacePoint(in.uv - vec2<f32>(0.0, e), far);
  var N = normalize(cross(pZ1 - pZ0, pX1 - pX0));

  var depth = 30.0;
  var foam = 0.0;
  var vel = vec2<f32>(0.0);
  if (!far) {
    depth = sampleField(1u, in.uv);
    foam = sampleField(3u, in.uv);
    vel = sampleVelocity(in.uv);
  }

  // Wind ripples (detail normal)
  let rippleAmp = U.misc.z * clamp(U.params1.w / 4.0, 0.0, 1.0) * (1.0 - exp(-depth * 12.0)) / (1.0 + dist * 0.02);
  if (rippleAmp > 0.0001) {
    let re = 0.08;
    let r0 = rippleHeight(in.world.xz, t);
    let rx = rippleHeight(in.world.xz + vec2<f32>(re, 0.0), t);
    let rz = rippleHeight(in.world.xz + vec2<f32>(0.0, re), t);
    let g = vec2<f32>(rx - r0, rz - r0) / re * rippleAmp * 0.02;
    N = normalize(vec3<f32>(N.x - g.x, N.y, N.z - g.y));
  }

  let NdotV = clamp(dot(N, V), 0.0, 1.0);
  let F0 = select(0.02, 0.04, isMud);
  let fres = F0 + (1.0 - F0) * pow(1.0 - NdotV, 5.0);

  // Reflection
  var R = reflect(-V, N);
  R.y = max(R.y, 0.02);
  R = normalize(R);
  var refl = skyColor(R);
  let rough = clamp(U.scatter.w, 0.0, 1.0);
  refl = mix(refl, vec3<f32>(0.45, 0.52, 0.62), rough * 0.8);

  // Sun specular (normalised Blinn-Phong)
  let H = normalize(L + V);
  let shin = mix(1800.0, 16.0, rough);
  let spec = pow(max(dot(N, H), 0.0), shin) * (shin + 8.0) / 50.0;
  let sunCol = vec3<f32>(1.0, 0.95, 0.85) * U.sunDir.w;

  // Refraction: distort the scene behind the surface
  let screenUV = in.pos.xy * U.screen.zw;
  let refrStrength = U.absorb.w * 0.06 * clamp(depth * 3.0, 0.0, 1.0) / (1.0 + dist * 0.01);
  let refrUV = clamp(screenUV + N.xz * refrStrength, vec2<f32>(0.001), vec2<f32>(0.999));
  let sceneCol = textureSampleLevel(sceneTex, sceneSampler, refrUV, 0.0).rgb;

  // Absorption / in-scattering along the view path
  let path = depth * mix(2.5, 1.0, NdotV);
  let T = exp(-U.absorb.rgb * path);
  let body = U.scatter.rgb * (0.6 + 0.8 * clamp(L.y, 0.0, 1.0));
  var under = sceneCol * T + body * (1.0 - T);
  let NdotL = max(dot(N, L), 0.0);
  if (isMud) {
    let mudShade = 0.35 + 0.75 * NdotL * U.sunDir.w;
    let mudCol = U.scatter.rgb * (0.85 + 0.3 * valueNoise(in.world.xz * 1.7));
    under = mix(sceneCol, mudCol * mudShade, clamp(depth / 0.05, 0.0, 1.0));
  }

  // Subsurface light through wave crests
  let crest = clamp((in.world.y - U.params0.w) / (U.params1.x * 1.5 + 0.4), 0.0, 1.0);
  let sssMask = select(1.0, 0.0, isMud) * clamp(depth, 0.0, 1.0);
  let sss = body * 1.5 * pow(max(dot(V, -L), 0.0), 3.0) * crest * (1.0 - fres) * sssMask;

  var col = mix(under, refl, fres) + sunCol * spec * select(1.0, 0.12, isMud) + sss;

  // Foam
  if (!isMud) {
    let shore = (1.0 - smoothstep(0.0, 0.25, depth)) * step(0.002, depth) * clamp(length(vel) * 2.0, 0.0, 1.0);
    var foamAmt = (foam + shore * 0.6) * U.params2.y;
    foamAmt = foamAmt + smoothstep(0.75, 1.0, crest) * U.params2.y * step(0.001, U.params1.x) * 0.5 * clamp(depth, 0.0, 1.0);
    let ftex = 0.5 + 0.5 * fbm(in.world.xz * 1.8 + vec2<f32>(t * 0.2, -t * 0.15), 3);
    let fmask = clamp(foamAmt * 1.6 - ftex * 0.9, 0.0, 1.0);
    let foamCol = vec3<f32>(0.92, 0.95, 0.97) * (0.45 + 0.7 * NdotL * U.sunDir.w);
    col = mix(col, foamCol, fmask);
  }

  // Atmospheric fade
  let fog = 1.0 - exp(-dist * 0.0015);
  col = mix(col, HORIZON, fog * 0.9);

  var alpha = clamp(depth / max(U.misc.w, 0.0005), 0.0, 1.0);
  if (far) {
    alpha = 1.0;
  }
  if (in.skirt > 0.5) {
    alpha = min(alpha, 0.9);
  }

  // Debug views
  let dbg = U.params2.z;
  if (dbg > 0.5 && !far) {
    var c = vec3<f32>(0.0);
    if (dbg < 1.5) {
      c = heat(clamp(depth / 3.0, 0.0, 1.0));
    } else if (dbg < 2.5) {
      c = vec3<f32>(0.5 + 0.5 * clamp(vel / 3.0, vec2<f32>(-1.0), vec2<f32>(1.0)), length(vel) / 4.0);
    } else {
      c = vec3<f32>(foam, foam * 0.6, 0.2);
    }
    return vec4<f32>(c, select(0.0, 1.0, depth > 0.0005));
  }
  return vec4<f32>(col, alpha);
}
`;
