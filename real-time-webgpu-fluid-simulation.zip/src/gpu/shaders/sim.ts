import { noiseWGSL } from './noise';

/**
 * Shallow-water heightfield solver (virtual-pipe / staggered flux formulation).
 *
 * Per cell we store: terrain height b, fluid depth d, outgoing fluxes (L, R, B, T),
 * a derived velocity and auxiliary channels (foam, wetness).
 *
 * Pass 1 (fluxPass): dq/dt = g * d * dEta  (momentum, upwind depth -> wave speed sqrt(g d))
 * Pass 2 (heightPass): dd/dt = -div(q)      (mass conservation)
 * Pass 0 (sourcePass): rain, evaporation, inflow, drains, wave maker, brushes.
 *
 * Both main passes only write to their own cell, so no ping-pong buffers are needed.
 */
export const simShader = /* wgsl */ `
struct SimParams {
  gridSize : u32,       // 0
  cellSize : f32,       // 1
  dt : f32,             // 2  sub-step dt
  frameDt : f32,        // 3  frame dt (sources)
  gravity : f32,        // 4
  viscosity : f32,      // 5
  drag : f32,           // 6
  yieldSlope : f32,     // 7
  minDepth : f32,       // 8
  rainRate : f32,       // 9
  rainDrop : f32,       // 10
  evaporation : f32,    // 11
  seaLevel : f32,       // 12
  waveAmp : f32,        // 13
  waveLen : f32,        // 14
  wavePeriod : f32,     // 15
  waveMaker : u32,      // 16
  time : f32,           // 17
  frame : u32,          // 18
  brushMode : u32,      // 19
  brushX : f32,         // 20
  brushY : f32,         // 21
  brushRadius : f32,    // 22
  brushStrength : f32,  // 23
  brushDX : f32,        // 24
  brushDY : f32,        // 25
  foamDecay : f32,      // 26
  foamGain : f32,       // 27
  sourceRate : f32,     // 28
  sourceX : f32,        // 29
  sourceY : f32,        // 30
  sourceRadius : f32,   // 31
  drain : f32,          // 32
  maxSpeed : f32,       // 33
  pad0 : f32,           // 34
  pad1 : f32,           // 35
};

struct TerrainParams {
  gridSize : u32,       // 0
  cellSize : f32,       // 1
  terrainType : u32,    // 2
  seed : f32,           // 3
  amplitude : f32,      // 4
  frequency : f32,      // 5
  slope : f32,          // 6
  baseHeight : f32,     // 7
  channelDepth : f32,   // 8
  channelWidth : f32,   // 9
  fillType : u32,       // 10
  fillLevel : f32,      // 11
  fillExtent : f32,     // 12
  pad0 : f32,           // 13
  pad1 : f32,           // 14
  pad2 : f32,           // 15
};

@group(0) @binding(0) var<uniform> P : SimParams;
@group(0) @binding(1) var<storage, read_write> terrain : array<f32>;
@group(0) @binding(2) var<storage, read_write> water : array<f32>;
@group(0) @binding(3) var<storage, read_write> flux : array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> velocity : array<vec2<f32>>;
@group(0) @binding(5) var<storage, read_write> aux : array<vec2<f32>>;
@group(0) @binding(6) var<uniform> T : TerrainParams;

${noiseWGSL}

fn cellIndex(x : i32, y : i32) -> u32 {
  return u32(y) * P.gridSize + u32(x);
}

fn surfaceAt(x : i32, y : i32) -> f32 {
  let i = cellIndex(x, y);
  return terrain[i] + water[i];
}

fn fluxAt(x : i32, y : i32) -> vec4<f32> {
  let n = i32(P.gridSize);
  if (x < 0 || y < 0 || x >= n || y >= n) {
    return vec4<f32>(0.0);
  }
  return flux[cellIndex(x, y)];
}

// ---------------------------------------------------------------------------
// Terrain generation
// ---------------------------------------------------------------------------
fn terrainHeight(u : f32, v : f32) -> f32 {
  let worldSize = f32(T.gridSize) * T.cellSize;
  let c = vec2<f32>(u - 0.5, v - 0.5);
  let np = vec2<f32>(u, v) * T.frequency + vec2<f32>(T.seed * 13.7, T.seed * 7.3);
  var h = T.baseHeight;
  let t = T.terrainType;
  if (t == 0u) {
    // Pond basin
    let r = length(c) * 2.0;
    let bowl = smoothstep(0.0, 1.0, r * 0.9);
    h = h + mix(-T.amplitude, 0.9, bowl * bowl);
    h = h + 0.06 * fbm(np, 4) + 0.03 * fbm(np * 4.0, 3);
  } else if (t == 1u) {
    // Beach: deep at u = 0, dry sand at u = 1
    let prof = smoothstep(0.0, 1.0, u);
    h = h + mix(-T.amplitude, T.slope, prof);
    h = h + 0.22 * fbm(np, 4) * smoothstep(0.25, 0.75, u);
    h = h + 0.12 * fbm(np * 3.0 + vec2<f32>(2.0, 2.0), 3);
    let sb = (u - 0.42) / 0.05;
    h = h + 0.45 * exp(-sb * sb);
    h = h + T.slope * 0.4 * smoothstep(0.85, 1.0, u);
  } else if (t == 2u) {
    // Bumpy ground
    h = h + T.amplitude * fbm(np, 5);
    h = h + 0.35 * T.amplitude * fbm(np * 3.1 + vec2<f32>(5.0, 5.0), 3);
    h = h + 0.6 * T.amplitude * fbm(np * 0.35 + vec2<f32>(9.0, 9.0), 2);
  } else if (t == 3u) {
    // Hillside with a meandering channel
    h = h + T.slope * (1.0 - u) * worldSize;
    let meander = 0.07 * sin(u * 8.0 + T.seed);
    let q = (c.y - meander) / T.channelWidth;
    let chan = exp(-q * q);
    h = h - T.channelDepth * chan;
    h = h + T.amplitude * fbm(np, 5) * (1.0 - 0.7 * chan);
    h = h + 0.25 * T.amplitude * fbm(np * 4.0, 3) * chan;
  } else {
    h = h + T.amplitude * fbm(np, 6);
  }
  return h;
}

@compute @workgroup_size(8, 8, 1)
fn initPass(@builtin(global_invocation_id) gid : vec3<u32>) {
  let n = i32(T.gridSize);
  let x = i32(gid.x);
  let y = i32(gid.y);
  if (x >= n || y >= n) { return; }
  let i = u32(y) * T.gridSize + u32(x);
  let u = (f32(x) + 0.5) / f32(n);
  let v = (f32(y) + 0.5) / f32(n);
  let b = terrainHeight(u, v);
  var d = 0.0;
  if (T.fillType == 1u) {
    d = max(T.fillLevel - b, 0.0);
  } else if (T.fillType == 2u) {
    let q = (v - 0.5) / (T.channelWidth * 1.6);
    let chan = exp(-q * q);
    let along = (1.0 - smoothstep(T.fillExtent - 0.1, T.fillExtent, u)) * smoothstep(0.0, 0.05, u);
    d = T.fillLevel * along * chan;
  }
  terrain[i] = b;
  water[i] = d;
  flux[i] = vec4<f32>(0.0);
  velocity[i] = vec2<f32>(0.0);
  aux[i] = vec2<f32>(0.0, step(0.0001, d));
}

// ---------------------------------------------------------------------------
// Sources: rain, evaporation, inflow, drain, wave maker, brushes (once per frame)
// ---------------------------------------------------------------------------
@compute @workgroup_size(8, 8, 1)
fn sourcePass(@builtin(global_invocation_id) gid : vec3<u32>) {
  let n = i32(P.gridSize);
  let x = i32(gid.x);
  let y = i32(gid.y);
  if (x >= n || y >= n) { return; }
  let i = cellIndex(x, y);
  let dx = P.cellSize;
  let dt = P.frameDt;
  var d = water[i];
  var b = terrain[i];
  var f = flux[i];
  let fx = f32(x);
  let fy = f32(y);
  let nf = f32(n);

  // Rain
  if (P.rainRate > 0.0) {
    let seed = vec2<f32>(f32(P.frame % 4096u) * 0.618, f32(P.frame % 977u) * 0.3247);
    let r = hash21(vec2<f32>(fx, fy) * 0.37 + seed);
    if (r < P.rainRate * dx * dx * dt) {
      d = d + P.rainDrop;
    }
  }

  // Evaporation
  if (P.evaporation > 0.0) {
    d = max(d - P.evaporation * dt, 0.0);
  }

  // Inflow source
  if (P.sourceRate > 0.0) {
    let sp = vec2<f32>(P.sourceX, P.sourceY) * nf;
    let dist = distance(vec2<f32>(fx + 0.5, fy + 0.5), sp) * dx;
    if (dist < P.sourceRadius) {
      let w = 1.0 - smoothstep(0.0, P.sourceRadius, dist);
      d = d + P.sourceRate * dt * w;
    }
  }

  // Drain along the far edge (x = n - 1)
  if (P.drain > 0.0 && x > n - 7) {
    let k = 1.0 - P.drain * f32(x - (n - 7)) / 6.0;
    d = d * k;
    f = f * k;
  }

  // Wave maker along the x = 0 edge
  if (P.waveMaker == 1u && x < 5) {
    let phase = 6.2831853 * (P.time / P.wavePeriod - fy * dx / (P.waveLen * 4.0));
    let targetEta = P.seaLevel + P.waveAmp * (sin(phase) * 0.85 + sin(phase * 2.0 + 0.9) * 0.15);
    let targetDepth = max(targetEta - b, 0.0);
    let strength = 0.45 * (1.0 - fx / 5.0);
    d = mix(d, targetDepth, strength);
  }

  // Brush interaction
  if (P.brushMode != 0u) {
    let delta = vec2<f32>(fx + 0.5 - P.brushX, fy + 0.5 - P.brushY);
    let dist = length(delta);
    if (dist < P.brushRadius) {
      let w = 1.0 - smoothstep(0.0, P.brushRadius, dist);
      let s = P.brushStrength;
      if (P.brushMode == 1u) {
        d = d + s * 1.5 * w * dt;
      } else if (P.brushMode == 2u) {
        d = max(d - s * 1.5 * w * dt, 0.0);
      } else if (P.brushMode == 3u) {
        let push = s * 0.8 * w * d * dx;
        if (P.brushDX > 0.0) { f.y = f.y + push * P.brushDX; } else { f.x = f.x - push * P.brushDX; }
        if (P.brushDY > 0.0) { f.w = f.w + push * P.brushDY; } else { f.z = f.z - push * P.brushDY; }
      } else if (P.brushMode == 4u) {
        b = b + s * 0.6 * w * dt;
      } else if (P.brushMode == 5u) {
        b = b - s * 0.6 * w * dt;
      } else if (P.brushMode == 6u) {
        // Splash impulse: push the surface down and shove fluid outwards
        let bump = cos(dist / P.brushRadius * 1.5707963);
        let wetMask = step(0.001, d);
        d = max(d - s * 0.14 * bump * wetMask, 0.0);
        let dirv = delta / max(dist, 0.5);
        let imp = s * 0.5 * w * d * dx;
        if (dirv.x > 0.0) { f.y = f.y + imp * dirv.x; } else { f.x = f.x - imp * dirv.x; }
        if (dirv.y > 0.0) { f.w = f.w + imp * dirv.y; } else { f.z = f.z - imp * dirv.y; }
      }
    }
  }

  water[i] = clamp(d, 0.0, 60.0);
  terrain[i] = b;
  flux[i] = max(f, vec4<f32>(0.0));
}

// ---------------------------------------------------------------------------
// Momentum / flux update
// ---------------------------------------------------------------------------
@compute @workgroup_size(8, 8, 1)
fn fluxPass(@builtin(global_invocation_id) gid : vec3<u32>) {
  let n = i32(P.gridSize);
  let x = i32(gid.x);
  let y = i32(gid.y);
  if (x >= n || y >= n) { return; }
  let i = cellIndex(x, y);
  let d = water[i];
  let eta = terrain[i] + d;
  var f = flux[i];
  let dx = P.cellSize;

  var dh = vec4<f32>(0.0);
  if (x > 0)     { dh.x = eta - surfaceAt(x - 1, y); }
  if (x < n - 1) { dh.y = eta - surfaceAt(x + 1, y); }
  if (y > 0)     { dh.z = eta - surfaceAt(x, y - 1); }
  if (y < n - 1) { dh.w = eta - surfaceAt(x, y + 1); }

  // Bingham-plastic yield: no flow until the surface slope exceeds the yield slope
  let yieldH = P.yieldSlope * dx;
  if (yieldH > 0.0) {
    dh = sign(dh) * max(abs(dh) - vec4<f32>(yieldH), vec4<f32>(0.0));
  }

  // Momentum: dq/dt = g * d * dEta (upwind depth -> shallow water wave speed sqrt(g d))
  let accel = P.dt * P.gravity * max(d, 0.0);
  f = max(f + accel * dh, vec4<f32>(0.0));

  // Implicit friction: linear drag + viscosity (thin films slow down as 1 / d^2)
  let dd = max(d, 0.002);
  let damp = 1.0 / (1.0 + P.dt * (P.drag + P.viscosity / (dd * dd)));
  f = f * damp;

  if (d < P.minDepth) {
    f = vec4<f32>(0.0);
  }

  // Never drain more than the cell holds
  let total = f.x + f.y + f.z + f.w;
  let maxOut = d * dx * dx / P.dt;
  if (total > maxOut) {
    f = f * (maxOut / max(total, 1e-9));
  }
  flux[i] = f;
}

// ---------------------------------------------------------------------------
// Mass update + derived velocity, foam and wetness
// ---------------------------------------------------------------------------
@compute @workgroup_size(8, 8, 1)
fn heightPass(@builtin(global_invocation_id) gid : vec3<u32>) {
  let n = i32(P.gridSize);
  let x = i32(gid.x);
  let y = i32(gid.y);
  if (x >= n || y >= n) { return; }
  let i = cellIndex(x, y);
  let dx = P.cellSize;
  let f = flux[i];
  let fL = fluxAt(x - 1, y);
  let fR = fluxAt(x + 1, y);
  let fB = fluxAt(x, y - 1);
  let fT = fluxAt(x, y + 1);
  let inflow = fL.y + fR.x + fB.w + fT.z;
  let outflow = f.x + f.y + f.z + f.w;
  let d0 = water[i];
  var d1 = d0 + P.dt * (inflow - outflow) / (dx * dx);
  d1 = clamp(d1, 0.0, 60.0);
  water[i] = d1;

  let dAvg = max(0.5 * (d0 + d1), 1e-4);
  let wx = 0.5 * (fL.y - f.x + f.y - fR.x);
  let wy = 0.5 * (fB.w - f.z + f.w - fT.z);
  var vel = vec2<f32>(wx, wy) / (dx * dAvg);
  let speed = length(vel);
  if (speed > P.maxSpeed) {
    vel = vel * (P.maxSpeed / speed);
  }
  if (d1 < P.minDepth) {
    vel = vec2<f32>(0.0);
  }
  velocity[i] = vel;

  // Foam: fast flow + rapid surface change (breaking / impacts)
  let a = aux[i];
  let dhdt = abs(d1 - d0) / P.dt;
  let gen = P.foamGain * P.dt * (max(min(speed, P.maxSpeed) - 0.6, 0.0) * 0.5 + max(dhdt - 0.5, 0.0) * 0.4);
  var foam = a.x * exp(-P.dt * P.foamDecay) + gen * step(P.minDepth * 4.0, d1);
  foam = clamp(foam, 0.0, 1.0);

  // Wetness: saturates when covered, slowly dries out
  var wet = a.y - P.dt * 0.03;
  if (d1 > P.minDepth * 2.0) {
    wet = 1.0;
  }
  aux[i] = vec2<f32>(foam, clamp(wet, 0.0, 1.0));
}
`;
