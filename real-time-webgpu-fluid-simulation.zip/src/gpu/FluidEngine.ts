import { simShader } from './shaders/sim';
import { renderShader } from './shaders/render';
import { OrbitCamera, clamp, degToRad, type Vec3 } from './math';
import { DEFAULT_PRESET } from './presets';
import {
  DEBUG_IDS,
  TOOL_IDS,
  type EngineStats,
  type Preset,
  type RenderParams,
  type SimParams,
  type TerrainParams,
  type ToolMode,
} from './types';

export const WORLD_SIZE = 64; // metres
const WG = 8;
const FAR_FIELD_RADIUS = 2500;
const SIM_UNIFORM_SIZE = 144;
const TERRAIN_UNIFORM_SIZE = 64;
const RENDER_UNIFORM_SIZE = 272;

interface GridResources {
  n: number;
  terrain: GPUBuffer;
  water: GPUBuffer;
  flux: GPUBuffer;
  velocity: GPUBuffer;
  aux: GPUBuffer;
  staging: GPUBuffer;
  simBindGroup: GPUBindGroup;
  renderBindGroup: GPUBindGroup;
  vertexBuffer: GPUBuffer;
  indexBuffer: GPUBuffer;
  indexCount: number;
  cpuTerrain: Float32Array;
  cpuWater: Float32Array;
  cpuValid: boolean;
  generation: number;
}

interface ScreenResources {
  width: number;
  height: number;
  sceneTex: GPUTexture;
  refrTex: GPUTexture;
  depthTex: GPUTexture;
  sceneView: GPUTextureView;
  refrView: GPUTextureView;
  depthView: GPUTextureView;
  refrBindGroup: GPUBindGroup;
  sceneBindGroup: GPUBindGroup;
}

export interface SupportInfo {
  ok: boolean;
  reason?: string;
}

export async function checkWebGPUSupport(): Promise<SupportInfo> {
  if (typeof navigator === 'undefined' || !('gpu' in navigator) || !navigator.gpu) {
    return { ok: false, reason: 'navigator.gpu is not available in this browser.' };
  }
  try {
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) return { ok: false, reason: 'No WebGPU adapter was returned (GPU blocked or unsupported).' };
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: (e as Error).message };
  }
}

export class FluidEngine {
  readonly canvas: HTMLCanvasElement;
  readonly camera = new OrbitCamera();

  onStats?: (s: EngineStats) => void;
  onError?: (message: string) => void;

  private device!: GPUDevice;
  private context!: GPUCanvasContext;
  private format!: GPUTextureFormat;
  private adapterName = 'Unknown GPU';

  // Layouts / pipelines
  private simLayout!: GPUBindGroupLayout;
  private renderLayout!: GPUBindGroupLayout;
  private sceneLayout!: GPUBindGroupLayout;
  private drawLayout!: GPUBindGroupLayout;
  private initPipeline!: GPUComputePipeline;
  private sourcePipeline!: GPUComputePipeline;
  private fluxPipeline!: GPUComputePipeline;
  private heightPipeline!: GPUComputePipeline;
  private skyPipeline!: GPURenderPipeline;
  private terrainPipeline!: GPURenderPipeline;
  private waterPipeline!: GPURenderPipeline;
  private blitPipeline!: GPURenderPipeline;

  // Uniforms
  private simUniform!: GPUBuffer;
  private terrainUniform!: GPUBuffer;
  private renderUniform!: GPUBuffer;
  private drawUniforms: GPUBuffer[] = [];
  private drawBindGroups: GPUBindGroup[] = [];
  private sampler!: GPUSampler;
  private simData = new ArrayBuffer(SIM_UNIFORM_SIZE);
  private simF = new Float32Array(this.simData);
  private simU = new Uint32Array(this.simData);
  private renderF = new Float32Array(RENDER_UNIFORM_SIZE / 4);

  private grid: GridResources | null = null;
  private screen: ScreenResources | null = null;
  private gridGeneration = 0;

  // State
  gridSize = 256;
  sim: SimParams = { ...DEFAULT_PRESET.sim };
  render: RenderParams = { ...DEFAULT_PRESET.render };
  terrain: TerrainParams = { ...DEFAULT_PRESET.terrain };
  tool: ToolMode = 'splash';
  brushRadius = 2.5; // metres
  brushStrength = 1;
  paused = false;
  renderScale = 1;

  private simTime = 0;
  private frameIndex = 0;
  private lastTime = 0;
  private raf = 0;
  private destroyed = false;
  private readbackPending = false;
  private statsAccumTime = 0;
  private statsFrames = 0;
  private fpsEma = 60;
  private lastSubsteps = 1;

  // Input
  private dragMode: 'none' | 'orbit' | 'pan' | 'brush' = 'none';
  private lastPointer = { x: 0, y: 0 };
  private brush = { active: false, gx: 0, gy: 0, dx: 0, dy: 0, lastSplash: 0, splashQueued: false, hasPrev: false };
  private cleanupFns: Array<() => void> = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
  }

  // ---------------------------------------------------------------------------
  // Initialisation
  // ---------------------------------------------------------------------------
  async init(): Promise<void> {
    if (!navigator.gpu) throw new Error('WebGPU is not supported in this browser.');
    const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
    if (!adapter) throw new Error('Could not acquire a WebGPU adapter.');
    const info = (adapter as GPUAdapter & { info?: GPUAdapterInfo }).info;
    if (info) {
      this.adapterName = [info.description, info.vendor, info.architecture].filter(Boolean).join(' · ') || 'GPU';
    }
    this.device = await adapter.requestDevice();
    this.device.lost.then((l) => {
      if (!this.destroyed) this.onError?.(`WebGPU device lost: ${l.message}`);
    });
    this.device.addEventListener('uncapturederror', (ev) => {
      const e = (ev as GPUUncapturedErrorEvent).error;
      console.error('[WebGPU]', e.message);
    });

    const ctx = this.canvas.getContext('webgpu');
    if (!ctx) throw new Error('Could not create a WebGPU canvas context.');
    this.context = ctx;
    this.format = navigator.gpu.getPreferredCanvasFormat();
    this.context.configure({ device: this.device, format: this.format, alphaMode: 'opaque' });

    await this.createStaticResources();
    this.createGridResources(this.gridSize);
    this.resizeIfNeeded(true);
    this.applyPreset(DEFAULT_PRESET);
    this.attachInput();
    this.lastTime = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  private async compileModule(code: string, label: string): Promise<GPUShaderModule> {
    const module = this.device.createShaderModule({ code, label });
    const info = await module.getCompilationInfo();
    const errors = info.messages.filter((m) => m.type === 'error');
    for (const m of info.messages) {
      const fn = m.type === 'error' ? console.error : console.warn;
      fn(`[${label}] ${m.type} at ${m.lineNum}:${m.linePos}: ${m.message}`);
    }
    if (errors.length) {
      throw new Error(`${label} shader failed to compile: ${errors.map((e) => `L${e.lineNum}: ${e.message}`).join(' | ')}`);
    }
    return module;
  }

  private async createStaticResources() {
    const d = this.device;
    d.pushErrorScope('validation');

    const simModule = await this.compileModule(simShader, 'sim');
    const renderModule = await this.compileModule(renderShader, 'render');

    this.simLayout = d.createBindGroupLayout({
      label: 'sim-layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } },
        { binding: 1, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
        { binding: 2, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
        { binding: 3, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
        { binding: 4, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
        { binding: 5, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
        { binding: 6, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } },
      ],
    });
    const VF = GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT;
    this.renderLayout = d.createBindGroupLayout({
      label: 'render-layout',
      entries: [
        { binding: 0, visibility: VF, buffer: { type: 'uniform' } },
        { binding: 1, visibility: VF, buffer: { type: 'read-only-storage' } },
        { binding: 2, visibility: VF, buffer: { type: 'read-only-storage' } },
        { binding: 3, visibility: VF, buffer: { type: 'read-only-storage' } },
        { binding: 4, visibility: VF, buffer: { type: 'read-only-storage' } },
      ],
    });
    this.sceneLayout = d.createBindGroupLayout({
      label: 'scene-layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float' } },
        { binding: 1, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
      ],
    });
    this.drawLayout = d.createBindGroupLayout({
      label: 'draw-layout',
      entries: [{ binding: 0, visibility: VF, buffer: { type: 'uniform' } }],
    });

    const simPipelineLayout = d.createPipelineLayout({ bindGroupLayouts: [this.simLayout] });
    const mkCompute = (entryPoint: string) =>
      d.createComputePipeline({
        label: entryPoint,
        layout: simPipelineLayout,
        compute: { module: simModule, entryPoint },
      });
    this.initPipeline = mkCompute('initPass');
    this.sourcePipeline = mkCompute('sourcePass');
    this.fluxPipeline = mkCompute('fluxPass');
    this.heightPipeline = mkCompute('heightPass');

    const hdr: GPUTextureFormat = 'rgba16float';
    const gridVertexLayout: GPUVertexBufferLayout = {
      arrayStride: 8,
      attributes: [{ shaderLocation: 0, offset: 0, format: 'float32x2' }],
    };

    this.skyPipeline = d.createRenderPipeline({
      label: 'sky',
      layout: d.createPipelineLayout({ bindGroupLayouts: [this.renderLayout] }),
      vertex: { module: renderModule, entryPoint: 'vsFullscreen' },
      fragment: { module: renderModule, entryPoint: 'fsSky', targets: [{ format: hdr }] },
      primitive: { topology: 'triangle-list' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: false, depthCompare: 'always' },
    });

    this.terrainPipeline = d.createRenderPipeline({
      label: 'terrain',
      layout: d.createPipelineLayout({ bindGroupLayouts: [this.renderLayout] }),
      vertex: { module: renderModule, entryPoint: 'vsTerrain', buffers: [gridVertexLayout] },
      fragment: { module: renderModule, entryPoint: 'fsTerrain', targets: [{ format: hdr }] },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less' },
    });

    this.waterPipeline = d.createRenderPipeline({
      label: 'water',
      layout: d.createPipelineLayout({
        bindGroupLayouts: [this.renderLayout, this.sceneLayout, this.drawLayout],
      }),
      vertex: { module: renderModule, entryPoint: 'vsWater', buffers: [gridVertexLayout] },
      fragment: {
        module: renderModule,
        entryPoint: 'fsWater',
        targets: [
          {
            format: hdr,
            blend: {
              color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' },
              alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' },
            },
          },
        ],
      },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth24plus', depthWriteEnabled: true, depthCompare: 'less' },
    });

    this.blitPipeline = d.createRenderPipeline({
      label: 'blit',
      layout: d.createPipelineLayout({ bindGroupLayouts: [this.renderLayout, this.sceneLayout] }),
      vertex: { module: renderModule, entryPoint: 'vsFullscreen' },
      fragment: { module: renderModule, entryPoint: 'fsBlit', targets: [{ format: this.format }] },
      primitive: { topology: 'triangle-list' },
    });

    this.simUniform = d.createBuffer({
      size: SIM_UNIFORM_SIZE,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    this.terrainUniform = d.createBuffer({
      size: TERRAIN_UNIFORM_SIZE,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    this.renderUniform = d.createBuffer({
      size: RENDER_UNIFORM_SIZE,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    for (let mode = 0; mode < 2; mode++) {
      const buf = d.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      d.queue.writeBuffer(buf, 0, new Uint32Array([mode, 0, 0, 0]));
      this.drawUniforms.push(buf);
      this.drawBindGroups.push(
        d.createBindGroup({ layout: this.drawLayout, entries: [{ binding: 0, resource: { buffer: buf } }] }),
      );
    }
    this.sampler = d.createSampler({
      magFilter: 'linear',
      minFilter: 'linear',
      addressModeU: 'clamp-to-edge',
      addressModeV: 'clamp-to-edge',
    });

    const err = await d.popErrorScope();
    if (err) throw new Error(`WebGPU validation error during setup: ${err.message}`);
  }

  private createGridResources(n: number) {
    const d = this.device;
    const old = this.grid;
    if (old) {
      const { staging, generation } = old;
      old.terrain.destroy();
      old.water.destroy();
      old.flux.destroy();
      old.velocity.destroy();
      old.aux.destroy();
      old.vertexBuffer.destroy();
      old.indexBuffer.destroy();
      if (!this.readbackPending) staging.destroy();
      else this.pendingStagingDestroy.push({ staging, generation });
    }
    const cells = n * n;
    const mk = (bytes: number, label: string, extra = 0) =>
      d.createBuffer({ label, size: bytes, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | extra });
    const terrain = mk(cells * 4, 'terrain', GPUBufferUsage.COPY_SRC);
    const water = mk(cells * 4, 'water', GPUBufferUsage.COPY_SRC);
    const flux = mk(cells * 16, 'flux');
    const velocity = mk(cells * 8, 'velocity');
    const aux = mk(cells * 8, 'aux');
    const staging = d.createBuffer({
      label: 'staging',
      size: cells * 8,
      usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
    });

    const simBindGroup = d.createBindGroup({
      layout: this.simLayout,
      entries: [
        { binding: 0, resource: { buffer: this.simUniform } },
        { binding: 1, resource: { buffer: terrain } },
        { binding: 2, resource: { buffer: water } },
        { binding: 3, resource: { buffer: flux } },
        { binding: 4, resource: { buffer: velocity } },
        { binding: 5, resource: { buffer: aux } },
        { binding: 6, resource: { buffer: this.terrainUniform } },
      ],
    });
    const renderBindGroup = d.createBindGroup({
      layout: this.renderLayout,
      entries: [
        { binding: 0, resource: { buffer: this.renderUniform } },
        { binding: 1, resource: { buffer: terrain } },
        { binding: 2, resource: { buffer: water } },
        { binding: 3, resource: { buffer: velocity } },
        { binding: 4, resource: { buffer: aux } },
      ],
    });

    // Grid mesh with a one-cell skirt ring outside [0, 1]
    const M = Math.min(n, 512);
    const V = M + 3;
    const verts = new Float32Array(V * V * 2);
    for (let j = 0; j < V; j++) {
      for (let i = 0; i < V; i++) {
        const k = (j * V + i) * 2;
        verts[k] = (i - 1) / M;
        verts[k + 1] = (j - 1) / M;
      }
    }
    const quads = (V - 1) * (V - 1);
    const indices = new Uint32Array(quads * 6);
    let p = 0;
    for (let j = 0; j < V - 1; j++) {
      for (let i = 0; i < V - 1; i++) {
        const a = j * V + i;
        const b = a + 1;
        const c = a + V;
        const e = c + 1;
        indices[p++] = a;
        indices[p++] = c;
        indices[p++] = b;
        indices[p++] = b;
        indices[p++] = c;
        indices[p++] = e;
      }
    }
    const vertexBuffer = d.createBuffer({
      label: 'grid-vb',
      size: verts.byteLength,
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
    });
    d.queue.writeBuffer(vertexBuffer, 0, verts);
    const indexBuffer = d.createBuffer({
      label: 'grid-ib',
      size: indices.byteLength,
      usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
    });
    d.queue.writeBuffer(indexBuffer, 0, indices);

    this.gridGeneration++;
    this.grid = {
      n,
      terrain,
      water,
      flux,
      velocity,
      aux,
      staging,
      simBindGroup,
      renderBindGroup,
      vertexBuffer,
      indexBuffer,
      indexCount: indices.length,
      cpuTerrain: new Float32Array(cells),
      cpuWater: new Float32Array(cells),
      cpuValid: false,
      generation: this.gridGeneration,
    };
    this.gridSize = n;
  }
  private pendingStagingDestroy: Array<{ staging: GPUBuffer; generation: number }> = [];

  private resizeIfNeeded(force = false) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2) * this.renderScale;
    const w = Math.max(1, Math.floor(this.canvas.clientWidth * dpr));
    const h = Math.max(1, Math.floor(this.canvas.clientHeight * dpr));
    if (!force && this.screen && this.screen.width === w && this.screen.height === h) return;
    this.canvas.width = w;
    this.canvas.height = h;
    const d = this.device;
    if (this.screen) {
      this.screen.sceneTex.destroy();
      this.screen.refrTex.destroy();
      this.screen.depthTex.destroy();
    }
    const sceneTex = d.createTexture({
      label: 'scene-hdr',
      size: [w, h],
      format: 'rgba16float',
      usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_SRC,
    });
    const refrTex = d.createTexture({
      label: 'refraction',
      size: [w, h],
      format: 'rgba16float',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST,
    });
    const depthTex = d.createTexture({
      label: 'depth',
      size: [w, h],
      format: 'depth24plus',
      usage: GPUTextureUsage.RENDER_ATTACHMENT,
    });
    const sceneView = sceneTex.createView();
    const refrView = refrTex.createView();
    const depthView = depthTex.createView();
    const refrBindGroup = d.createBindGroup({
      layout: this.sceneLayout,
      entries: [
        { binding: 0, resource: refrView },
        { binding: 1, resource: this.sampler },
      ],
    });
    const sceneBindGroup = d.createBindGroup({
      layout: this.sceneLayout,
      entries: [
        { binding: 0, resource: sceneView },
        { binding: 1, resource: this.sampler },
      ],
    });
    this.screen = { width: w, height: h, sceneTex, refrTex, depthTex, sceneView, refrView, depthView, refrBindGroup, sceneBindGroup };
  }

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------
  applyPreset(p: Preset) {
    this.sim = { ...p.sim };
    this.render = { ...p.render };
    this.terrain = { ...p.terrain };
    this.camera.yaw = p.camera.yaw;
    this.camera.pitch = p.camera.pitch;
    this.camera.distance = p.camera.distance;
    this.camera.target = [0, p.camera.targetY, 0];
    this.simTime = 0;
    this.regenerateTerrain();
  }

  setSimParams(partial: Partial<SimParams>) {
    this.sim = { ...this.sim, ...partial };
  }

  setRenderParams(partial: Partial<RenderParams>) {
    this.render = { ...this.render, ...partial };
  }

  setTerrainParams(partial: Partial<TerrainParams>) {
    this.terrain = { ...this.terrain, ...partial };
    this.regenerateTerrain();
  }

  setResolution(n: number) {
    if (n === this.gridSize || !this.device) return;
    this.createGridResources(n);
    this.regenerateTerrain();
  }

  setRenderScale(s: number) {
    this.renderScale = s;
    this.resizeIfNeeded(true);
  }

  reset() {
    this.simTime = 0;
    this.regenerateTerrain();
  }

  regenerateTerrain() {
    const g = this.grid;
    if (!g) return;
    const buf = new ArrayBuffer(TERRAIN_UNIFORM_SIZE);
    const f = new Float32Array(buf);
    const u = new Uint32Array(buf);
    const t = this.terrain;
    u[0] = g.n;
    f[1] = WORLD_SIZE / g.n;
    u[2] = t.terrainType;
    f[3] = t.seed;
    f[4] = t.amplitude;
    f[5] = t.frequency;
    f[6] = t.slope;
    f[7] = t.baseHeight;
    f[8] = t.channelDepth;
    f[9] = t.channelWidth;
    u[10] = t.fillType;
    f[11] = t.fillLevel;
    f[12] = t.fillExtent;
    this.device.queue.writeBuffer(this.terrainUniform, 0, buf);
    const enc = this.device.createCommandEncoder();
    const pass = enc.beginComputePass();
    pass.setPipeline(this.initPipeline);
    pass.setBindGroup(0, g.simBindGroup);
    const wgs = Math.ceil(g.n / WG);
    pass.dispatchWorkgroups(wgs, wgs);
    pass.end();
    this.device.queue.submit([enc.finish()]);
    g.cpuValid = false;
  }

  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    for (const fn of this.cleanupFns) fn();
    this.cleanupFns = [];
    try {
      this.device?.destroy();
    } catch {
      /* ignore */
    }
  }

  // ---------------------------------------------------------------------------
  // Frame loop
  // ---------------------------------------------------------------------------
  private frame = (now: number) => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.frame);
    const g = this.grid;
    if (!g) return;
    let dt = (now - this.lastTime) / 1000;
    if (!(dt > 0) || dt > 0.1) dt = 1 / 60;
    this.lastTime = now;
    this.resizeIfNeeded();
    const screen = this.screen!;

    const encoder = this.device.createCommandEncoder();

    // --- Simulation -----------------------------------------------------------
    const brushActive = this.brush.active || this.brush.splashQueued;
    if (!this.paused || brushActive) {
      const frameDt = Math.min(dt, 1 / 30);
      if (!this.paused) {
        this.simTime += frameDt;
        this.frameIndex++;
      }
      this.runSimulation(encoder, g, frameDt, this.paused);
    }

    // --- Rendering ------------------------------------------------------------
    this.writeRenderUniforms(screen.width, screen.height);
    const pass1 = encoder.beginRenderPass({
      colorAttachments: [
        { view: screen.sceneView, clearValue: { r: 0, g: 0, b: 0, a: 1 }, loadOp: 'clear', storeOp: 'store' },
      ],
      depthStencilAttachment: {
        view: screen.depthView,
        depthClearValue: 1,
        depthLoadOp: 'clear',
        depthStoreOp: 'store',
      },
    });
    pass1.setBindGroup(0, g.renderBindGroup);
    pass1.setPipeline(this.skyPipeline);
    pass1.draw(3);
    pass1.setPipeline(this.terrainPipeline);
    pass1.setVertexBuffer(0, g.vertexBuffer);
    pass1.setIndexBuffer(g.indexBuffer, 'uint32');
    pass1.drawIndexed(g.indexCount);
    pass1.end();

    encoder.copyTextureToTexture(
      { texture: screen.sceneTex },
      { texture: screen.refrTex },
      [screen.width, screen.height, 1],
    );

    const pass2 = encoder.beginRenderPass({
      colorAttachments: [{ view: screen.sceneView, loadOp: 'load', storeOp: 'store' }],
      depthStencilAttachment: { view: screen.depthView, depthLoadOp: 'load', depthStoreOp: 'store' },
    });
    pass2.setPipeline(this.waterPipeline);
    pass2.setBindGroup(0, g.renderBindGroup);
    pass2.setBindGroup(1, screen.refrBindGroup);
    pass2.setVertexBuffer(0, g.vertexBuffer);
    pass2.setIndexBuffer(g.indexBuffer, 'uint32');
    if (this.render.farField) {
      pass2.setBindGroup(2, this.drawBindGroups[1]);
      pass2.drawIndexed(g.indexCount);
    }
    pass2.setBindGroup(2, this.drawBindGroups[0]);
    pass2.drawIndexed(g.indexCount);
    pass2.end();

    const pass3 = encoder.beginRenderPass({
      colorAttachments: [
        {
          view: this.context.getCurrentTexture().createView(),
          clearValue: { r: 0, g: 0, b: 0, a: 1 },
          loadOp: 'clear',
          storeOp: 'store',
        },
      ],
    });
    pass3.setPipeline(this.blitPipeline);
    pass3.setBindGroup(0, g.renderBindGroup);
    pass3.setBindGroup(1, screen.sceneBindGroup);
    pass3.draw(3);
    pass3.end();

    // --- CPU readback for picking --------------------------------------------
    let doReadback = false;
    if (!this.readbackPending && (this.frameIndex % 6 === 0 || !g.cpuValid)) {
      const bytes = g.n * g.n * 4;
      encoder.copyBufferToBuffer(g.terrain, 0, g.staging, 0, bytes);
      encoder.copyBufferToBuffer(g.water, 0, g.staging, bytes, bytes);
      doReadback = true;
    }

    this.device.queue.submit([encoder.finish()]);

    if (doReadback) this.startReadback(g);

    // --- Stats ------------------------------------------------------------------
    this.fpsEma = this.fpsEma * 0.95 + (1 / dt) * 0.05;
    this.statsAccumTime += dt;
    this.statsFrames++;
    if (this.statsAccumTime >= 0.5) {
      this.onStats?.({
        fps: this.fpsEma,
        frameMs: (this.statsAccumTime / this.statsFrames) * 1000,
        substeps: this.lastSubsteps,
        gridSize: g.n,
        cells: g.n * g.n,
        adapter: this.adapterName,
      });
      this.statsAccumTime = 0;
      this.statsFrames = 0;
    }
  };

  private startReadback(g: GridResources) {
    this.readbackPending = true;
    const staging = g.staging;
    const generation = g.generation;
    staging
      .mapAsync(GPUMapMode.READ)
      .then(() => {
        const cells = g.n * g.n;
        if (!this.destroyed && this.grid && this.grid.generation === generation) {
          const arr = new Float32Array(staging.getMappedRange());
          g.cpuTerrain.set(arr.subarray(0, cells));
          g.cpuWater.set(arr.subarray(cells, cells * 2));
          g.cpuValid = true;
        }
        staging.unmap();
      })
      .catch(() => {
        /* buffer destroyed or device lost */
      })
      .finally(() => {
        this.readbackPending = false;
        for (const p of this.pendingStagingDestroy) p.staging.destroy();
        this.pendingStagingDestroy = [];
      });
  }

  private runSimulation(encoder: GPUCommandEncoder, g: GridResources, frameDt: number, sourcesOnly: boolean) {
    const s = this.sim;
    const dx = WORLD_SIZE / g.n;
    const dtMax = (0.35 * dx) / Math.sqrt(s.gravity * Math.max(s.maxDepth, 0.5));
    let substeps = clamp(Math.ceil(frameDt / dtMax), 1, Math.max(1, Math.round(s.maxSubsteps)));
    let dtSub = frameDt / substeps;
    if (dtSub > dtMax) dtSub = dtMax; // time dilation rather than instability
    if (sourcesOnly) substeps = 0;
    this.lastSubsteps = substeps;

    // Brush state for this frame
    let brushMode = 0;
    if (this.brush.active && this.tool !== 'none' && this.tool !== 'splash') brushMode = TOOL_IDS[this.tool];
    if (this.tool === 'splash' && this.brush.splashQueued) brushMode = TOOL_IDS.splash;
    this.brush.splashQueued = false;
    const bdx = clamp(this.brush.dx, -8, 8);
    const bdy = clamp(this.brush.dy, -8, 8);
    this.brush.dx = 0;
    this.brush.dy = 0;

    const f = this.simF;
    const u = this.simU;
    u[0] = g.n;
    f[1] = dx;
    f[2] = dtSub;
    f[3] = frameDt;
    f[4] = s.gravity;
    f[5] = s.viscosity;
    f[6] = s.drag;
    f[7] = s.yieldSlope;
    f[8] = s.minDepth;
    f[9] = sourcesOnly ? 0 : s.rainRate;
    f[10] = s.rainDrop;
    f[11] = sourcesOnly ? 0 : s.evaporation;
    f[12] = s.seaLevel;
    f[13] = s.waveAmp;
    f[14] = s.waveLen;
    f[15] = s.wavePeriod;
    u[16] = s.waveMaker && !sourcesOnly ? 1 : 0;
    f[17] = this.simTime;
    u[18] = this.frameIndex;
    u[19] = brushMode;
    f[20] = this.brush.gx;
    f[21] = this.brush.gy;
    f[22] = Math.max(1, this.brushRadius / dx);
    f[23] = this.brushStrength;
    f[24] = bdx;
    f[25] = bdy;
    f[26] = s.foamDecay;
    f[27] = s.foamGain;
    f[28] = sourcesOnly ? 0 : s.sourceRate;
    f[29] = s.sourceX;
    f[30] = s.sourceY;
    f[31] = s.sourceRadius;
    f[32] = sourcesOnly ? 0 : s.drain;
    f[33] = 25; // max speed
    this.device.queue.writeBuffer(this.simUniform, 0, this.simData);

    const wgs = Math.ceil(g.n / WG);
    const pass = encoder.beginComputePass();
    pass.setBindGroup(0, g.simBindGroup);
    pass.setPipeline(this.sourcePipeline);
    pass.dispatchWorkgroups(wgs, wgs);
    for (let i = 0; i < substeps; i++) {
      pass.setPipeline(this.fluxPipeline);
      pass.dispatchWorkgroups(wgs, wgs);
      pass.setPipeline(this.heightPipeline);
      pass.dispatchWorkgroups(wgs, wgs);
    }
    pass.end();
  }

  private writeRenderUniforms(width: number, height: number) {
    const r = this.render;
    const g = this.grid!;
    const aspect = width / height;
    const vp = this.camera.viewProj(aspect);
    const { forward, right, up } = this.camera.basis();
    const eye = this.camera.eye;
    const el = degToRad(r.sunElevation);
    const az = degToRad(r.sunAzimuth);
    const sun: Vec3 = [Math.cos(el) * Math.cos(az), Math.sin(el), Math.cos(el) * Math.sin(az)];
    const sunIntensity = 0.35 + 0.65 * clamp(Math.sin(el) * 2.5, 0, 1);
    const wind = degToRad(r.windDir);
    const f = this.renderF;
    f.set(vp, 0);
    f.set([eye[0], eye[1], eye[2], Math.tan(this.camera.fovY / 2)], 16);
    f.set([right[0], right[1], right[2], aspect], 20);
    f.set([up[0], up[1], up[2], 0], 24);
    f.set([forward[0], forward[1], forward[2], 0], 28);
    f.set([sun[0], sun[1], sun[2], sunIntensity], 32);
    f.set([g.n, WORLD_SIZE / g.n, this.simTime, this.sim.seaLevel], 36);
    f.set([r.swellAmp, Math.cos(wind), Math.sin(wind), r.windSpeed], 40);
    f.set([r.fluidType, r.foamAmount, DEBUG_IDS[r.debugView], FAR_FIELD_RADIUS], 44);
    f.set([r.absorb[0], r.absorb[1], r.absorb[2], r.refraction], 48);
    f.set([r.scatter[0], r.scatter[1], r.scatter[2], r.roughness], 52);
    f.set([width, height, 1 / width, 1 / height], 56);
    f.set([r.palette, r.skirtBase, r.rippleAmp, r.fadeDepth], 60);
    const deepSpeed = Math.sqrt(this.sim.gravity * Math.max(this.sim.maxDepth, 0.5));
    f.set([this.sim.waveMaker ? this.sim.waveAmp : 0, this.sim.wavePeriod, this.sim.waveLen, deepSpeed], 64);
    this.device.queue.writeBuffer(this.renderUniform, 0, f);
  }

  // ---------------------------------------------------------------------------
  // Picking
  // ---------------------------------------------------------------------------
  private surfaceHeightAt(x: number, z: number): number {
    const g = this.grid;
    if (!g || !g.cpuValid) return this.sim.seaLevel;
    const n = g.n;
    const u = clamp(((x + WORLD_SIZE / 2) / WORLD_SIZE) * n - 0.5, 0, n - 1);
    const v = clamp(((z + WORLD_SIZE / 2) / WORLD_SIZE) * n - 0.5, 0, n - 1);
    const x0 = Math.floor(u);
    const y0 = Math.floor(v);
    const x1 = Math.min(x0 + 1, n - 1);
    const y1 = Math.min(y0 + 1, n - 1);
    const fx = u - x0;
    const fy = v - y0;
    const h = (ix: number, iy: number) => g.cpuTerrain[iy * n + ix] + g.cpuWater[iy * n + ix];
    const a = h(x0, y0) * (1 - fx) + h(x1, y0) * fx;
    const b = h(x0, y1) * (1 - fx) + h(x1, y1) * fx;
    return a * (1 - fy) + b * fy;
  }

  /** Returns the grid-space hit point (in cells) of the surface under the pointer. */
  pick(clientX: number, clientY: number): { gx: number; gy: number } | null {
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return null;
    const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
    const ndcY = 1 - ((clientY - rect.top) / rect.height) * 2;
    const { origin, dir } = this.camera.ray(ndcX, ndcY, rect.width / rect.height);
    const half = WORLD_SIZE / 2;
    let tMin = 0;
    let tMax = 2000;
    for (const axis of [0, 2] as const) {
      if (Math.abs(dir[axis]) < 1e-6) {
        if (Math.abs(origin[axis]) > half) return null;
        continue;
      }
      let t1 = (-half - origin[axis]) / dir[axis];
      let t2 = (half - origin[axis]) / dir[axis];
      if (t1 > t2) [t1, t2] = [t2, t1];
      tMin = Math.max(tMin, t1);
      tMax = Math.min(tMax, t2);
    }
    if (tMax < tMin) return null;
    const at = (t: number): Vec3 => [origin[0] + dir[0] * t, origin[1] + dir[1] * t, origin[2] + dir[2] * t];
    const above = (p: Vec3) => p[1] > this.surfaceHeightAt(p[0], p[2]);
    let tPrev = tMin;
    if (!above(at(tMin))) {
      const p = at(tMin);
      return this.toGrid(p);
    }
    const step = 0.3;
    for (let t = tMin + step; t <= tMax + step; t += step) {
      const tt = Math.min(t, tMax);
      if (!above(at(tt))) {
        let lo = tPrev;
        let hi = tt;
        for (let k = 0; k < 8; k++) {
          const mid = (lo + hi) / 2;
          if (above(at(mid))) lo = mid;
          else hi = mid;
        }
        return this.toGrid(at((lo + hi) / 2));
      }
      tPrev = tt;
      if (tt >= tMax) break;
    }
    return null;
  }

  private toGrid(p: Vec3) {
    const n = this.grid?.n ?? this.gridSize;
    return {
      gx: clamp(((p[0] + WORLD_SIZE / 2) / WORLD_SIZE) * n, 0, n),
      gy: clamp(((p[2] + WORLD_SIZE / 2) / WORLD_SIZE) * n, 0, n),
    };
  }

  // ---------------------------------------------------------------------------
  // Input
  // ---------------------------------------------------------------------------
  private attachInput() {
    const c = this.canvas;
    const onDown = (e: PointerEvent) => {
      c.focus?.();
      this.lastPointer = { x: e.clientX, y: e.clientY };
      const wantsBrush = e.button === 0 && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey && this.tool !== 'none';
      if (wantsBrush) {
        this.dragMode = 'brush';
        this.brush.active = true;
        this.brush.hasPrev = false;
        this.updateBrush(e, true);
      } else if (e.button === 1 || e.ctrlKey || e.altKey || e.metaKey) {
        this.dragMode = 'pan';
      } else {
        this.dragMode = 'orbit';
      }
      try {
        c.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
      e.preventDefault();
    };
    const onMove = (e: PointerEvent) => {
      const dx = e.clientX - this.lastPointer.x;
      const dy = e.clientY - this.lastPointer.y;
      this.lastPointer = { x: e.clientX, y: e.clientY };
      if (this.dragMode === 'orbit') this.camera.orbit(dx, dy);
      else if (this.dragMode === 'pan') this.camera.pan(dx, dy);
      else if (this.dragMode === 'brush') this.updateBrush(e, false);
    };
    const onUp = (e: PointerEvent) => {
      this.dragMode = 'none';
      this.brush.active = false;
      try {
        c.releasePointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      this.camera.zoom(e.deltaY);
    };
    const onCtx = (e: Event) => e.preventDefault();
    c.addEventListener('pointerdown', onDown);
    c.addEventListener('pointermove', onMove);
    c.addEventListener('pointerup', onUp);
    c.addEventListener('pointercancel', onUp);
    c.addEventListener('wheel', onWheel, { passive: false });
    c.addEventListener('contextmenu', onCtx);
    this.cleanupFns.push(() => {
      c.removeEventListener('pointerdown', onDown);
      c.removeEventListener('pointermove', onMove);
      c.removeEventListener('pointerup', onUp);
      c.removeEventListener('pointercancel', onUp);
      c.removeEventListener('wheel', onWheel);
      c.removeEventListener('contextmenu', onCtx);
    });
  }

  private updateBrush(e: PointerEvent, isDown: boolean) {
    const hit = this.pick(e.clientX, e.clientY);
    if (!hit) {
      this.brush.hasPrev = false;
      return;
    }
    if (this.brush.hasPrev) {
      this.brush.dx += hit.gx - this.brush.gx;
      this.brush.dy += hit.gy - this.brush.gy;
    }
    this.brush.gx = hit.gx;
    this.brush.gy = hit.gy;
    this.brush.hasPrev = true;
    if (this.tool === 'splash') {
      const now = performance.now();
      if (isDown || now - this.brush.lastSplash > 140) {
        this.brush.splashQueued = true;
        this.brush.lastSplash = now;
      }
    }
  }
}
