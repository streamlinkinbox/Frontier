// Minimal column-major 4x4 matrix + vector helpers (WebGPU clip space, z in [0,1]).

export type Mat4 = Float32Array;
export type Vec3 = [number, number, number];

export function mat4Identity(): Mat4 {
  const m = new Float32Array(16);
  m[0] = m[5] = m[10] = m[15] = 1;
  return m;
}

export function mat4Multiply(a: Mat4, b: Mat4): Mat4 {
  const out = new Float32Array(16);
  for (let c = 0; c < 4; c++) {
    for (let r = 0; r < 4; r++) {
      let s = 0;
      for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k];
      out[c * 4 + r] = s;
    }
  }
  return out;
}

export function mat4Perspective(fovY: number, aspect: number, near: number, far: number): Mat4 {
  const f = 1 / Math.tan(fovY / 2);
  const m = new Float32Array(16);
  m[0] = f / aspect;
  m[5] = f;
  m[10] = far / (near - far);
  m[11] = -1;
  m[14] = (near * far) / (near - far);
  return m;
}

export function vec3Sub(a: Vec3, b: Vec3): Vec3 {
  return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}
export function vec3Add(a: Vec3, b: Vec3): Vec3 {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}
export function vec3Scale(a: Vec3, s: number): Vec3 {
  return [a[0] * s, a[1] * s, a[2] * s];
}
export function vec3Cross(a: Vec3, b: Vec3): Vec3 {
  return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
}
export function vec3Dot(a: Vec3, b: Vec3): number {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}
export function vec3Normalize(a: Vec3): Vec3 {
  const l = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
}

export function mat4LookAt(eye: Vec3, target: Vec3, up: Vec3): Mat4 {
  const f = vec3Normalize(vec3Sub(target, eye));
  const s = vec3Normalize(vec3Cross(f, up));
  const u = vec3Cross(s, f);
  const m = new Float32Array(16);
  m[0] = s[0];
  m[4] = s[1];
  m[8] = s[2];
  m[1] = u[0];
  m[5] = u[1];
  m[9] = u[2];
  m[2] = -f[0];
  m[6] = -f[1];
  m[10] = -f[2];
  m[12] = -vec3Dot(s, eye);
  m[13] = -vec3Dot(u, eye);
  m[14] = vec3Dot(f, eye);
  m[15] = 1;
  return m;
}

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const degToRad = (d: number) => (d * Math.PI) / 180;

/** Orbit camera around a target point. */
export class OrbitCamera {
  yaw = -2.3;
  pitch = 0.45;
  distance = 70;
  target: Vec3 = [0, 0, 0];
  fovY = degToRad(50);
  near = 0.3;
  far = 6000;

  get eye(): Vec3 {
    const cp = Math.cos(this.pitch);
    return [
      this.target[0] + Math.cos(this.yaw) * cp * this.distance,
      this.target[1] + Math.sin(this.pitch) * this.distance,
      this.target[2] + Math.sin(this.yaw) * cp * this.distance,
    ];
  }

  basis(): { forward: Vec3; right: Vec3; up: Vec3 } {
    const forward = vec3Normalize(vec3Sub(this.target, this.eye));
    const right = vec3Normalize(vec3Cross(forward, [0, 1, 0]));
    const up = vec3Cross(right, forward);
    return { forward, right, up };
  }

  viewProj(aspect: number): Mat4 {
    const view = mat4LookAt(this.eye, this.target, [0, 1, 0]);
    const proj = mat4Perspective(this.fovY, aspect, this.near, this.far);
    return mat4Multiply(proj, view);
  }

  /** World-space ray through normalized device coords (x right, y up, both in [-1, 1]). */
  ray(ndcX: number, ndcY: number, aspect: number): { origin: Vec3; dir: Vec3 } {
    const { forward, right, up } = this.basis();
    const t = Math.tan(this.fovY / 2);
    const dir = vec3Normalize(
      vec3Add(vec3Add(forward, vec3Scale(right, ndcX * t * aspect)), vec3Scale(up, ndcY * t)),
    );
    return { origin: this.eye, dir };
  }

  orbit(dx: number, dy: number) {
    this.yaw += dx * 0.005;
    this.pitch = clamp(this.pitch + dy * 0.005, 0.05, 1.45);
  }

  zoom(delta: number) {
    this.distance = clamp(this.distance * Math.exp(delta * 0.001), 6, 400);
  }

  pan(dx: number, dy: number) {
    const { right, forward } = this.basis();
    const flatF = vec3Normalize([forward[0], 0, forward[2]]);
    const s = this.distance * 0.0015;
    this.target = vec3Add(
      this.target,
      vec3Add(vec3Scale(right, -dx * s), vec3Scale(flatF, dy * s)),
    );
    this.target[0] = clamp(this.target[0], -80, 80);
    this.target[2] = clamp(this.target[2], -80, 80);
  }
}
