import { useCallback, useEffect, useRef, useState } from 'react';
import { ControlPanel } from '@/components/ControlPanel';
import { HintBar, LoadingScreen, PresetBar, StatsOverlay, UnsupportedScreen } from '@/components/Overlays';
import { DEFAULT_PRESET, PRESETS } from '@/gpu/presets';
import type { Preset, RenderParams, SimParams, TerrainParams, ToolMode } from '@/gpu/types';
import { useFluidEngine } from '@/hooks/useFluidEngine';
import { cn } from '@/utils/cn';

const TOOL_KEYS: ToolMode[] = ['splash', 'add', 'remove', 'push', 'raise', 'lower', 'none'];

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const { engineRef, status, stats } = useFluidEngine(canvasRef);

  const [presetId, setPresetId] = useState<string>(DEFAULT_PRESET.id);
  const [sim, setSim] = useState<SimParams>({ ...DEFAULT_PRESET.sim });
  const [render, setRender] = useState<RenderParams>({ ...DEFAULT_PRESET.render });
  const [terrain, setTerrain] = useState<TerrainParams>({ ...DEFAULT_PRESET.terrain });
  const [tool, setTool] = useState<ToolMode>('splash');
  const [brushRadius, setBrushRadius] = useState(2.5);
  const [brushStrength, setBrushStrength] = useState(1);
  const [paused, setPaused] = useState(false);
  const [resolution, setResolution] = useState(256);
  const [renderScale, setRenderScale] = useState(1);
  const [panelOpen, setPanelOpen] = useState(true);
  const [copied, setCopied] = useState(false);
  const [showInfo, setShowInfo] = useState(true);

  const activePreset = PRESETS.find((p) => p.id === presetId) ?? DEFAULT_PRESET;

  // Push the full UI state into the engine once it is ready.
  useEffect(() => {
    const e = engineRef.current;
    if (status.kind !== 'ready' || !e) return;
    e.setSimParams(sim);
    e.setRenderParams(render);
    e.tool = tool;
    e.brushRadius = brushRadius;
    e.brushStrength = brushStrength;
    e.paused = paused;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status.kind]);

  const onSim = useCallback(
    (p: Partial<SimParams>) => {
      setSim((s) => ({ ...s, ...p }));
      engineRef.current?.setSimParams(p);
    },
    [engineRef],
  );
  const onRender = useCallback(
    (p: Partial<RenderParams>) => {
      setRender((r) => ({ ...r, ...p }));
      engineRef.current?.setRenderParams(p);
    },
    [engineRef],
  );
  const onTerrain = useCallback(
    (p: Partial<TerrainParams>) => {
      setTerrain((t) => ({ ...t, ...p }));
      engineRef.current?.setTerrainParams(p);
    },
    [engineRef],
  );
  const onTool = useCallback(
    (t: ToolMode) => {
      setTool(t);
      if (engineRef.current) engineRef.current.tool = t;
    },
    [engineRef],
  );
  const onBrushRadius = useCallback(
    (v: number) => {
      setBrushRadius(v);
      if (engineRef.current) engineRef.current.brushRadius = v;
    },
    [engineRef],
  );
  const onBrushStrength = useCallback(
    (v: number) => {
      setBrushStrength(v);
      if (engineRef.current) engineRef.current.brushStrength = v;
    },
    [engineRef],
  );
  const onPaused = useCallback(
    (v: boolean) => {
      setPaused(v);
      if (engineRef.current) engineRef.current.paused = v;
    },
    [engineRef],
  );
  const onReset = useCallback(() => {
    engineRef.current?.reset();
  }, [engineRef]);
  const onResolution = useCallback(
    (n: number) => {
      setResolution(n);
      engineRef.current?.setResolution(n);
    },
    [engineRef],
  );
  const onRenderScale = useCallback(
    (s: number) => {
      setRenderScale(s);
      engineRef.current?.setRenderScale(s);
    },
    [engineRef],
  );
  const onSelectPreset = useCallback(
    (p: Preset) => {
      setPresetId(p.id);
      setSim({ ...p.sim });
      setRender({ ...p.render });
      setTerrain({ ...p.terrain });
      setShowInfo(true);
      engineRef.current?.applyPreset(p);
    },
    [engineRef],
  );
  const onCopyJson = useCallback(() => {
    const payload = {
      preset: presetId,
      worldSize: 64,
      gridSize: resolution,
      simulation: sim,
      rendering: render,
      terrain,
    };
    navigator.clipboard
      ?.writeText(JSON.stringify(payload, null, 2))
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      })
      .catch(() => undefined);
  }, [presetId, resolution, sim, render, terrain]);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return;
      if (e.code === 'Space') {
        e.preventDefault();
        onPaused(!paused);
      } else if (e.key === 'r' || e.key === 'R') {
        onReset();
      } else if (e.key === 'h' || e.key === 'H') {
        setPanelOpen((o) => !o);
      } else if (/^[1-7]$/.test(e.key)) {
        onTool(TOOL_KEYS[parseInt(e.key, 10) - 1]);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [paused, onPaused, onReset, onTool]);

  const ready = status.kind === 'ready';

  return (
    <div className="relative h-screen w-screen select-none overflow-hidden bg-[#07101c] text-slate-100">
      <canvas
        ref={canvasRef}
        className={cn('absolute inset-0 h-full w-full touch-none', tool === 'none' ? 'cursor-grab' : 'cursor-crosshair')}
      />

      {status.kind === 'loading' && <LoadingScreen />}
      {status.kind === 'unsupported' && <UnsupportedScreen reason={status.reason} />}
      {status.kind === 'error' && <UnsupportedScreen reason={status.message} isError />}

      {/* Header */}
      <div className={cn('absolute left-3 top-3 right-3 flex flex-col gap-2 transition-all', panelOpen ? 'md:right-[348px]' : '')}>
        <div className="flex items-start justify-between gap-3">
          <div className="pointer-events-none rounded-2xl bg-black/35 px-4 py-2.5 ring-1 ring-white/10 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 text-sm shadow-lg shadow-cyan-500/30">
                🌊
              </span>
              <div>
                <div className="text-sm font-semibold tracking-tight">FluidForge</div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-cyan-200/70">WebGPU shallow-water lab</div>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPanelOpen((o) => !o)}
            className="rounded-xl bg-black/40 px-3 py-2 text-[11px] text-slate-200 ring-1 ring-white/10 backdrop-blur-md hover:bg-black/55"
            title="Toggle control panel (H)"
          >
            {panelOpen ? 'Hide panel' : 'Show panel'}
          </button>
        </div>
        {ready && <PresetBar presets={PRESETS} activeId={presetId} onSelect={onSelectPreset} />}
        {ready && showInfo && (
          <div className="flex max-w-xl items-start gap-2 rounded-xl bg-black/35 px-3 py-2 text-[11px] leading-relaxed text-slate-300 ring-1 ring-white/10 backdrop-blur-md">
            <span className="mt-px">{activePreset.emoji}</span>
            <p className="flex-1">{activePreset.description}</p>
            <button type="button" onClick={() => setShowInfo(false)} className="text-slate-500 hover:text-slate-200" aria-label="Dismiss">
              ✕
            </button>
          </div>
        )}
      </div>

      {/* Bottom-left stats */}
      {ready && (
        <div className="absolute bottom-3 left-3">
          <StatsOverlay stats={stats} paused={paused} />
        </div>
      )}

      {/* Bottom-centre hints */}
      {ready && (
        <div className={cn('absolute bottom-3 left-1/2 hidden -translate-x-1/2 md:block', panelOpen ? 'md:-translate-x-[calc(50%+170px)]' : '')}>
          <HintBar tool={tool} />
        </div>
      )}

      {/* Control panel */}
      {ready && (
        <div
          className={cn(
            'absolute z-10 flex flex-col rounded-2xl bg-[#0b1528]/80 ring-1 ring-white/10 shadow-2xl shadow-black/40 backdrop-blur-xl transition-transform duration-300',
            'inset-x-2 bottom-2 h-[52vh] md:inset-x-auto md:bottom-3 md:right-3 md:top-3 md:h-auto md:w-[332px]',
            panelOpen ? 'translate-y-0 md:translate-x-0' : 'translate-y-[120%] md:translate-x-[120%] md:translate-y-0',
          )}
        >
          <ControlPanel
            sim={sim}
            onSim={onSim}
            render={render}
            onRender={onRender}
            terrain={terrain}
            onTerrain={onTerrain}
            tool={tool}
            onTool={onTool}
            brushRadius={brushRadius}
            onBrushRadius={onBrushRadius}
            brushStrength={brushStrength}
            onBrushStrength={onBrushStrength}
            paused={paused}
            onPaused={onPaused}
            onReset={onReset}
            resolution={resolution}
            onResolution={onResolution}
            renderScale={renderScale}
            onRenderScale={onRenderScale}
            onCopyJson={onCopyJson}
            copied={copied}
          />
        </div>
      )}
    </div>
  );
}
