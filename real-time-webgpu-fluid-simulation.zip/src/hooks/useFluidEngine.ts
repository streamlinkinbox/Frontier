import { useEffect, useRef, useState, type RefObject } from 'react';
import { FluidEngine, checkWebGPUSupport } from '@/gpu/FluidEngine';
import type { EngineStats } from '@/gpu/types';

export type EngineStatus =
  | { kind: 'loading' }
  | { kind: 'ready' }
  | { kind: 'unsupported'; reason: string }
  | { kind: 'error'; message: string };

export function useFluidEngine(canvasRef: RefObject<HTMLCanvasElement | null>) {
  const engineRef = useRef<FluidEngine | null>(null);
  const [status, setStatus] = useState<EngineStatus>({ kind: 'loading' });
  const [stats, setStats] = useState<EngineStats | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    let engine: FluidEngine | null = null;

    (async () => {
      const support = await checkWebGPUSupport();
      if (cancelled) return;
      if (!support.ok) {
        setStatus({ kind: 'unsupported', reason: support.reason ?? 'WebGPU unavailable' });
        return;
      }
      engine = new FluidEngine(canvas);
      engine.onStats = (s) => setStats(s);
      engine.onError = (m) => setStatus({ kind: 'error', message: m });
      try {
        await engine.init();
        if (cancelled) {
          engine.destroy();
          return;
        }
        engineRef.current = engine;
        setStatus({ kind: 'ready' });
      } catch (e) {
        console.error(e);
        setStatus({ kind: 'error', message: (e as Error).message });
      }
    })();

    return () => {
      cancelled = true;
      engine?.destroy();
      engineRef.current = null;
    };
  }, [canvasRef]);

  return { engineRef, status, stats };
}
