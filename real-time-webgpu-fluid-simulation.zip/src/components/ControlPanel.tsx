import { useState } from 'react';
import type { DebugView, RenderParams, SimParams, TerrainParams, ToolMode } from '@/gpu/types';
import { cn } from '@/utils/cn';
import { Button, Section, Segmented, Slider, Toggle } from './ui';

export interface ControlPanelProps {
  sim: SimParams;
  onSim: (p: Partial<SimParams>) => void;
  render: RenderParams;
  onRender: (p: Partial<RenderParams>) => void;
  terrain: TerrainParams;
  onTerrain: (p: Partial<TerrainParams>) => void;
  tool: ToolMode;
  onTool: (t: ToolMode) => void;
  brushRadius: number;
  onBrushRadius: (v: number) => void;
  brushStrength: number;
  onBrushStrength: (v: number) => void;
  paused: boolean;
  onPaused: (v: boolean) => void;
  onReset: () => void;
  resolution: number;
  onResolution: (n: number) => void;
  renderScale: number;
  onRenderScale: (s: number) => void;
  onCopyJson: () => void;
  copied: boolean;
}

const TOOLS: { id: ToolMode; label: string; icon: string; hint: string }[] = [
  { id: 'splash', label: 'Splash', icon: '💦', hint: 'Click / drag: impulse on the surface' },
  { id: 'add', label: 'Pour', icon: '🚰', hint: 'Drag: add fluid' },
  { id: 'remove', label: 'Drain', icon: '🕳️', hint: 'Drag: remove fluid' },
  { id: 'push', label: 'Push', icon: '🌀', hint: 'Drag: apply force along the stroke' },
  { id: 'raise', label: 'Raise', icon: '⛰️', hint: 'Drag: raise terrain' },
  { id: 'lower', label: 'Dig', icon: '⛏️', hint: 'Drag: lower terrain' },
  { id: 'none', label: 'Orbit', icon: '🎥', hint: 'Left drag orbits the camera' },
];

const WATER_LOOKS: { name: string; swatch: string; render: Partial<RenderParams>; sim: Partial<SimParams> }[] = [
  {
    name: 'Tropical',
    swatch: 'linear-gradient(135deg,#16a3a8,#4fd1c5)',
    render: { fluidType: 0, absorb: [0.42, 0.1, 0.06], scatter: [0.02, 0.22, 0.3], roughness: 0.08, foamAmount: 1.2, refraction: 1 },
    sim: { viscosity: 0, yieldSlope: 0, drag: 0.05 },
  },
  {
    name: 'Lake',
    swatch: 'linear-gradient(135deg,#1f4f5a,#3b7f7f)',
    render: { fluidType: 0, absorb: [0.35, 0.2, 0.12], scatter: [0.05, 0.14, 0.12], roughness: 0.08, foamAmount: 1, refraction: 1 },
    sim: { viscosity: 0, yieldSlope: 0, drag: 0.08 },
  },
  {
    name: 'Deep',
    swatch: 'linear-gradient(135deg,#0b2a5b,#1d4e9c)',
    render: { fluidType: 0, absorb: [0.5, 0.2, 0.08], scatter: [0.01, 0.08, 0.2], roughness: 0.1, foamAmount: 1.2, refraction: 1 },
    sim: { viscosity: 0, yieldSlope: 0, drag: 0.04 },
  },
  {
    name: 'Murky',
    swatch: 'linear-gradient(135deg,#5b4a2e,#8a7a4a)',
    render: { fluidType: 0, absorb: [0.9, 0.6, 0.45], scatter: [0.14, 0.12, 0.09], roughness: 0.06, foamAmount: 0.4, refraction: 0.8 },
    sim: { viscosity: 0.02, yieldSlope: 0, drag: 0.2 },
  },
  {
    name: 'Mud',
    swatch: 'linear-gradient(135deg,#4a3621,#7a5a3a)',
    render: { fluidType: 1, absorb: [4, 4, 4], scatter: [0.34, 0.25, 0.16], roughness: 0.6, foamAmount: 0, refraction: 0.3, rippleAmp: 0 },
    sim: { viscosity: 1.4, yieldSlope: 0.035, drag: 0.4, minDepth: 0.002 },
  },
  {
    name: 'Lava',
    swatch: 'linear-gradient(135deg,#c2410c,#fbbf24)',
    render: { fluidType: 1, absorb: [4, 4, 4], scatter: [1.6, 0.42, 0.08], roughness: 0.75, foamAmount: 0, refraction: 0.2, rippleAmp: 0 },
    sim: { viscosity: 2.5, yieldSlope: 0.06, drag: 0.6, minDepth: 0.004 },
  },
];

type Tab = 'tools' | 'sim' | 'look' | 'terrain';

export function ControlPanel(p: ControlPanelProps) {
  const [tab, setTab] = useState<Tab>('tools');
  const { sim, render, terrain } = p;

  return (
    <div className="flex h-full flex-col">
      <div className="px-3 pt-3">
        <Segmented<Tab>
          size="md"
          value={tab}
          onChange={setTab}
          options={[
            { value: 'tools', label: 'Tools' },
            { value: 'sim', label: 'Physics' },
            { value: 'look', label: 'Shading' },
            { value: 'terrain', label: 'Terrain' },
          ]}
        />
      </div>

      <div className="panel-scroll flex-1 overflow-y-auto px-3 pb-3">
        {tab === 'tools' && (
          <>
            <Section title="Interaction brush">
              <div className="grid grid-cols-4 gap-1.5">
                {TOOLS.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    title={t.hint}
                    onClick={() => p.onTool(t.id)}
                    className={cn(
                      'flex flex-col items-center gap-0.5 rounded-lg px-1 py-1.5 text-[10px] ring-1 transition-colors',
                      p.tool === t.id
                        ? 'bg-cyan-400/20 text-cyan-100 ring-cyan-300/40'
                        : 'bg-white/5 text-slate-300 ring-white/10 hover:bg-white/10',
                    )}
                  >
                    <span className="text-base leading-none">{t.icon}</span>
                    {t.label}
                  </button>
                ))}
              </div>
              <Slider label="Brush radius" value={p.brushRadius} min={0.4} max={10} step={0.1} onChange={p.onBrushRadius} format={(v) => `${v.toFixed(1)} m`} />
              <Slider label="Brush strength" value={p.brushStrength} min={0.1} max={4} step={0.05} onChange={p.onBrushStrength} format={(v) => `${v.toFixed(2)}×`} />
            </Section>

            <Section title="Fluid material">
              <div className="grid grid-cols-3 gap-1.5">
                {WATER_LOOKS.map((w) => (
                  <button
                    key={w.name}
                    type="button"
                    onClick={() => {
                      p.onRender(w.render);
                      p.onSim(w.sim);
                    }}
                    className="flex items-center gap-1.5 rounded-lg bg-white/5 px-2 py-1.5 text-[10px] text-slate-200 ring-1 ring-white/10 hover:bg-white/10"
                  >
                    <span className="h-3.5 w-3.5 shrink-0 rounded-full ring-1 ring-white/20" style={{ background: w.swatch }} />
                    {w.name}
                  </button>
                ))}
              </div>
            </Section>

            <Section title="Playback & quality">
              <div className="flex gap-1.5">
                <Button variant={p.paused ? 'primary' : 'ghost'} onClick={() => p.onPaused(!p.paused)} className="flex-1">
                  {p.paused ? '▶ Resume' : '⏸ Pause'}
                </Button>
                <Button variant="danger" onClick={p.onReset} className="flex-1" title="Regenerate terrain and fluid">
                  ↺ Reset scene
                </Button>
              </div>
              <div>
                <div className="mb-1 text-[11px] text-slate-300">Simulation grid</div>
                <Segmented<number>
                  value={p.resolution}
                  onChange={p.onResolution}
                  options={[
                    { value: 128, label: '128²' },
                    { value: 256, label: '256²' },
                    { value: 384, label: '384²' },
                    { value: 512, label: '512²' },
                  ]}
                />
              </div>
              <div>
                <div className="mb-1 text-[11px] text-slate-300">Render scale</div>
                <Segmented<number>
                  value={p.renderScale}
                  onChange={p.onRenderScale}
                  options={[
                    { value: 0.5, label: '50%' },
                    { value: 0.75, label: '75%' },
                    { value: 1, label: '100%' },
                  ]}
                />
              </div>
              <Slider label="Max sub-steps / frame" value={sim.maxSubsteps} min={1} max={10} step={1} onChange={(v) => p.onSim({ maxSubsteps: v })} format={(v) => `${v}`} hint="Upper bound on CFL sub-stepping. If the stable step is smaller, time dilates instead of exploding." />
              <Button onClick={p.onCopyJson} className="w-full">
                {p.copied ? '✓ Copied parameters' : '⧉ Copy parameters as JSON'}
              </Button>
            </Section>

            <Section title="Under the hood" defaultOpen={false} badge="WGSL compute">
              <ul className="space-y-1.5 text-[10.5px] leading-relaxed text-slate-400">
                <li>
                  <b className="text-slate-200">Solver:</b> 2.5D shallow-water heightfield (staggered flux / virtual-pipe scheme). Momentum
                  <code className="mx-1 rounded bg-white/10 px-1">dq/dt = g·h·∇η</code> gives depth-dependent wave speed √(g·h) → shoaling,
                  refraction and run-up on terrain.
                </li>
                <li>
                  <b className="text-slate-200">Wet / dry:</b> flux-limited mass update, wetting threshold, per-cell wetness &amp; foam advection
                  channels.
                </li>
                <li>
                  <b className="text-slate-200">Non-Newtonian:</b> implicit viscous damping ∝ 1/h² (lubrication) + Bingham yield slope for mud &amp;
                  lava.
                </li>
                <li>
                  <b className="text-slate-200">Stability:</b> automatic CFL sub-stepping (0.35·Δx/√(g·h<sub>max</sub>)).
                </li>
                <li>
                  <b className="text-slate-200">Shading:</b> HDR pipeline — Gerstner swell, analytic normals, screen-space refraction, Beer-Lambert
                  absorption, Fresnel sky reflection, crest SSS, foam masks, procedural caustics, ACES tonemap.
                </li>
                <li>
                  <b className="text-slate-200">Keys:</b> Space pause · R reset · 1–7 tools · H hide panel.
                </li>
              </ul>
            </Section>
          </>
        )}

        {tab === 'sim' && (
          <>
            <Section title="Shallow-water solver">
              <Slider label="Gravity" value={sim.gravity} min={0.5} max={25} step={0.1} onChange={(v) => p.onSim({ gravity: v })} format={(v) => `${v.toFixed(1)} m/s²`} />
              <Slider label="Viscosity" value={sim.viscosity} min={0} max={4} step={0.01} onChange={(v) => p.onSim({ viscosity: v })} hint="Thin-film viscous damping (∝ 1/depth²). 0 = water, 1–3 = mud / lava." />
              <Slider label="Bottom drag" value={sim.drag} min={0} max={1.5} step={0.01} onChange={(v) => p.onSim({ drag: v })} />
              <Slider label="Yield slope (Bingham)" value={sim.yieldSlope} min={0} max={0.2} step={0.001} onChange={(v) => p.onSim({ yieldSlope: v })} format={(v) => v.toFixed(3)} hint="Fluid only flows when the surface slope exceeds this value – mud piles up." />
              <Slider label="Wetting threshold" value={sim.minDepth} min={0.0001} max={0.01} step={0.0001} onChange={(v) => p.onSim({ minDepth: v })} format={(v) => `${(v * 1000).toFixed(1)} mm`} />
              <Slider label="Expected max depth" value={sim.maxDepth} min={0.5} max={20} step={0.5} onChange={(v) => p.onSim({ maxDepth: v })} format={(v) => `${v.toFixed(1)} m`} hint="Used for the CFL time-step estimate (wave speed √(g·h))." />
            </Section>

            <Section title="Rain & evaporation">
              <Slider label="Rain intensity" value={sim.rainRate} min={0} max={12} step={0.1} onChange={(v) => p.onSim({ rainRate: v })} format={(v) => `${v.toFixed(1)} /m²/s`} />
              <Slider label="Drop volume" value={sim.rainDrop} min={0.002} max={0.04} step={0.001} onChange={(v) => p.onSim({ rainDrop: v })} format={(v) => `${(v * 1000).toFixed(0)} mm`} />
              <Slider label="Evaporation" value={sim.evaporation} min={0} max={0.005} step={0.0001} onChange={(v) => p.onSim({ evaporation: v })} format={(v) => `${(v * 1000).toFixed(2)} mm/s`} />
            </Section>

            <Section title="Wave maker (x = 0 edge)">
              <Toggle label="Enabled" checked={sim.waveMaker} onChange={(v) => p.onSim({ waveMaker: v })} />
              <Slider label="Wave height" value={sim.waveAmp} min={0} max={2} step={0.01} onChange={(v) => p.onSim({ waveAmp: v })} format={(v) => `${v.toFixed(2)} m`} />
              <Slider label="Period" value={sim.wavePeriod} min={1.5} max={14} step={0.1} onChange={(v) => p.onSim({ wavePeriod: v })} format={(v) => `${v.toFixed(1)} s`} />
              <Slider label="Obliqueness length" value={sim.waveLen} min={6} max={80} step={1} onChange={(v) => p.onSim({ waveLen: v })} format={(v) => `${v.toFixed(0)} m`} />
              <Slider label="Sea level" value={sim.seaLevel} min={-3} max={3} step={0.05} onChange={(v) => p.onSim({ seaLevel: v })} format={(v) => `${v.toFixed(2)} m`} />
            </Section>

            <Section title="Inflow & drain">
              <Slider label="Source rate" value={sim.sourceRate} min={0} max={3} step={0.01} onChange={(v) => p.onSim({ sourceRate: v })} format={(v) => `${v.toFixed(2)} m/s`} />
              <Slider label="Source radius" value={sim.sourceRadius} min={0.4} max={6} step={0.1} onChange={(v) => p.onSim({ sourceRadius: v })} format={(v) => `${v.toFixed(1)} m`} />
              <Slider label="Source X" value={sim.sourceX} min={0.02} max={0.98} step={0.01} onChange={(v) => p.onSim({ sourceX: v })} />
              <Slider label="Source Y" value={sim.sourceY} min={0.02} max={0.98} step={0.01} onChange={(v) => p.onSim({ sourceY: v })} />
              <Slider label="Drain at far edge" value={sim.drain} min={0} max={0.6} step={0.01} onChange={(v) => p.onSim({ drain: v })} />
            </Section>

            <Section title="Foam dynamics">
              <Slider label="Foam generation" value={sim.foamGain} min={0} max={3} step={0.01} onChange={(v) => p.onSim({ foamGain: v })} />
              <Slider label="Foam decay" value={sim.foamDecay} min={0.05} max={4} step={0.01} onChange={(v) => p.onSim({ foamDecay: v })} format={(v) => `${v.toFixed(2)} /s`} />
            </Section>
          </>
        )}

        {tab === 'look' && (
          <>
            <Section title="Ocean swell (Gerstner)">
              <Slider label="Swell amplitude" value={render.swellAmp} min={0} max={1.2} step={0.01} onChange={(v) => p.onRender({ swellAmp: v })} format={(v) => `${v.toFixed(2)} m`} />
              <Slider label="Wind direction" value={render.windDir} min={0} max={360} step={1} onChange={(v) => p.onRender({ windDir: v })} format={(v) => `${v.toFixed(0)}°`} />
              <Slider label="Wind speed" value={render.windSpeed} min={0} max={14} step={0.1} onChange={(v) => p.onRender({ windSpeed: v })} format={(v) => `${v.toFixed(1)} m/s`} />
              <Slider label="Micro ripples" value={render.rippleAmp} min={0} max={1.5} step={0.01} onChange={(v) => p.onRender({ rippleAmp: v })} />
              <Toggle label="Endless ocean plane" checked={render.farField} onChange={(v) => p.onRender({ farField: v })} />
            </Section>

            <Section title="Surface shading">
              <Slider label="Roughness" value={render.roughness} min={0} max={1} step={0.01} onChange={(v) => p.onRender({ roughness: v })} />
              <Slider label="Refraction" value={render.refraction} min={0} max={2.5} step={0.01} onChange={(v) => p.onRender({ refraction: v })} />
              <Slider label="Foam amount" value={render.foamAmount} min={0} max={3} step={0.01} onChange={(v) => p.onRender({ foamAmount: v })} />
              <Slider label="Thin-film fade depth" value={render.fadeDepth} min={0.003} max={0.25} step={0.001} onChange={(v) => p.onRender({ fadeDepth: v })} format={(v) => `${(v * 100).toFixed(1)} cm`} />
              <ColorRow label="Absorption / m" value={render.absorb} max={2} onChange={(v) => p.onRender({ absorb: v })} />
              <ColorRow label="Scatter colour" value={render.scatter} max={1} onChange={(v) => p.onRender({ scatter: v })} />
              <div>
                <div className="mb-1 text-[11px] text-slate-300">Fluid type</div>
                <Segmented<number>
                  value={render.fluidType}
                  onChange={(v) => p.onRender({ fluidType: v as 0 | 1 })}
                  options={[
                    { value: 0, label: 'Water (transmissive)' },
                    { value: 1, label: 'Opaque (mud / lava)' },
                  ]}
                />
              </div>
            </Section>

            <Section title="Lighting & environment">
              <Slider label="Sun elevation" value={render.sunElevation} min={3} max={89} step={1} onChange={(v) => p.onRender({ sunElevation: v })} format={(v) => `${v.toFixed(0)}°`} />
              <Slider label="Sun azimuth" value={render.sunAzimuth} min={0} max={360} step={1} onChange={(v) => p.onRender({ sunAzimuth: v })} format={(v) => `${v.toFixed(0)}°`} />
              <div>
                <div className="mb-1 text-[11px] text-slate-300">Ground palette</div>
                <Segmented<number>
                  value={render.palette}
                  onChange={(v) => p.onRender({ palette: v as 0 | 1 })}
                  options={[
                    { value: 0, label: 'Sand · grass · rock' },
                    { value: 1, label: 'Dirt · mud' },
                  ]}
                />
              </div>
              <Slider label="Skirt base height" value={render.skirtBase} min={-20} max={0} step={0.5} onChange={(v) => p.onRender({ skirtBase: v })} format={(v) => `${v.toFixed(1)} m`} />
            </Section>

            <Section title="Debug view">
              <Segmented<DebugView>
                value={render.debugView}
                onChange={(v) => p.onRender({ debugView: v })}
                options={[
                  { value: 'none', label: 'Shaded' },
                  { value: 'depth', label: 'Depth' },
                  { value: 'velocity', label: 'Velocity' },
                  { value: 'foam', label: 'Foam' },
                ]}
              />
            </Section>
          </>
        )}

        {tab === 'terrain' && (
          <>
            <Section title="Procedural terrain">
              <Segmented<number>
                value={terrain.terrainType}
                onChange={(v) => p.onTerrain({ terrainType: v })}
                options={[
                  { value: 0, label: 'Basin' },
                  { value: 1, label: 'Beach' },
                  { value: 2, label: 'Bumpy' },
                  { value: 3, label: 'Channel' },
                  { value: 4, label: 'Islands' },
                ]}
              />
              <Slider label="Seed" value={terrain.seed} min={0} max={40} step={1} onChange={(v) => p.onTerrain({ seed: v })} format={(v) => `${v}`} />
              <Slider label="Relief amplitude" value={terrain.amplitude} min={0} max={8} step={0.05} onChange={(v) => p.onTerrain({ amplitude: v })} format={(v) => `${v.toFixed(2)} m`} />
              <Slider label="Noise frequency" value={terrain.frequency} min={1} max={16} step={0.5} onChange={(v) => p.onTerrain({ frequency: v })} />
              <Slider
                label={terrain.terrainType === 3 ? 'Hill slope (rise / m)' : 'Beach top height'}
                value={terrain.slope}
                min={0}
                max={terrain.terrainType === 3 ? 0.25 : 4}
                step={0.005}
                onChange={(v) => p.onTerrain({ slope: v })}
                format={(v) => v.toFixed(3)}
              />
              <Slider label="Base height" value={terrain.baseHeight} min={-4} max={4} step={0.05} onChange={(v) => p.onTerrain({ baseHeight: v })} format={(v) => `${v.toFixed(2)} m`} />
              <Slider label="Channel depth" value={terrain.channelDepth} min={0} max={4} step={0.05} onChange={(v) => p.onTerrain({ channelDepth: v })} format={(v) => `${v.toFixed(2)} m`} />
              <Slider label="Channel width" value={terrain.channelWidth} min={0.02} max={0.35} step={0.005} onChange={(v) => p.onTerrain({ channelWidth: v })} />
            </Section>
            <Section title="Initial fluid">
              <Segmented<number>
                value={terrain.fillType}
                onChange={(v) => p.onTerrain({ fillType: v })}
                options={[
                  { value: 0, label: 'Empty' },
                  { value: 1, label: 'Fill to level' },
                  { value: 2, label: 'Blob at top' },
                ]}
              />
              <Slider label={terrain.fillType === 2 ? 'Blob depth' : 'Fill level'} value={terrain.fillLevel} min={-4} max={4} step={0.05} onChange={(v) => p.onTerrain({ fillLevel: v })} format={(v) => `${v.toFixed(2)} m`} />
              <Slider label="Blob extent" value={terrain.fillExtent} min={0.05} max={0.7} step={0.01} onChange={(v) => p.onTerrain({ fillExtent: v })} />
              <p className="text-[10px] leading-relaxed text-slate-500">
                Terrain changes regenerate the scene instantly. Use the Raise / Dig brushes to sculpt by hand.
              </p>
            </Section>
          </>
        )}
      </div>
    </div>
  );
}

function ColorRow({
  label,
  value,
  max,
  onChange,
}: {
  label: string;
  value: [number, number, number];
  max: number;
  onChange: (v: [number, number, number]) => void;
}) {
  const names = ['R', 'G', 'B'];
  const colors = ['bg-rose-400', 'bg-emerald-400', 'bg-sky-400'];
  return (
    <div>
      <div className="mb-1 text-[11px] text-slate-300">{label}</div>
      <div className="grid grid-cols-3 gap-2">
        {value.map((v, i) => (
          <label key={names[i]} className="flex items-center gap-1.5">
            <span className={cn('h-2 w-2 rounded-full', colors[i])} />
            <input
              type="range"
              min={0}
              max={max}
              step={0.005}
              value={Math.min(v, max)}
              onChange={(e) => {
                const next: [number, number, number] = [value[0], value[1], value[2]];
                next[i] = parseFloat(e.target.value);
                onChange(next);
              }}
              className="fluid-slider"
              style={{ ['--pct' as string]: `${(Math.min(v, max) / max) * 100}%` }}
            />
          </label>
        ))}
      </div>
    </div>
  );
}
