import { useState, type ReactNode } from 'react';
import { cn } from '@/utils/cn';

export function Slider({
  label,
  value,
  min,
  max,
  step = 0.01,
  onChange,
  format,
  hint,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
  hint?: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <label className="group block" title={hint}>
      <div className="mb-1 flex items-center justify-between text-[11px]">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono tabular-nums text-cyan-200/90">{format ? format(value) : value.toFixed(step < 0.01 ? 3 : step < 0.1 ? 2 : 1)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="fluid-slider"
        style={{ ['--pct' as string]: `${pct}%` }}
      />
    </label>
  );
}

export function Toggle({
  label,
  checked,
  onChange,
  hint,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  hint?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      title={hint}
      className="flex w-full items-center justify-between py-0.5 text-[11px] text-slate-300"
    >
      <span>{label}</span>
      <span
        className={cn(
          'relative h-4 w-7 rounded-full transition-colors',
          checked ? 'bg-cyan-400/90' : 'bg-white/15',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-3 w-3 rounded-full bg-white shadow transition-transform',
            checked ? 'translate-x-3.5' : 'translate-x-0.5',
          )}
        />
      </span>
    </button>
  );
}

export function Section({
  title,
  children,
  defaultOpen = true,
  badge,
}: {
  title: string;
  children: ReactNode;
  defaultOpen?: boolean;
  badge?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-white/5 last:border-b-0">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between py-2 text-left"
      >
        <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400">{title}</span>
        <span className="flex items-center gap-2">
          {badge && <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] text-slate-300">{badge}</span>}
          <svg
            className={cn('h-3 w-3 text-slate-500 transition-transform', open ? 'rotate-180' : '')}
            viewBox="0 0 12 12"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.5}
          >
            <path d="M2 4l4 4 4-4" />
          </svg>
        </span>
      </button>
      {open && <div className="space-y-2.5 pb-3">{children}</div>}
    </div>
  );
}

export function Segmented<T extends string | number>({
  options,
  value,
  onChange,
  size = 'sm',
}: {
  options: { value: T; label: ReactNode; title?: string }[];
  value: T;
  onChange: (v: T) => void;
  size?: 'sm' | 'md';
}) {
  return (
    <div className="flex rounded-lg bg-black/30 p-0.5 ring-1 ring-white/10">
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          title={o.title}
          onClick={() => onChange(o.value)}
          className={cn(
            'flex-1 rounded-md text-center transition-colors',
            size === 'sm' ? 'px-1.5 py-1 text-[10px]' : 'px-2 py-1.5 text-[11px]',
            value === o.value ? 'bg-cyan-400/20 text-cyan-100 shadow-inner ring-1 ring-cyan-300/30' : 'text-slate-400 hover:text-slate-200',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Button({
  children,
  onClick,
  variant = 'ghost',
  className,
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'ghost' | 'primary' | 'danger';
  className?: string;
  title?: string;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className={cn(
        'rounded-lg px-2.5 py-1.5 text-[11px] font-medium transition-colors ring-1',
        variant === 'ghost' && 'bg-white/5 text-slate-200 ring-white/10 hover:bg-white/10',
        variant === 'primary' && 'bg-cyan-400/20 text-cyan-100 ring-cyan-300/30 hover:bg-cyan-400/30',
        variant === 'danger' && 'bg-rose-500/15 text-rose-200 ring-rose-400/20 hover:bg-rose-500/25',
        className,
      )}
    >
      {children}
    </button>
  );
}
