import type { EngineStats, Preset } from '@/gpu/types';
import { cn } from '@/utils/cn';

export function PresetBar({
  presets,
  activeId,
  onSelect,
}: {
  presets: Preset[];
  activeId: string;
  onSelect: (p: Preset) => void;
}) {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none]">
      {presets.map((p) => (
        <button
          key={p.id}
          type="button"
          onClick={() => onSelect(p)}
          title={p.description}
          className={cn(
            'flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-medium ring-1 backdrop-blur-md transition-all',
            activeId === p.id
              ? 'bg-cyan-400/25 text-cyan-50 ring-cyan-300/40 shadow-[0_0_20px_-4px_rgba(34,211,238,0.6)]'
              : 'bg-black/35 text-slate-200 ring-white/10 hover:bg-black/50',
          )}
        >
          <span>{p.emoji}</span>
          {p.name}
        </button>
      ))}
    </div>
  );
}

export function StatsOverlay({ stats, paused }: { stats: EngineStats | null; paused: boolean }) {
  return (
    <div className="pointer-events-none rounded-xl bg-black/40 px-3 py-2 font-mono text-[10px] leading-relaxed text-slate-300 ring-1 ring-white/10 backdrop-blur-md">
      <div className="flex items-center gap-2">
        <span className={cn('h-1.5 w-1.5 rounded-full', paused ? 'bg-amber-400' : 'bg-emerald-400 animate-pulse')} />
        <span className="text-slate-100">{stats ? `${stats.fps.toFixed(0)} fps` : '— fps'}</span>
        <span className="text-slate-500">{stats ? `${stats.frameMs.toFixed(1)} ms` : ''}</span>
      </div>
      {stats && (
        <>
          <div>
            grid {stats.gridSize}² · {(stats.cells / 1000).toFixed(0)}k cells · {stats.substeps} substep{stats.substeps === 1 ? '' : 's'}
          </div>
          <div className="max-w-[260px] truncate text-slate-500" title={stats.adapter}>
            {stats.adapter}
          </div>
        </>
      )}
    </div>
  );
}

export function HintBar({ tool }: { tool: string }) {
  return (
    <div className="pointer-events-none flex flex-wrap items-center justify-center gap-x-4 gap-y-1 rounded-full bg-black/40 px-4 py-1.5 text-[10px] text-slate-300 ring-1 ring-white/10 backdrop-blur-md">
      <span>
        <Key>LMB</Key> {tool === 'none' ? 'orbit' : 'use brush'}
      </span>
      <span>
        <Key>RMB</Key> / <Key>Shift</Key>+drag orbit
      </span>
      <span>
        <Key>Ctrl</Key>+drag pan
      </span>
      <span>
        <Key>Wheel</Key> zoom
      </span>
    </div>
  );
}

function Key({ children }: { children: React.ReactNode }) {
  return <kbd className="rounded bg-white/10 px-1 py-px font-mono text-[9px] text-slate-100 ring-1 ring-white/15">{children}</kbd>;
}

export function LoadingScreen() {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#07101c]">
      <div className="flex flex-col items-center gap-4">
        <div className="relative h-14 w-14">
          <div className="absolute inset-0 animate-ping rounded-full bg-cyan-400/20" />
          <div className="absolute inset-2 animate-spin rounded-full border-2 border-cyan-300/70 border-t-transparent" />
        </div>
        <div className="text-sm text-slate-300">Compiling WebGPU pipelines…</div>
      </div>
    </div>
  );
}

export function UnsupportedScreen({ reason, isError }: { reason: string; isError?: boolean }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(ellipse_at_top,#0f2a3f,#07101c_60%)] p-6">
      <div className="max-w-lg rounded-2xl bg-black/40 p-6 ring-1 ring-white/10 backdrop-blur-xl">
        <div className="mb-3 text-3xl">{isError ? '⚠️' : '🧪'}</div>
        <h2 className="text-lg font-semibold text-slate-50">
          {isError ? 'The WebGPU engine hit an error' : 'WebGPU is required'}
        </h2>
        <p className="mt-2 text-sm leading-relaxed text-slate-300">
          {isError
            ? 'Something went wrong while creating the GPU pipelines. Details:'
            : 'This fluid lab runs its shallow-water solver and renderer entirely on the GPU via WebGPU compute shaders, which this browser does not expose.'}
        </p>
        <pre className="mt-3 max-h-40 overflow-auto rounded-lg bg-black/50 p-3 text-[11px] leading-relaxed text-rose-200 whitespace-pre-wrap">{reason}</pre>
        {!isError && (
          <ul className="mt-4 space-y-1.5 text-sm text-slate-300">
            <li>• <b className="text-slate-100">Chrome / Edge 113+</b> on Windows, macOS, ChromeOS and Android — enabled by default.</li>
            <li>• <b className="text-slate-100">Safari 26+</b> (macOS / iOS) — enabled by default; older builds: Develop → Feature Flags → WebGPU.</li>
            <li>• <b className="text-slate-100">Firefox 141+</b> on Windows (other platforms: set <code className="rounded bg-white/10 px-1">dom.webgpu.enabled</code>).</li>
            <li>• On Linux Chrome, launch with <code className="rounded bg-white/10 px-1">--enable-unsafe-webgpu --enable-features=Vulkan</code>.</li>
          </ul>
        )}
      </div>
    </div>
  );
}
