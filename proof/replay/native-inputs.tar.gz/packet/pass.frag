#version 300 es
precision highp float;
precision highp int;

in vec2 vUv;
uniform sampler2D uGPosRough;
uniform sampler2D uGNormMat;
uniform int uLightCount;
uniform int uLightType[3];
uniform vec3 uLightOrigin[3];
uniform vec3 uLightDir[3];
uniform float uLightRadius[3];
uniform int uBvhRays;


struct SurfaceMat {
  vec3 albedo;
  float roughness;
  vec3 emissive;
  float metalness;
  float coat;
  float coatRough;
};

SurfaceMat evalMaterial(int matId, vec3 worldPos, vec3 paintColor) {
  SurfaceMat m;
  m.albedo = vec3(0.22, 0.23, 0.26);
  m.roughness = 0.42;
  m.emissive = vec3(0.0);
  m.metalness = 0.16;
  m.coat = 0.0;
  m.coatRough = 0.04;

  if (matId == 1) {
    float gx = abs(fract(worldPos.x * 0.25 + 0.5) - 0.5);
    float gy = abs(fract(worldPos.y * 0.25 + 0.5) - 0.5);
    float grid = 1.0 - smoothstep(0.005, 0.013, min(gx, gy));
    float lane = (1.0 - smoothstep(0.038, 0.058, abs(abs(worldPos.y) - 4.15))) * step(abs(worldPos.x), 11.5);
    vec3 basePad = mix(vec3(0.32, 0.33, 0.36), vec3(0.22, 0.23, 0.26), grid * 0.26);
    m.albedo = mix(basePad, vec3(0.78, 0.60, 0.16), lane * 0.62);
    m.roughness = mix(0.25, 0.36, lane);
    m.metalness = 0.02;
    m.coat = 0.38;
    m.coatRough = 0.11;
  } else if (matId == 2) {
    m.albedo = vec3(0.90, 0.93, 0.97);
    m.roughness = 0.035;
    m.metalness = 0.98;
    m.coat = 0.50;
    m.coatRough = 0.03;
  } else if (matId == 3) {
    m.albedo = vec3(0.94, 0.74, 0.44);
    m.roughness = 0.045;
    m.metalness = 0.96;
    m.coat = 0.40;
    m.coatRough = 0.04;
  } else if (matId == 4) {
    m.albedo = vec3(0.15, 0.16, 0.19);
    m.roughness = 0.28;
    m.metalness = 0.55;
  } else if (matId == 5) {
    m.albedo = vec3(0.95, 0.98, 1.00);
    m.roughness = 0.15;
    m.emissive = vec3(4.5, 5.2, 6.4);
    m.metalness = 0.0;
  } else if (matId == 6) {
    float luma = dot(paintColor, vec3(0.299, 0.587, 0.114));
    m.albedo = paintColor;
    m.roughness = 0.14;
    m.metalness = (luma > 0.78) ? 0.28 : 0.74;
    m.coat = 1.0;
    m.coatRough = 0.032;
  } else if (matId == 7) {
    m.albedo = vec3(0.03, 0.045, 0.065);
    m.roughness = 0.025;
    m.metalness = 0.10;
    m.coat = 1.0;
    m.coatRough = 0.02;
  } else if (matId == 8 || matId == 15) {
    m.albedo = vec3(0.10, 0.105, 0.12);
    m.roughness = 0.26;
    m.metalness = 0.35;
    m.coat = 0.35;
    m.coatRough = 0.12;
  } else if (matId == 10) {
    m.albedo = vec3(0.86, 0.89, 0.94);
    m.roughness = 0.08;
    m.metalness = 0.95;
    m.coat = 0.60;
    m.coatRough = 0.05;
  } else if (matId == 11) {
    m.albedo = vec3(0.065, 0.068, 0.075);
    m.roughness = 0.62;
    m.metalness = 0.02;
  } else if (matId == 12 || matId == 13) {
    m.albedo = vec3(0.92, 0.96, 1.00);
    m.roughness = 0.05;
    m.emissive = (matId == 13) ? vec3(7.0, 7.6, 8.8) : vec3(2.2, 2.6, 3.2);
    m.metalness = 0.0;
    m.coat = 1.0;
    m.coatRough = 0.03;
  } else if (matId == 14) {
    m.albedo = vec3(0.68, 0.03, 0.04);
    m.roughness = 0.06;
    m.emissive = vec3(6.5, 0.40, 0.30);
    m.metalness = 0.0;
    m.coat = 1.0;
    m.coatRough = 0.03;
  } else if (matId == 17) {
    m.albedo = vec3(0.92, 0.28, 0.05);
    m.roughness = 0.18;
    m.metalness = 0.10;
    m.coat = 0.65;
    m.coatRough = 0.08;
  } else if (matId == 18) {
    m.albedo = vec3(0.94, 0.06, 0.08);
    m.roughness = 0.85;
    m.metalness = 0.0;
  } else if (matId == 19) {
    m.albedo = vec3(0.05, 0.68, 0.95);
    m.roughness = 0.85;
    m.metalness = 0.0;
  } else if (matId == 20) {
    m.albedo = vec3(0.88, 0.89, 0.91);
    m.roughness = 0.85;
    m.metalness = 0.0;
  } else if (matId == 21) {
    m.albedo = vec3(0.22, 0.24, 0.30);
    m.roughness = 0.24;
    m.metalness = 0.72;
    m.coat = 0.28;
    m.coatRough = 0.09;
  } else if (matId == 22) {
    m.albedo = vec3(0.75, 0.96, 1.00);
    m.roughness = 0.10;
    m.emissive = vec3(5.2, 8.8, 12.4);
    m.metalness = 0.0;
    m.coat = 0.50;
    m.coatRough = 0.04;
  }
  return m;
}

vec3 evalPortalIrradiance(vec3 pos, vec3 nrm) {
  vec3 portalIrr = vec3(0.0);
  if (pos.z < 6.20) {
    for (int i = -1; i <= 1; i++) {
      vec3 lp = vec3(float(i) * 12.0, clamp(pos.y, -13.0, 13.0), 6.20);
      vec3 d = lp - pos;
      float d2 = dot(d, d);
      vec3 ldir = d * inversesqrt(max(d2, 1e-4));
      portalIrr += vec3(0.75, 0.84, 1.02) * (max(dot(nrm, ldir), 0.0) / (1.0 + 0.12 * d2));
    }
  }
  return portalIrr;
}

vec3 evalSkyAndClouds(vec3 dir, vec3 sunDir, int lightType, vec3 lightColor) {
  float up = clamp(dir.z, -0.25, 1.0);
  vec3 horizon = (lightType == 0) ? vec3(0.50, 0.64, 0.84) : vec3(0.16, 0.18, 0.24);
  vec3 zenith  = (lightType == 0) ? vec3(0.11, 0.24, 0.50) : vec3(0.05, 0.07, 0.11);
  vec3 ground  = vec3(0.07, 0.075, 0.09);
  vec3 sky = (up >= 0.0)
    ? mix(horizon, zenith, pow(max(up, 1e-4), 0.58))
    : mix(horizon * 0.45, ground, clamp(-up * 6.0, 0.0, 1.0));

  if (lightType == 0) {
    float sunCos = max(dot(dir, sunDir), 1e-4);
    sky += lightColor * pow(sunCos, 18.0) * 0.50;
    sky += lightColor * smoothstep(0.99935, 0.99985, sunCos) * 10.0;
    if (dir.z > 0.04) {
      vec2 cuv = dir.xy / (dir.z + 0.18) * 0.55;
      float n = sin(cuv.x * 2.3 + 0.7) * cos(cuv.y * 2.1 - 0.4)
              + 0.5 * sin(cuv.x * 5.1 - cuv.y * 3.7)
              + 0.25 * cos(cuv.x * 9.3 + cuv.y * 8.1);
      float cloud = smoothstep(0.35, 1.18, n) * smoothstep(0.04, 0.24, dir.z);
      vec3 cloudLit = mix(vec3(0.56, 0.64, 0.75), vec3(1.16, 1.10, 1.02), 0.5 + 0.5 * sunCos);
      sky = mix(sky, cloudLit, cloud * 0.48);
    }
  }
  return sky;
}

void buildOrthonormalBasis(vec3 n, out vec3 t, out vec3 b) {
  vec3 up = (abs(n.z) < 0.92) ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
  t = normalize(cross(up, n));
  b = cross(n, t);
}

vec2 r2Sequence(vec2 px) {
  return fract(px.x * vec2(0.7548776662, 0.5698402910) + px.y * vec2(0.5698402910, 0.3247179572));
}

// Clipped-Polygon Linearly Transformed Cosine (LTC) Emissive Area Panel Evaluator (matching Frontier LinearCosineLightIntegration.cpp)
float integrateSphericalEdgeZ(vec3 v1, vec3 v2) {
  float x = clamp(dot(v1, v2), -0.99999, 0.99999);
  float absX = abs(x);
  float a = 5.42031 + (3.12829 + 0.0902326 * absX) * absX;
  float b = 3.45068 + (4.18814 + absX) * absX;
  float thetaOverSin = a / b;
  if (x < 0.0) {
    float sinTheta = sqrt(max(1e-8, 1.0 - x * x));
    thetaOverSin = 3.14159265 / sinTheta - thetaOverSin;
  }
  return (v1.x * v2.y - v1.y * v2.x) * thetaOverSin;
}

float integrateClippedQuadFormFactor(vec3 localQ[4]) {
  vec3 clipped[8];
  int clipCount = 0;
  for (int i = 0; i < 4; i++) {
    vec3 cur = localQ[i];
    vec3 next = localQ[(i + 1) & 3];
    bool curA = (cur.z >= 0.0);
    bool nxtA = (next.z >= 0.0);
    if (curA) clipped[clipCount++] = cur;
    if (curA != nxtA) {
      float alpha = cur.z / (cur.z - next.z);
      vec3 hit = cur + (next - cur) * alpha;
      hit.z = 0.0;
      clipped[clipCount++] = hit;
    }
  }
  if (clipCount < 3) return 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= clipCount) break;
    clipped[i] = normalize(clipped[i]);
  }
  float contourSum = 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= clipCount) break;
    int nxt = (i + 1 >= clipCount) ? 0 : (i + 1);
    contourSum += integrateSphericalEdgeZ(clipped[i], clipped[nxt]);
  }
  return clamp(abs(contourSum) / 6.2831853, 0.0, 1.0);
}

vec3 evalEmissivePanelLtc(
  vec3 pos, vec3 nrm, vec3 viewDir, SurfaceMat m,
  vec3 eCenter, vec3 eRight, vec3 eUp, vec3 eNormal,
  float eHalfW, float eHalfH, float eIntensity, float vis
) {
  if (vis <= 1e-4 || eIntensity <= 1e-4) return vec3(0.0);
  if (dot(pos - eCenter, eNormal) <= 0.02) return vec3(0.0);

  float noV = clamp(dot(nrm, viewDir), 1e-4, 1.0);
  vec3 t1 = viewDir - nrm * noV;
  float t1Len = dot(t1, t1);
  if (t1Len <= 1e-6) {
    vec3 fb;
    buildOrthonormalBasis(nrm, t1, fb);
  } else {
    t1 *= inversesqrt(t1Len);
  }
  vec3 t2 = normalize(cross(nrm, t1));

  vec3 halfU = eRight * eHalfW;
  vec3 halfV = eUp * eHalfH;
  vec3 wc[4];
  wc[0] = eCenter - halfU - halfV;
  wc[1] = eCenter + halfU - halfV;
  wc[2] = eCenter + halfU + halfV;
  wc[3] = eCenter - halfU + halfV;

  vec3 diffLocal[4];
  for (int i = 0; i < 4; i++) {
    vec3 rel = wc[i] - pos;
    diffLocal[i] = vec3(dot(rel, t1), dot(rel, t2), dot(rel, nrm));
  }
  float diffFF = integrateClippedQuadFormFactor(diffLocal);

  float r = max(m.coat > 0.0 ? mix(m.roughness, m.coatRough, m.coat * 0.65) : m.roughness, 0.035);
  float alpha = clamp(r * r, 0.004, 1.0);
  float sinV = sqrt(max(0.0, 1.0 - noV * noV));
  float invScaleX = 1.0 / max(0.04, alpha * (0.85 + 0.15 * noV));
  float invScaleY = 1.0 / max(0.04, alpha);
  float shearXZ = -sinV / max(0.08, noV + alpha);

  vec3 specLocal[4];
  for (int i = 0; i < 4; i++) {
    vec3 d = diffLocal[i];
    float mx = -d.x * noV + d.z * sinV;
    float mz =  d.x * sinV + d.z * noV;
    specLocal[i] = vec3((mx + shearXZ * mz * alpha) * invScaleX, d.y * invScaleY, mz);
  }
  float specFF = integrateClippedQuadFormFactor(specLocal);

  vec3 diffAlb = m.albedo * (1.0 - m.metalness);
  vec3 f0 = mix(vec3(0.04), m.albedo, m.metalness);
  float schlick = pow(max(1.0 - noV, 1e-4), 5.0);
  vec3 specAlb = f0 + (vec3(1.0) - f0) * (schlick * clamp(1.0 - r * 0.65, 0.0, 1.0));
  vec3 rad = vec3(11.0, 26.0, 42.0) * eIntensity;
  return rad * (diffAlb * diffFF + specAlb * specFF) * vis;
}


uniform sampler2D uBvhNodes;
uniform sampler2D uBvhTris;
uniform sampler2D uInstances;
uniform int uMaxBvhInstances;

const int BVH_TEX_MASK  = 2047;
const int BVH_TEX_SHIFT = 11;

vec4 fetchNodeTexel(int texelIdx) {
  return texelFetch(uBvhNodes, ivec2(texelIdx & BVH_TEX_MASK, texelIdx >> BVH_TEX_SHIFT), 0);
}
vec4 fetchTriTexel(int texelIdx) {
  return texelFetch(uBvhTris, ivec2(texelIdx & BVH_TEX_MASK, texelIdx >> BVH_TEX_SHIFT), 0);
}
mat4 fetchInstanceMat(int instIdx, int matOffset) {
  int base = instIdx * 9 + matOffset;
  return mat4(
    texelFetch(uInstances, ivec2(base + 0, 0), 0),
    texelFetch(uInstances, ivec2(base + 1, 0), 0),
    texelFetch(uInstances, ivec2(base + 2, 0), 0),
    texelFetch(uInstances, ivec2(base + 3, 0), 0)
  );
}
int fetchInstanceMatOverride(int instIdx) {
  return int(texelFetch(uInstances, ivec2(instIdx * 9 + 8, 0), 0).x + 0.5) - 1;
}
vec3 unpackOctahedral(int packed20) {
  float u = float(packed20 & 1023) / 1023.0 * 2.0 - 1.0;
  float v = float((packed20 >> 10) & 1023) / 1023.0 * 2.0 - 1.0;
  vec3 n = vec3(u, v, 1.0 - abs(u) - abs(v));
  if (n.z < 0.0) {
    vec2 s = vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    n.xy = (1.0 - abs(n.yx)) * s;
  }
  return normalize(n);
}
vec3 safeRecip(vec3 d) {
  return vec3(
    abs(d.x) < 1e-8 ? 1e8 : 1.0 / d.x,
    abs(d.y) < 1e-8 ? 1e8 : 1.0 / d.y,
    abs(d.z) < 1e-8 ? 1e8 : 1.0 / d.z
  );
}
float intersectAabb(vec3 orig, vec3 rcp, vec3 bmin, vec3 bmax, float limit) {
  vec3 t0 = (bmin - orig) * rcp;
  vec3 t1 = (bmax - orig) * rcp;
  vec3 lo = min(t0, t1);
  vec3 hi = max(t0, t1);
  float tNear = max(max(lo.x, lo.y), max(lo.z, 0.0));
  float tFar  = min(min(hi.x, hi.y), min(hi.z, limit));
  return (tNear <= tFar) ? tNear : 1e30;
}

struct BvhHit { bool hit; float t; vec3 pos; vec3 nrm; int matId; };

BvhHit traceSceneBvh(vec3 origin, vec3 dir, float tMin, float tMax) {
  BvhHit res;
  res.hit = false; res.t = tMax; res.pos = origin + dir * tMax; res.nrm = -dir; res.matId = 0;

  vec3 worldRcp = safeRecip(dir);
  int stack[48]; int depth = 1; stack[0] = 0;
  int blasFloor = 999999;
  float nearest = tMax; int bestTri = -1; int bestInst = -1; vec2 bestUv = vec2(0.0);
  int currInst = -1; vec3 localOrig = origin; vec3 localDir = dir; vec3 localRcp = worldRcp;

  for (int stepIdx = 0; stepIdx < 280; stepIdx++) {
    if (depth <= 0) break;
    if (depth <= blasFloor) blasFloor = 999999;
    depth--;
    int nodeIdx = stack[depth];
    vec4 n0 = fetchNodeTexel(nodeIdx * 2);
    vec4 n1 = fetchNodeTexel(nodeIdx * 2 + 1);
    int leftOrFirst = int(n0.w + 0.5);
    int count = int(round(n1.w));

    if (blasFloor == 999999) {
      if (intersectAabb(origin, worldRcp, n0.xyz, n1.xyz, nearest) >= nearest) continue;
      if (count < 0) {
        currInst = (-count) - 1;
        if (currInst >= uMaxBvhInstances) continue;
        mat4 w2l = fetchInstanceMat(currInst, 4);
        localOrig = (w2l * vec4(origin, 1.0)).xyz;
        localDir  = (w2l * vec4(dir, 0.0)).xyz;
        localRcp  = safeRecip(localDir);
        if (depth < 47) { blasFloor = depth; stack[depth++] = leftOrFirst; }
      } else if (depth < 46) {
        stack[depth++] = leftOrFirst + 1;
        stack[depth++] = leftOrFirst;
      }
    } else {
      if (intersectAabb(localOrig, localRcp, n0.xyz, n1.xyz, nearest) >= nearest) continue;
      if (count > 0) {
        for (int ti = 0; ti < count; ti++) {
          int triIdx = leftOrFirst + ti;
          int base = triIdx * 4;
          vec4 t0 = fetchTriTexel(base);
          vec3 e1 = fetchTriTexel(base + 1).xyz;
          vec3 e2 = fetchTriTexel(base + 2).xyz;
          vec3 pvec = cross(localDir, e2);
          float det = dot(e1, pvec);
          if (abs(det) < 1e-8) continue;
          float invDet = 1.0 / det;
          vec3 tvec = localOrig - t0.xyz;
          float u = dot(tvec, pvec) * invDet;
          if (u < 0.0 || u > 1.0) continue;
          vec3 qvec = cross(tvec, e1);
          float v = dot(localDir, qvec) * invDet;
          if (v < 0.0 || u + v > 1.0) continue;
          float travel = dot(e2, qvec) * invDet;
          if (travel >= tMin && travel < nearest) {
            nearest = travel; bestTri = triIdx; bestInst = currInst; bestUv = vec2(u, v);
          }
        }
      } else if (depth < 46) {
        stack[depth++] = leftOrFirst + 1;
        stack[depth++] = leftOrFirst;
      }
    }
  }

  if (bestTri >= 0) {
    int base = bestTri * 4;
    vec4 t0 = fetchTriTexel(base);
    vec4 t1 = fetchTriTexel(base + 1);
    vec4 t2 = fetchTriTexel(base + 2);
    vec4 t3 = fetchTriTexel(base + 3);
    vec3 na = unpackOctahedral(int(t1.w + 0.5));
    vec3 nb = unpackOctahedral(int(t2.w + 0.5));
    vec3 nc = unpackOctahedral(int(t3.w + 0.5));
    vec3 localN = normalize(na * (1.0 - bestUv.x - bestUv.y) + nb * bestUv.x + nc * bestUv.y);
    mat4 l2w = fetchInstanceMat(bestInst, 0);
    vec3 worldN = normalize(mat3(l2w) * localN);
    if (dot(worldN, dir) > 0.0) worldN = -worldN;
    int rawMat = int(t0.w + 0.5);
    int over = fetchInstanceMatOverride(bestInst);
    res.hit = true; res.t = nearest; res.pos = origin + dir * nearest;
    res.nrm = worldN; res.matId = (over >= 0) ? over : rawMat;
  }
  return res;
}

float traceSceneShadowBlockerBvh(vec3 origin, vec3 dir, float tMin, float tMax) {
  vec3 worldRcp = safeRecip(dir);
  int stack[48]; int depth = 1; stack[0] = 0;
  int blasFloor = 999999;
  vec3 localOrig = origin; vec3 localDir = dir; vec3 localRcp = worldRcp;
  float closestBlocker = tMax; bool blocked = false;

  for (int stepIdx = 0; stepIdx < 240; stepIdx++) {
    if (depth <= 0) break;
    if (depth <= blasFloor) blasFloor = 999999;
    depth--;
    int nodeIdx = stack[depth];
    vec4 n0 = fetchNodeTexel(nodeIdx * 2);
    vec4 n1 = fetchNodeTexel(nodeIdx * 2 + 1);
    int leftOrFirst = int(n0.w + 0.5);
    int count = int(round(n1.w));

    if (blasFloor == 999999) {
      if (intersectAabb(origin, worldRcp, n0.xyz, n1.xyz, closestBlocker) >= closestBlocker) continue;
      if (count < 0) {
        int inst = (-count) - 1;
        if (inst >= uMaxBvhInstances) continue;
        mat4 w2l = fetchInstanceMat(inst, 4);
        localOrig = (w2l * vec4(origin, 1.0)).xyz;
        localDir  = (w2l * vec4(dir, 0.0)).xyz;
        localRcp  = safeRecip(localDir);
        if (depth < 47) { blasFloor = depth; stack[depth++] = leftOrFirst; }
      } else if (depth < 46) {
        stack[depth++] = leftOrFirst + 1;
        stack[depth++] = leftOrFirst;
      }
    } else {
      if (intersectAabb(localOrig, localRcp, n0.xyz, n1.xyz, closestBlocker) >= closestBlocker) continue;
      if (count > 0) {
        for (int ti = 0; ti < count; ti++) {
          int base = (leftOrFirst + ti) * 4;
          vec4 t0 = fetchTriTexel(base);
          if (int(t0.w + 0.5) == 7) continue;
          vec3 e1 = fetchTriTexel(base + 1).xyz;
          vec3 e2 = fetchTriTexel(base + 2).xyz;
          vec3 pvec = cross(localDir, e2);
          float det = dot(e1, pvec);
          if (abs(det) < 1e-8) continue;
          float invDet = 1.0 / det;
          vec3 tvec = localOrig - t0.xyz;
          float u = dot(tvec, pvec) * invDet;
          if (u < 0.0 || u > 1.0) continue;
          vec3 qvec = cross(tvec, e1);
          float v = dot(localDir, qvec) * invDet;
          if (v < 0.0 || u + v > 1.0) continue;
          float travel = dot(e2, qvec) * invDet;
          if (travel >= tMin && travel < closestBlocker) { closestBlocker = travel; blocked = true; }
        }
      } else if (depth < 46) {
        stack[depth++] = leftOrFirst + 1;
        stack[depth++] = leftOrFirst;
      }
    }
  }
  return blocked ? closestBlocker : -1.0;
}


layout(location = 0) out vec4 outShadow;

vec2 sobol2(uint index){uint g=index^(index>>1u),x=0u,y=0u,v=0x80000000u;for(uint j=0u;j<16u;j++){if((g & (1u<<j))!=0u){x^=0x80000000u>>j;y^=v;}v^=v>>1u;}return (vec2(x,y)+vec2(65536.0))*2.3283064365386963e-10;}
// Common-origin packet for a distant circular source. Geometry stays instanced.
// Bounding intervals enclose every sample direction under a rigid BLAS transform.
bool capBox(vec3 o, vec3 centre, float delta, vec3 lo, vec3 hi){
  float tn=0.003,tf=48.0;
  for(int k=0;k<3;k++){
    float a=centre[k]-delta,b=centre[k]+delta;
    if(b>0.)tn=max(tn,(lo[k]-o[k])/b);else if(b<0.)tf=min(tf,(lo[k]-o[k])/b);else if(o[k]<lo[k])return false;
    if(a>0.)tf=min(tf,(hi[k]-o[k])/a);else if(a<0.)tn=max(tn,(hi[k]-o[k])/a);else if(o[k]>hi[k])return false;
  }return tf>=tn;
}
const int packetSize=32;
float sunPacket(vec3 origin, vec3 L,float tangentRadius,out float blocker){
  float farT[packetSize];vec3 direction[packetSize];vec3 T,B;buildOrthonormalBasis(L,T,B);
  float cmin=inversesqrt(1.+tangentRadius*tangentRadius);
  float delta=sqrt(2.*(1.-cmin))+0.00001;
  for(int j=0;j<packetSize;j++){vec2 q=sobol2(uint(j));float c=mix(1.,cmin,q.x),a=6.283185307*q.y;direction[j]=c*L+sqrt(max(0.,1.-c*c))*(T*cos(a)+B*sin(a));farT[j]=48.;}
  int stack[64];int depth=1,floorDepth=-1;stack[0]=0;
  vec3 o=origin,axis=L;mat3 normalToWorld=mat3(1.);
  while(depth>0){
    if(depth==floorDepth){floorDepth=-1;o=origin;axis=L;}
    int id=stack[--depth];vec4 lo=fetchNodeTexel(id*2),hi=fetchNodeTexel(id*2+1);
    if(!capBox(o,axis,delta,lo.xyz,hi.xyz))continue;
    int first=int(lo.w+0.5),count=int(round(hi.w));
    if(count<0){int inst=-1-count;mat4 inv=fetchInstanceMat(inst,4);o=(inv*vec4(origin,1.)).xyz;axis=mat3(inv)*L;normalToWorld=transpose(mat3(inv));floorDepth=depth;stack[depth++]=first;}
    else if(count==0){stack[depth++]=first;stack[depth++]=first+1;}
    else for(int ti=0;ti<count;ti++){
      int base=(first+ti)*4;vec4 a=fetchTriTexel(base);if(int(a.w+.5)==7)continue;
      vec3 e=fetchTriTexel(base+1).xyz,f=fetchTriTexel(base+2).xyz,off=o-a.xyz;
      vec3 dv=normalToWorld*cross(f,e),uv=normalToWorld*cross(f,off),vv=normalToWorld*cross(off,e);
      float travelNumer=dot(f,cross(off,e));
      for(int j=0;j<packetSize;j++){vec3 D=direction[j];float det=dot(D,dv);if(abs(det)<1.e-8)continue;
        float u=dot(D,uv)/det,v=dot(D,vv)/det,t=travelNumer/det;
        if(u>=0.&&v>=0.&&u+v<=1.&&t>=.003&&t<farT[j])farT[j]=t;}
    }
  }
  int hits=0;float invSum=0.;for(int j=0;j<packetSize;j++){if(farT[j]<48.){hits++;invSum+=1./max(.005,farT[j]);}}
  blocker=hits>0?float(hits)/invSum:0.;return 1.-float(hits)/float(packetSize);
}

float evalBvhLight(int idx, vec3 pos, vec3 nrm, int rays, vec2 r2, out float blkOut) {
  blkOut = 0.0;
  vec3 toLight = (uLightType[idx] == 0) ? uLightDir[idx] : normalize(uLightOrigin[idx] - pos);
  if (dot(nrm, toLight) <= 0.002) return 0.0;

  vec3 origin = pos + nrm * 0.004;
  if(uLightType[idx]==0)return sunPacket(origin,toLight,uLightRadius[idx],blkOut);
  float phi0 = fract(r2.x + float(idx) * 0.371) * 6.2831853;
  int rayCount = clamp(rays, 1, 16);
  float invRays = 1.0 / float(rayCount);
  float visAcc = 0.0, harmInvDist = 0.0; int blkCount = 0;

  vec3 lTan, lBit;
  buildOrthonormalBasis(toLight, lTan, lBit);
  float lRad = uLightRadius[idx];

  for (int s = 0; s < 16; s++) {
    if (s >= rayCount) break;
    float uDisk = (float(s) + fract(r2.y + float(s) * 0.618034) * 0.8 + 0.1) * invRays;
    float rFrac = sqrt(clamp(uDisk, 0.005, 0.995));
    float ang = phi0 + float(s) * 2.39996323;

    vec3 rayDir; float maxT;
    if (uLightType[idx] == 0) {
      vec2 q=sobol2(uint(s));float c=mix(1.,inversesqrt(1.+lRad*lRad),q.x);float a=6.283185307*q.y;rayDir=c*toLight+sqrt(max(0.,1.-c*c))*(lTan*cos(a)+lBit*sin(a));
      maxT = 48.0;
    } else {
      vec3 discPt = uLightOrigin[idx] + (lTan * cos(ang) + lBit * sin(ang)) * (rFrac * lRad);
      vec3 delta = discPt - origin;
      maxT = max(0.05, length(delta) - 0.05);
      rayDir = delta / max(maxT + 0.05, 1e-4);
    }
    float blk = traceSceneShadowBlockerBvh(origin, rayDir, 0.003, maxT);
    if (blk < 0.0) visAcc += invRays;
    else { harmInvDist += 1.0 / max(0.005, blk); blkCount++; }
  }
  blkOut = (blkCount > 0) ? (float(blkCount) / harmInvDist) : 0.0;
  return visAcc;
}

void main() {
  vec4 normMat = texture(uGNormMat, vUv);
  if (normMat.w < 0.5) { outShadow = vec4(1.0, 1.0, 1.0, 0.0); return; }
  vec3 pos = texture(uGPosRough, vUv).xyz;
  vec3 nrm = normalize(normMat.xyz);
  vec2 r2 = r2Sequence(gl_FragCoord.xy);

  float b0 = 0.0, b1 = 0.0, b2 = 0.0;
  float v0 = evalBvhLight(0, pos, nrm, uBvhRays, r2, b0);
  int secRays = max(1, uBvhRays / 2);
  float v1 = (uLightCount >= 2) ? evalBvhLight(1, pos, nrm, secRays, r2, b1) : 1.0;
  float v2 = (uLightCount >= 3) ? evalBvhLight(2, pos, nrm, secRays, r2, b2) : 1.0;
  outShadow = vec4(v0, v1, v2, max(b0, max(b1, b2) * 0.7));
}
