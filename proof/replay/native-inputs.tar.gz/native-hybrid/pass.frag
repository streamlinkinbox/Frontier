#version 300 es
precision highp float;
precision highp sampler3D;

in vec2 vUv;
uniform sampler2D uGPosRough;
uniform sampler2D uGNormMat;

uniform sampler2D uContactMap;
uniform mat4 uContactViewProj;
uniform vec3 uContactOrigin;
uniform vec3 uContactForward;
uniform float uContactHalfSpan;
uniform float uContactRes;
uniform float uContactPerspTan;

uniform int uLightCount;
uniform int uLightType[3];
uniform vec3 uLightOrigin[3];
uniform vec3 uLightDir[3];
uniform float uLightRadius[3];


struct SurfaceMat {
  vec3 albedo;
  float roughness;
  vec3 emissive;
  float metalness;
  float coat;
  float coatRough;
};

SurfaceMat evalMaterial(int matId, vec3 worldPos, vec3 paintColor) {
  SurfaceMat m;
  m.albedo = vec3(0.22, 0.23, 0.26);
  m.roughness = 0.42;
  m.emissive = vec3(0.0);
  m.metalness = 0.16;
  m.coat = 0.0;
  m.coatRough = 0.04;

  if (matId == 1) {
    float gx = abs(fract(worldPos.x * 0.25 + 0.5) - 0.5);
    float gy = abs(fract(worldPos.y * 0.25 + 0.5) - 0.5);
    float grid = 1.0 - smoothstep(0.005, 0.013, min(gx, gy));
    float lane = (1.0 - smoothstep(0.038, 0.058, abs(abs(worldPos.y) - 4.15))) * step(abs(worldPos.x), 11.5);
    vec3 basePad = mix(vec3(0.32, 0.33, 0.36), vec3(0.22, 0.23, 0.26), grid * 0.26);
    m.albedo = mix(basePad, vec3(0.78, 0.60, 0.16), lane * 0.62);
    m.roughness = mix(0.25, 0.36, lane);
    m.metalness = 0.02;
    m.coat = 0.38;
    m.coatRough = 0.11;
  } else if (matId == 2) {
    m.albedo = vec3(0.90, 0.93, 0.97);
    m.roughness = 0.035;
    m.metalness = 0.98;
    m.coat = 0.50;
    m.coatRough = 0.03;
  } else if (matId == 3) {
    m.albedo = vec3(0.94, 0.74, 0.44);
    m.roughness = 0.045;
    m.metalness = 0.96;
    m.coat = 0.40;
    m.coatRough = 0.04;
  } else if (matId == 4) {
    m.albedo = vec3(0.15, 0.16, 0.19);
    m.roughness = 0.28;
    m.metalness = 0.55;
  } else if (matId == 5) {
    m.albedo = vec3(0.95, 0.98, 1.00);
    m.roughness = 0.15;
    m.emissive = vec3(4.5, 5.2, 6.4);
    m.metalness = 0.0;
  } else if (matId == 6) {
    float luma = dot(paintColor, vec3(0.299, 0.587, 0.114));
    m.albedo = paintColor;
    m.roughness = 0.14;
    m.metalness = (luma > 0.78) ? 0.28 : 0.74;
    m.coat = 1.0;
    m.coatRough = 0.032;
  } else if (matId == 7) {
    m.albedo = vec3(0.03, 0.045, 0.065);
    m.roughness = 0.025;
    m.metalness = 0.10;
    m.coat = 1.0;
    m.coatRough = 0.02;
  } else if (matId == 8 || matId == 15) {
    m.albedo = vec3(0.10, 0.105, 0.12);
    m.roughness = 0.26;
    m.metalness = 0.35;
    m.coat = 0.35;
    m.coatRough = 0.12;
  } else if (matId == 10) {
    m.albedo = vec3(0.86, 0.89, 0.94);
    m.roughness = 0.08;
    m.metalness = 0.95;
    m.coat = 0.60;
    m.coatRough = 0.05;
  } else if (matId == 11) {
    m.albedo = vec3(0.065, 0.068, 0.075);
    m.roughness = 0.62;
    m.metalness = 0.02;
  } else if (matId == 12 || matId == 13) {
    m.albedo = vec3(0.92, 0.96, 1.00);
    m.roughness = 0.05;
    m.emissive = (matId == 13) ? vec3(7.0, 7.6, 8.8) : vec3(2.2, 2.6, 3.2);
    m.metalness = 0.0;
    m.coat = 1.0;
    m.coatRough = 0.03;
  } else if (matId == 14) {
    m.albedo = vec3(0.68, 0.03, 0.04);
    m.roughness = 0.06;
    m.emissive = vec3(6.5, 0.40, 0.30);
    m.metalness = 0.0;
    m.coat = 1.0;
    m.coatRough = 0.03;
  } else if (matId == 17) {
    m.albedo = vec3(0.92, 0.28, 0.05);
    m.roughness = 0.18;
    m.metalness = 0.10;
    m.coat = 0.65;
    m.coatRough = 0.08;
  } else if (matId == 18) {
    m.albedo = vec3(0.94, 0.06, 0.08);
    m.roughness = 0.85;
    m.metalness = 0.0;
  } else if (matId == 19) {
    m.albedo = vec3(0.05, 0.68, 0.95);
    m.roughness = 0.85;
    m.metalness = 0.0;
  } else if (matId == 20) {
    m.albedo = vec3(0.88, 0.89, 0.91);
    m.roughness = 0.85;
    m.metalness = 0.0;
  } else if (matId == 21) {
    m.albedo = vec3(0.22, 0.24, 0.30);
    m.roughness = 0.24;
    m.metalness = 0.72;
    m.coat = 0.28;
    m.coatRough = 0.09;
  } else if (matId == 22) {
    m.albedo = vec3(0.75, 0.96, 1.00);
    m.roughness = 0.10;
    m.emissive = vec3(5.2, 8.8, 12.4);
    m.metalness = 0.0;
    m.coat = 0.50;
    m.coatRough = 0.04;
  }
  return m;
}

vec3 evalPortalIrradiance(vec3 pos, vec3 nrm) {
  vec3 portalIrr = vec3(0.0);
  if (pos.z < 6.20) {
    for (int i = -1; i <= 1; i++) {
      vec3 lp = vec3(float(i) * 12.0, clamp(pos.y, -13.0, 13.0), 6.20);
      vec3 d = lp - pos;
      float d2 = dot(d, d);
      vec3 ldir = d * inversesqrt(max(d2, 1e-4));
      portalIrr += vec3(0.75, 0.84, 1.02) * (max(dot(nrm, ldir), 0.0) / (1.0 + 0.12 * d2));
    }
  }
  return portalIrr;
}

vec3 evalSkyAndClouds(vec3 dir, vec3 sunDir, int lightType, vec3 lightColor) {
  float up = clamp(dir.z, -0.25, 1.0);
  vec3 horizon = (lightType == 0) ? vec3(0.50, 0.64, 0.84) : vec3(0.16, 0.18, 0.24);
  vec3 zenith  = (lightType == 0) ? vec3(0.11, 0.24, 0.50) : vec3(0.05, 0.07, 0.11);
  vec3 ground  = vec3(0.07, 0.075, 0.09);
  vec3 sky = (up >= 0.0)
    ? mix(horizon, zenith, pow(max(up, 1e-4), 0.58))
    : mix(horizon * 0.45, ground, clamp(-up * 6.0, 0.0, 1.0));

  if (lightType == 0) {
    float sunCos = max(dot(dir, sunDir), 1e-4);
    sky += lightColor * pow(sunCos, 18.0) * 0.50;
    sky += lightColor * smoothstep(0.99935, 0.99985, sunCos) * 10.0;
    if (dir.z > 0.04) {
      vec2 cuv = dir.xy / (dir.z + 0.18) * 0.55;
      float n = sin(cuv.x * 2.3 + 0.7) * cos(cuv.y * 2.1 - 0.4)
              + 0.5 * sin(cuv.x * 5.1 - cuv.y * 3.7)
              + 0.25 * cos(cuv.x * 9.3 + cuv.y * 8.1);
      float cloud = smoothstep(0.35, 1.18, n) * smoothstep(0.04, 0.24, dir.z);
      vec3 cloudLit = mix(vec3(0.56, 0.64, 0.75), vec3(1.16, 1.10, 1.02), 0.5 + 0.5 * sunCos);
      sky = mix(sky, cloudLit, cloud * 0.48);
    }
  }
  return sky;
}

void buildOrthonormalBasis(vec3 n, out vec3 t, out vec3 b) {
  vec3 up = (abs(n.z) < 0.92) ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
  t = normalize(cross(up, n));
  b = cross(n, t);
}

vec2 r2Sequence(vec2 px) {
  return fract(px.x * vec2(0.7548776662, 0.5698402910) + px.y * vec2(0.5698402910, 0.3247179572));
}

// Clipped-Polygon Linearly Transformed Cosine (LTC) Emissive Area Panel Evaluator (matching Frontier LinearCosineLightIntegration.cpp)
float integrateSphericalEdgeZ(vec3 v1, vec3 v2) {
  float x = clamp(dot(v1, v2), -0.99999, 0.99999);
  float absX = abs(x);
  float a = 5.42031 + (3.12829 + 0.0902326 * absX) * absX;
  float b = 3.45068 + (4.18814 + absX) * absX;
  float thetaOverSin = a / b;
  if (x < 0.0) {
    float sinTheta = sqrt(max(1e-8, 1.0 - x * x));
    thetaOverSin = 3.14159265 / sinTheta - thetaOverSin;
  }
  return (v1.x * v2.y - v1.y * v2.x) * thetaOverSin;
}

float integrateClippedQuadFormFactor(vec3 localQ[4]) {
  vec3 clipped[8];
  int clipCount = 0;
  for (int i = 0; i < 4; i++) {
    vec3 cur = localQ[i];
    vec3 next = localQ[(i + 1) & 3];
    bool curA = (cur.z >= 0.0);
    bool nxtA = (next.z >= 0.0);
    if (curA) clipped[clipCount++] = cur;
    if (curA != nxtA) {
      float alpha = cur.z / (cur.z - next.z);
      vec3 hit = cur + (next - cur) * alpha;
      hit.z = 0.0;
      clipped[clipCount++] = hit;
    }
  }
  if (clipCount < 3) return 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= clipCount) break;
    clipped[i] = normalize(clipped[i]);
  }
  float contourSum = 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= clipCount) break;
    int nxt = (i + 1 >= clipCount) ? 0 : (i + 1);
    contourSum += integrateSphericalEdgeZ(clipped[i], clipped[nxt]);
  }
  return clamp(abs(contourSum) / 6.2831853, 0.0, 1.0);
}

vec3 evalEmissivePanelLtc(
  vec3 pos, vec3 nrm, vec3 viewDir, SurfaceMat m,
  vec3 eCenter, vec3 eRight, vec3 eUp, vec3 eNormal,
  float eHalfW, float eHalfH, float eIntensity, float vis
) {
  if (vis <= 1e-4 || eIntensity <= 1e-4) return vec3(0.0);
  if (dot(pos - eCenter, eNormal) <= 0.02) return vec3(0.0);

  float noV = clamp(dot(nrm, viewDir), 1e-4, 1.0);
  vec3 t1 = viewDir - nrm * noV;
  float t1Len = dot(t1, t1);
  if (t1Len <= 1e-6) {
    vec3 fb;
    buildOrthonormalBasis(nrm, t1, fb);
  } else {
    t1 *= inversesqrt(t1Len);
  }
  vec3 t2 = normalize(cross(nrm, t1));

  vec3 halfU = eRight * eHalfW;
  vec3 halfV = eUp * eHalfH;
  vec3 wc[4];
  wc[0] = eCenter - halfU - halfV;
  wc[1] = eCenter + halfU - halfV;
  wc[2] = eCenter + halfU + halfV;
  wc[3] = eCenter - halfU + halfV;

  vec3 diffLocal[4];
  for (int i = 0; i < 4; i++) {
    vec3 rel = wc[i] - pos;
    diffLocal[i] = vec3(dot(rel, t1), dot(rel, t2), dot(rel, nrm));
  }
  float diffFF = integrateClippedQuadFormFactor(diffLocal);

  float r = max(m.coat > 0.0 ? mix(m.roughness, m.coatRough, m.coat * 0.65) : m.roughness, 0.035);
  float alpha = clamp(r * r, 0.004, 1.0);
  float sinV = sqrt(max(0.0, 1.0 - noV * noV));
  float invScaleX = 1.0 / max(0.04, alpha * (0.85 + 0.15 * noV));
  float invScaleY = 1.0 / max(0.04, alpha);
  float shearXZ = -sinV / max(0.08, noV + alpha);

  vec3 specLocal[4];
  for (int i = 0; i < 4; i++) {
    vec3 d = diffLocal[i];
    float mx = -d.x * noV + d.z * sinV;
    float mz =  d.x * sinV + d.z * noV;
    specLocal[i] = vec3((mx + shearXZ * mz * alpha) * invScaleX, d.y * invScaleY, mz);
  }
  float specFF = integrateClippedQuadFormFactor(specLocal);

  vec3 diffAlb = m.albedo * (1.0 - m.metalness);
  vec3 f0 = mix(vec3(0.04), m.albedo, m.metalness);
  float schlick = pow(max(1.0 - noV, 1e-4), 5.0);
  vec3 specAlb = f0 + (vec3(1.0) - f0) * (schlick * clamp(1.0 - r * 0.65, 0.0, 1.0));
  vec3 rad = vec3(11.0, 26.0, 42.0) * eIntensity;
  return rad * (diffAlb * diffFF + specAlb * specFF) * vis;
}


uniform sampler3D uClip0Dist;
uniform sampler3D uClip1Dist;
uniform sampler3D uClip0Linear;
uniform sampler3D uBodySdf;
uniform sampler3D uRimSdf;
uniform sampler3D uTyreSdf;
uniform sampler3D uLouverSdf;

uniform vec3 uClip0Min;
uniform vec3 uClip0InvSpan;
uniform float uClip0Voxel;
uniform vec3 uClip1Min;
uniform vec3 uClip1InvSpan;
uniform float uClip1Voxel;

uniform vec3 uBodySdfMin;
uniform vec3 uBodySdfMax;
uniform vec3 uBodySdfInvSpan;
uniform vec3 uRimSdfMin;
uniform vec3 uRimSdfMax;
uniform vec3 uRimSdfInvSpan;
uniform vec3 uTyreSdfMin;
uniform vec3 uTyreSdfMax;
uniform vec3 uTyreSdfInvSpan;
uniform vec3 uLouverSdfMin;
uniform vec3 uLouverSdfMax;
uniform vec3 uLouverSdfInvSpan;

uniform mat4 uBodyWorldToLocal;
uniform mat4 uWheelWorldToLocal[4];
uniform int uSdfMode;
uniform int uShowLouvers;

float sampleBoxSdfConservative(sampler3D tex, vec3 localPos, vec3 bmin, vec3 bmax, vec3 invSpan) {
  vec3 pad = vec3(0.015);
  vec3 clamped = clamp(localPos, bmin + pad, bmax - pad);
  float boxDist = length(localPos - clamped);
  vec3 uvw = (clamped - bmin) * invSpan;
  float inner = texture(tex, uvw).r;
  return (boxDist > 0.0) ? (boxDist + max(0.0, inner)) : inner;
}

float sampleDynamicShadowSdf(vec3 worldPos) {
  if (uSdfMode == 1) {
    vec3 u0 = (worldPos - uClip0Min) * uClip0InvSpan;
    float d = 1e4;
    if (all(greaterThan(u0, vec3(0.015))) && all(lessThan(u0, vec3(0.985)))) {
      d = texture(uClip0Linear, u0).a;
    } else {
      vec3 u1 = (worldPos - uClip1Min) * uClip1InvSpan;
      if (all(greaterThan(u1, vec3(0.015))) && all(lessThan(u1, vec3(0.985)))) d = texture(uClip1Dist, u1).r;
    }
    if (uShowLouvers == 1) d = min(d, sampleBoxSdfConservative(uLouverSdf, worldPos, uLouverSdfMin, uLouverSdfMax, uLouverSdfInvSpan));
    return d;
  }

  float d = 1e4;
  vec3 u0 = (worldPos - uClip0Min) * uClip0InvSpan;
  if (all(greaterThan(u0, vec3(0.015))) && all(lessThan(u0, vec3(0.985)))) d = texture(uClip0Dist, u0).r;
  else {
    vec3 u1 = (worldPos - uClip1Min) * uClip1InvSpan;
    if (all(greaterThan(u1, vec3(0.015))) && all(lessThan(u1, vec3(0.985)))) d = texture(uClip1Dist, u1).r;
  }
  vec3 bl = (uBodyWorldToLocal * vec4(worldPos, 1.0)).xyz;
  d = min(d, sampleBoxSdfConservative(uBodySdf, bl, uBodySdfMin, uBodySdfMax, uBodySdfInvSpan));
  for (int w = 0; w < 4; w++) {
    vec3 wl = (uWheelWorldToLocal[w] * vec4(worldPos, 1.0)).xyz;
    float dWheelApprox = length(max(abs(wl) - vec3(0.66, 0.35, 0.66), 0.0));
    if (dWheelApprox < d + 0.12) {
      d = min(d, sampleBoxSdfConservative(uTyreSdf, wl, uTyreSdfMin, uTyreSdfMax, uTyreSdfInvSpan));
      d = min(d, sampleBoxSdfConservative(uRimSdf, wl, uRimSdfMin, uRimSdfMax, uRimSdfInvSpan));
    }
  }
  if (uShowLouvers == 1) d = min(d, sampleBoxSdfConservative(uLouverSdf, worldPos, uLouverSdfMin, uLouverSdfMax, uLouverSdfInvSpan));
  return d;
}

float traceSdfConeShadow(vec3 pos, vec3 nrm, vec3 toLight, float maxDist, int lightType, float lightRadius, out float outBlocker) {
  float minStart = max(0.085, uClip0Voxel * 0.95);
  vec3 origin = pos + nrm * minStart;
  float t = minStart;
  float vis = 1.0;
  outBlocker = 0.0;
  float minPenRatio = 1e4;

  for (int s = 0; s < 38; s++) {
    if (t >= maxDist) break;
    vec3 sp = origin + toLight * t;
    float d = sampleDynamicShadowSdf(sp);
    if (d > 5e3) break;
    float coneW = (lightType == 0)
      ? max(uClip0Voxel * 0.45, lightRadius * t)
      : max(uClip0Voxel * 0.45, lightRadius * (t / max(maxDist, 0.25)));
    float stepVis = smoothstep(-coneW * 0.40, coneW, d);
    if (stepVis < vis) vis = stepVis;
    if (d < coneW && d / max(coneW, 1e-4) < minPenRatio) {
      minPenRatio = d / max(coneW, 1e-4);
      outBlocker = t;
    }
    if (vis < 0.002) { vis = 0.0; break; }
    t += clamp(d * 0.78, 0.04, 0.45);
  }
  return vis;
}


layout(location = 0) out vec4 outShadow;

float evalHybridKey(vec3 pos, vec3 nrm, vec2 r2, out float blkOut) {
  blkOut = 0.0;
  vec3 toLight = (uLightType[0] == 0) ? uLightDir[0] : normalize(uLightOrigin[0] - pos);
  float ndl = dot(nrm, toLight);
  if (ndl <= 0.002) return 0.0;

  float maxDist = (uLightType[0] == 0) ? 24.0 : max(0.15, length(uLightOrigin[0] - pos) - 0.12);
  float sdfBlk = 0.0;
  float sdfVis = traceSdfConeShadow(pos, nrm, toLight, maxDist, uLightType[0], uLightRadius[0], sdfBlk);

  vec3 biasedPos = pos + nrm * 4.5e-3;
  vec4 clip = uContactViewProj * vec4(biasedPos, 1.0);
  vec3 ndc = clip.xyz / max(clip.w, 1e-4);
  vec2 cUv = ndc.xy * 0.5 + 0.5;
  bool insideClip = (clip.w > 1e-4) && all(greaterThan(cUv, vec2(0.01))) && all(lessThan(cUv, vec2(0.99))) && ndc.z >= -1.0 && ndc.z <= 1.0;

  if (!insideClip) { blkOut = sdfBlk; return sdfVis; }

  float recD = (uLightType[0] == 0) ? dot(biasedPos - uContactOrigin, uContactForward) : length(biasedPos - uContactOrigin);
  float texelWorld = (uLightType[0] == 0) ? (2.0 * uContactHalfSpan) / uContactRes : (2.0 * recD * uContactPerspTan) / uContactRes;
  float slope = clamp(sqrt(max(0.0, 1.0 - ndl * ndl)) / max(ndl, 0.04), 0.0, 4.0);
  float biasM = texelWorld * (1.2 + 0.8 * slope);

  float litSum = 0.0, blkSum = 0.0; int blkCnt = 0;
  float phi0 = r2.x * 6.2831853;
  for (int t = 0; t < 8; t++) {
    float rad = sqrt((float(t) + 0.5) * 0.125) * 1.45;
    float ang = phi0 + float(t) * 2.39996323;
    ivec2 tc = clamp(ivec2(cUv * uContactRes + vec2(cos(ang), sin(ang)) * rad), ivec2(0), ivec2(int(uContactRes) - 1));
    float cd = texelFetch(uContactMap, tc, 0).r;
    float df = recD - cd;
    if (df > biasM) { blkSum += df; blkCnt++; } else { litSum += 1.0; }
  }
  float clipVis = litSum * 0.125;
  blkOut = (blkCnt > 0) ? (blkSum / float(blkCnt)) : sdfBlk;
  float farW = clamp((blkOut - 0.12) / 0.45, 0.0, 1.0) * 0.78;
  return mix(clipVis, min(clipVis + 0.30, sdfVis), farW);
}

void main() {
  vec4 normMat = texture(uGNormMat, vUv);
  if (normMat.w < 0.5) { outShadow = vec4(1.0, 1.0, 1.0, 0.0); return; }
  vec3 pos = texture(uGPosRough, vUv).xyz;
  vec3 nrm = normalize(normMat.xyz);
  vec2 r2 = r2Sequence(gl_FragCoord.xy);

  float b0 = 0.0, b1 = 0.0, b2 = 0.0;
  float v0 = evalHybridKey(pos, nrm, r2, b0);
  float v1 = 1.0, v2 = 1.0;
  if (uLightCount >= 2) {
    vec3 l1 = (uLightType[1] == 0) ? uLightDir[1] : normalize(uLightOrigin[1] - pos);
    v1 = (dot(nrm, l1) > 0.002) ? traceSdfConeShadow(pos, nrm, l1, max(0.15, length(uLightOrigin[1] - pos) - 0.12), uLightType[1], uLightRadius[1], b1) : 0.0;
  }
  if (uLightCount >= 3) {
    vec3 l2 = (uLightType[2] == 0) ? uLightDir[2] : normalize(uLightOrigin[2] - pos);
    v2 = (dot(nrm, l2) > 0.002) ? traceSdfConeShadow(pos, nrm, l2, max(0.15, length(uLightOrigin[2] - pos) - 0.12), uLightType[2], uLightRadius[2], b2) : 0.0;
  }
  outShadow = vec4(v0, v1, v2, max(b0, max(b1, b2) * 0.7));
}
