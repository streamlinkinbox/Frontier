#version 300 es
precision highp float;
precision highp sampler3D;

in vec2 vUv;
uniform sampler2D uGPosRough;
uniform sampler2D uGNormMat;
uniform int uLightCount;
uniform int uLightType[3];
uniform vec3 uLightOrigin[3];
uniform vec3 uLightDir[3];
uniform float uLightRadius[3];


uniform sampler3D uClip0Dist;
uniform sampler3D uClip1Dist;
uniform sampler3D uClip0Linear;
uniform sampler3D uBodySdf;
uniform sampler3D uRimSdf;
uniform sampler3D uTyreSdf;
uniform sampler3D uLouverSdf;

uniform vec3 uClip0Min;
uniform vec3 uClip0InvSpan;
uniform float uClip0Voxel;
uniform vec3 uClip1Min;
uniform vec3 uClip1InvSpan;
uniform float uClip1Voxel;

uniform vec3 uBodySdfMin;
uniform vec3 uBodySdfMax;
uniform vec3 uBodySdfInvSpan;
uniform vec3 uRimSdfMin;
uniform vec3 uRimSdfMax;
uniform vec3 uRimSdfInvSpan;
uniform vec3 uTyreSdfMin;
uniform vec3 uTyreSdfMax;
uniform vec3 uTyreSdfInvSpan;
uniform vec3 uLouverSdfMin;
uniform vec3 uLouverSdfMax;
uniform vec3 uLouverSdfInvSpan;

uniform mat4 uBodyWorldToLocal;
uniform mat4 uWheelWorldToLocal[4];
uniform int uSdfMode;
uniform int uShowLouvers;

float sampleBoxSdfConservative(sampler3D tex, vec3 localPos, vec3 bmin, vec3 bmax, vec3 invSpan) {
  vec3 pad = vec3(0.015);
  vec3 clamped = clamp(localPos, bmin + pad, bmax - pad);
  float boxDist = length(localPos - clamped);
  vec3 uvw = (clamped - bmin) * invSpan;
  float inner = texture(tex, uvw).r;
  return (boxDist > 0.0) ? (boxDist + max(0.0, inner)) : inner;
}

float sampleDynamicShadowSdf(vec3 worldPos) {
  if (uSdfMode == 1) {
    vec3 u0 = (worldPos - uClip0Min) * uClip0InvSpan;
    float d = 1e4;
    if (all(greaterThan(u0, vec3(0.015))) && all(lessThan(u0, vec3(0.985)))) {
      d = texture(uClip0Linear, u0).a;
    } else {
      vec3 u1 = (worldPos - uClip1Min) * uClip1InvSpan;
      if (all(greaterThan(u1, vec3(0.015))) && all(lessThan(u1, vec3(0.985)))) d = texture(uClip1Dist, u1).r;
    }
    if (uShowLouvers == 1) d = min(d, sampleBoxSdfConservative(uLouverSdf, worldPos, uLouverSdfMin, uLouverSdfMax, uLouverSdfInvSpan));
    return d;
  }

  float d = 1e4;
  vec3 u0 = (worldPos - uClip0Min) * uClip0InvSpan;
  if (all(greaterThan(u0, vec3(0.015))) && all(lessThan(u0, vec3(0.985)))) d = texture(uClip0Dist, u0).r;
  else {
    vec3 u1 = (worldPos - uClip1Min) * uClip1InvSpan;
    if (all(greaterThan(u1, vec3(0.015))) && all(lessThan(u1, vec3(0.985)))) d = texture(uClip1Dist, u1).r;
  }
  vec3 bl = (uBodyWorldToLocal * vec4(worldPos, 1.0)).xyz;
  d = min(d, sampleBoxSdfConservative(uBodySdf, bl, uBodySdfMin, uBodySdfMax, uBodySdfInvSpan));
  for (int w = 0; w < 4; w++) {
    vec3 wl = (uWheelWorldToLocal[w] * vec4(worldPos, 1.0)).xyz;
    float dWheelApprox = length(max(abs(wl) - vec3(0.66, 0.35, 0.66), 0.0));
    if (dWheelApprox < d + 0.12) {
      d = min(d, sampleBoxSdfConservative(uTyreSdf, wl, uTyreSdfMin, uTyreSdfMax, uTyreSdfInvSpan));
      d = min(d, sampleBoxSdfConservative(uRimSdf, wl, uRimSdfMin, uRimSdfMax, uRimSdfInvSpan));
    }
  }
  if (uShowLouvers == 1) d = min(d, sampleBoxSdfConservative(uLouverSdf, worldPos, uLouverSdfMin, uLouverSdfMax, uLouverSdfInvSpan));
  return d;
}

float traceSdfConeShadow(vec3 pos, vec3 nrm, vec3 toLight, float maxDist, int lightType, float lightRadius, out float outBlocker) {
  float minStart = max(0.085, uClip0Voxel * 0.95);
  vec3 origin = pos + nrm * minStart;
  float t = minStart;
  float vis = 1.0;
  outBlocker = 0.0;
  float minPenRatio = 1e4;

  for (int s = 0; s < 38; s++) {
    if (t >= maxDist) break;
    vec3 sp = origin + toLight * t;
    float d = sampleDynamicShadowSdf(sp);
    if (d > 5e3) break;
    float coneW = (lightType == 0)
      ? max(uClip0Voxel * 0.45, lightRadius * t)
      : max(uClip0Voxel * 0.45, lightRadius * (t / max(maxDist, 0.25)));
    float stepVis = smoothstep(-coneW * 0.40, coneW, d);
    if (stepVis < vis) vis = stepVis;
    if (d < coneW && d / max(coneW, 1e-4) < minPenRatio) {
      minPenRatio = d / max(coneW, 1e-4);
      outBlocker = t;
    }
    if (vis < 0.002) { vis = 0.0; break; }
    t += clamp(d * 0.78, 0.04, 0.45);
  }
  return vis;
}


layout(location = 0) out vec4 outShadow;

float evalSdfLight(int idx, vec3 pos, vec3 nrm, out float blk) {
  blk = 0.0;
  vec3 toLight = (uLightType[idx] == 0) ? uLightDir[idx] : normalize(uLightOrigin[idx] - pos);
  if (dot(nrm, toLight) <= 0.002) return 0.0;
  float maxDist = (uLightType[idx] == 0) ? 24.0 : max(0.15, length(uLightOrigin[idx] - pos) - 0.12);
  return traceSdfConeShadow(pos, nrm, toLight, maxDist, uLightType[idx], uLightRadius[idx], blk);
}

void main() {
  vec4 normMat = texture(uGNormMat, vUv);
  if (normMat.w < 0.5) { outShadow = vec4(1.0, 1.0, 1.0, 0.0); return; }
  vec3 pos = texture(uGPosRough, vUv).xyz;
  vec3 nrm = normalize(normMat.xyz);

  float b0 = 0.0, b1 = 0.0, b2 = 0.0;
  float v0 = evalSdfLight(0, pos, nrm, b0);
  float v1 = (uLightCount >= 2) ? evalSdfLight(1, pos, nrm, b1) : 1.0;
  float v2 = (uLightCount >= 3) ? evalSdfLight(2, pos, nrm, b2) : 1.0;
  outShadow = vec4(v0, v1, v2, max(b0, max(b1, b2) * 0.7));
}
